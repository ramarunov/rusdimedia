import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Get the response
  const response = NextResponse.next()

  // Add Vary header to ensure proper caching based on client capabilities
  response.headers.set("Vary", "Accept-Encoding, User-Agent")

  // Add Surrogate-Control header for legacy CDNs
  const path = request.nextUrl.pathname

  if (path.match(/\.(jpg|jpeg|png|webp|avif|ico|svg|js|css|woff|woff2|ttf|otf|eot)$/)) {
    // Static assets - long cache
    response.headers.set("Surrogate-Control", "public, max-age=31536000, immutable")
  } else if (
    path.match(
      /\/(sitemap\.xml|post-sitemap\.xml|category-sitemap\.xml|tag-sitemap\.xml|sitemap-index\.xml|robots\.txt)$/,
    )
  ) {
    // Dynamic content - short cache
    response.headers.set("Surrogate-Control", "public, max-age=1800, s-maxage=3600, stale-while-revalidate=7200")
  } else {
    // HTML pages - moderate cache
    response.headers.set("Surrogate-Control", "public, max-age=3600, s-maxage=86400, stale-while-revalidate=86400")
  }

  return response
}

// Only run middleware on specific paths - exclude static assets to avoid potential issues
export const config = {
  matcher: [
    // Apply to all routes except static assets and API routes
    "/((?!_next/static|_next/image|favicon.ico|api).*)",
  ],
}
