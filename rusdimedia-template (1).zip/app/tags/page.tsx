import Link from "next/link"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Semua Tag - Rusdimedia.com",
  description: "Jelajahi semua tag artikel di Rusdimedia.com",
  alternates: {
    canonical: "https://rusdimedia.com/tags",
  },
}

export default async function TagsIndexPage() {
  let tags = []

  try {
    // Fetch tags directly from the WordPress API
    const response = await fetch("https://dash.rusdimedia.com/wp-json/wp/v2/tags?per_page=100", {
      next: { revalidate: 3600 }, // Cache for 1 hour
    })

    if (!response.ok) {
      console.error(`Failed to fetch tags: ${response.status}`)
      throw new Error("Failed to fetch tags")
    }

    tags = await response.json()

    if (!Array.isArray(tags)) {
      console.error("Invalid tags response format")
      tags = []
    }
  } catch (error) {
    console.error("Error fetching tags:", error)
    tags = []
  }

  // Filter out tags with no posts and sort by count
  const activeTags = tags.filter((tag) => tag.count > 0).sort((a, b) => b.count - a.count)

  // Show a message if no tags are found
  if (activeTags.length === 0) {
    return (
      <div className="py-6">
        <h1 className="mb-8 text-3xl font-bold">Semua Tag</h1>
        <div className="text-center py-12">
          <p className="text-lg text-gray-600">Tidak ada tag yang tersedia saat ini.</p>
          <Link href="/" className="mt-4 inline-block rounded-md bg-[#00acee] px-6 py-3 text-white hover:bg-[#0096ce]">
            Kembali ke Beranda
          </Link>
        </div>
      </div>
    )
  }

  // Group tags by first letter for alphabetical display
  const groupedTags: Record<string, typeof activeTags> = {}

  activeTags.forEach((tag) => {
    const firstLetter = tag.name.charAt(0).toUpperCase()
    if (!groupedTags[firstLetter]) {
      groupedTags[firstLetter] = []
    }
    groupedTags[firstLetter].push(tag)
  })

  // Get sorted letters
  const letters = Object.keys(groupedTags).sort()

  return (
    <div className="py-6">
      <h1 className="mb-8 text-3xl font-bold">Semua Tag</h1>

      {/* Popular tags */}
      <div className="mb-10">
        <h2 className="mb-4 text-xl font-bold">Tag Populer</h2>
        <div className="flex flex-wrap gap-3">
          {activeTags.slice(0, 20).map((tag) => (
            <Link
              key={tag.id}
              href={`/tags/${tag.slug}`}
              className="rounded-full bg-gray-100 px-3 py-2 text-sm font-medium hover:bg-gray-200"
            >
              #{tag.name} <span className="text-gray-500">({tag.count})</span>
            </Link>
          ))}
        </div>
      </div>

      {/* Alphabetical tags */}
      <div>
        <h2 className="mb-4 text-xl font-bold">Semua Tag</h2>

        {/* Alphabet navigation */}
        <div className="mb-6 flex flex-wrap gap-2">
          {letters.map((letter) => (
            <a
              key={letter}
              href={`#letter-${letter}`}
              className="flex h-8 w-8 items-center justify-center rounded-full bg-[#00acee] text-white hover:bg-[#0096ce]"
            >
              {letter}
            </a>
          ))}
        </div>

        {/* Tags by letter */}
        <div className="space-y-8">
          {letters.map((letter) => (
            <div key={letter} id={`letter-${letter}`}>
              <h3 className="mb-3 text-lg font-bold">{letter}</h3>
              <div className="flex flex-wrap gap-3">
                {groupedTags[letter].map((tag) => (
                  <Link
                    key={tag.id}
                    href={`/tags/${tag.slug}`}
                    className="rounded-full bg-gray-100 px-3 py-1 text-sm hover:bg-gray-200"
                  >
                    #{tag.name} <span className="text-gray-500">({tag.count})</span>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
