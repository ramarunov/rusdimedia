import type { Metadata } from "next"
import Link from "next/link"
import { notFound } from "next/navigation"
import { formatDate } from "@/lib/utils"
import Pagination from "@/components/pagination"
import OptimizedImage from "@/components/optimized-image"

interface TagPageProps {
  params: {
    slug: string
  }
  searchParams: {
    page?: string
  }
}

export async function generateMetadata({ params }: TagPageProps): Promise<Metadata> {
  try {
    // Fetch the specific tag directly
    const tagResponse = await fetch(`https://dash.rusdimedia.com/wp-json/wp/v2/tags?slug=${params.slug}`)

    if (!tagResponse.ok) {
      return {
        title: "Tag Not Found - Rusdimedia.com",
        description: "The requested tag could not be found.",
      }
    }

    const tags = await tagResponse.json()

    if (!tags || tags.length === 0) {
      return {
        title: "Tag Not Found - Rusdimedia.com",
        description: "The requested tag could not be found.",
      }
    }

    const tag = tags[0]

    return {
      title: `#${tag.name} - Rusdimedia.com`,
      description: `Berita dan artikel terbaru dengan tag #${tag.name} di Rusdimedia.com`,
      alternates: {
        canonical: `https://rusdimedia.com/tags/${params.slug}`,
      },
    }
  } catch (error) {
    console.error("Error generating metadata for tag:", error)
    return {
      title: "Tag - Rusdimedia.com",
      description: "Berita dan artikel terbaru di Rusdimedia.com",
    }
  }
}

export default async function TagPage({ params, searchParams }: TagPageProps) {
  const { slug } = params
  const currentPage = searchParams.page ? Number.parseInt(searchParams.page) : 1
  const postsPerPage = 9

  try {
    // Fetch the specific tag directly
    const tagResponse = await fetch(`https://dash.rusdimedia.com/wp-json/wp/v2/tags?slug=${slug}`)

    if (!tagResponse.ok) {
      console.error(`Failed to fetch tag with slug ${slug}: ${tagResponse.status}`)
      notFound()
    }

    const tags = await tagResponse.json()

    if (!tags || tags.length === 0) {
      console.error(`No tag found with slug ${slug}`)
      notFound()
    }

    const tag = tags[0]
    const tagId = tag.id
    const tagCount = tag.count || 0

    // Fetch posts for this tag
    const postsResponse = await fetch(
      `https://dash.rusdimedia.com/wp-json/wp/v2/posts?tags=${tagId}&per_page=${postsPerPage}&page=${currentPage}&_embed=true`,
    )

    if (!postsResponse.ok) {
      console.error(`Failed to fetch posts for tag ${slug}: ${postsResponse.status}`)
      notFound()
    }

    const posts = await postsResponse.json()

    // Fetch related tags (other tags with posts)
    const allTagsResponse = await fetch(`https://dash.rusdimedia.com/wp-json/wp/v2/tags?per_page=20`)
    const allTags = allTagsResponse.ok ? await allTagsResponse.json() : []

    // Filter out the current tag and tags with no posts
    const relatedTags = allTags
      .filter((t: any) => t.id !== tagId && t.count > 0)
      .sort(() => 0.5 - Math.random()) // Shuffle
      .slice(0, 10) // Take 10 random tags

    return (
      <div className="py-6">
        <header className="mb-8 text-center">
          <h1 className="text-3xl font-bold md:text-4xl">#{tag.name}</h1>
          <p className="mt-2 text-gray-600">
            Menampilkan {posts.length} dari {tagCount} artikel
          </p>
        </header>

        {/* Related tags */}
        {relatedTags.length > 0 && (
          <div className="mb-8">
            <h2 className="mb-3 text-lg font-semibold">Tag Terkait</h2>
            <div className="flex flex-wrap gap-2">
              {relatedTags.map((relatedTag: any) => (
                <Link
                  key={relatedTag.id}
                  href={`/tags/${relatedTag.slug}`}
                  className="rounded-full bg-gray-100 px-3 py-1 text-sm hover:bg-gray-200"
                >
                  #{relatedTag.name}
                </Link>
              ))}
            </div>
          </div>
        )}

        {posts.length > 0 ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {posts.map((post: any, index: number) => (
              <article key={post.id} className="article-card">
                <Link href={`/${post.slug}`}>
                  <div className="aspect-[16/9] relative">
                    {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                      <OptimizedImage
                        src={post._embedded["wp:featuredmedia"][0].source_url}
                        alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                        fill
                        loading={index < 6 ? "eager" : "lazy"} // Load first 6 images eagerly
                        className="object-cover transition-transform duration-300 hover:scale-105"
                        sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, 33vw"
                        quality={75}
                      />
                    ) : (
                      <div className="h-full w-full bg-gray-300" />
                    )}
                  </div>
                  <div className="p-4">
                    <h2 className="article-title text-lg" dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                    <div className="article-meta mt-2">
                      <span>{formatDate(post.date)}</span>
                    </div>
                    <div
                      className="mt-2 text-sm text-gray-600 line-clamp-2"
                      dangerouslySetInnerHTML={{ __html: post.excerpt.rendered }}
                    />
                  </div>
                </Link>
              </article>
            ))}
          </div>
        ) : (
          <div className="my-12 text-center">
            <p className="text-lg text-gray-600">Tidak ada artikel dengan tag ini.</p>
            <Link
              href="/"
              className="mt-4 inline-block rounded-md bg-[#00acee] px-6 py-3 text-white hover:bg-[#0096ce]"
            >
              Kembali ke Beranda
            </Link>
          </div>
        )}

        {tagCount > postsPerPage && (
          <Pagination
            currentPage={currentPage}
            totalItems={tagCount}
            itemsPerPage={postsPerPage}
            baseUrl={`/tags/${slug}`}
          />
        )}
      </div>
    )
  } catch (error) {
    console.error(`Error in tag page for slug ${slug}:`, error)
    notFound()
  }
}
