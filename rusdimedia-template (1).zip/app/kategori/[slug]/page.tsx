import { fetchCategoryBySlug, fetchPostsByCategory, fetchSubcategories } from "@/lib/api"
import type { Metadata } from "next"
import Link from "next/link"
import { notFound } from "next/navigation"
import { formatDate } from "@/lib/utils"
import Pagination from "@/components/pagination"
import OptimizedImage from "@/components/optimized-image"
import { generateCollectionPageSchema, generateBreadcrumbSchema } from "@/lib/schema"

interface CategoryPageProps {
  params: {
    slug: string
  }
  searchParams: {
    page?: string
  }
}

export async function generateMetadata({ params }: CategoryPageProps): Promise<Metadata> {
  const category = await fetchCategoryBySlug(params.slug)

  if (!category) {
    return {
      title: "Category Not Found - Rusdimedia.com",
      description: "The requested category could not be found.",
    }
  }

  return {
    title: `${category.name} - Rusdimedia.com`,
    description: `Berita dan artikel terbaru tentang ${category.name} di Rusdimedia.com`,
    keywords: `${category.name}, berita ${category.name}, artikel ${category.name}`,
    alternates: {
      canonical: `https://rusdimedia.com/kategori/${params.slug}`,
    },
    openGraph: {
      title: `${category.name} - Rusdimedia.com`,
      description: `Berita dan artikel terbaru tentang ${category.name} di Rusdimedia.com`,
      url: `https://rusdimedia.com/kategori/${params.slug}`,
      type: "website",
      siteName: "Rusdimedia.com",
    },
  }
}

export default async function CategoryPage({ params, searchParams }: CategoryPageProps) {
  const category = await fetchCategoryBySlug(params.slug)

  if (!category) {
    notFound()
  }

  const currentPage = searchParams.page ? Number.parseInt(searchParams.page) : 1
  const postsPerPage = 9

  const posts = await fetchPostsByCategory(params.slug, postsPerPage)

  // Fetch subcategories for this category
  const subcategories = await fetchSubcategories(params.slug)

  // Generate schema.org structured data
  const collectionPageSchema = generateCollectionPageSchema(
    `${category.name} - Rusdimedia.com`,
    `https://rusdimedia.com/kategori/${params.slug}`,
  )

  // Generate breadcrumb schema
  const breadcrumbItems = [
    { name: "Beranda", url: "https://rusdimedia.com/" },
    { name: category.name, url: `https://rusdimedia.com/kategori/${params.slug}` },
  ]

  const breadcrumbSchema = generateBreadcrumbSchema(breadcrumbItems)

  return (
    <>
      {/* Add schema.org JSON-LD structured data */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(collectionPageSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />

      <div className="py-6">
        <header className="mb-8 text-center">
          <h1 className="text-3xl font-bold md:text-4xl">{category.name}</h1>
          <p className="mt-2 text-gray-600">
            Menampilkan {posts.length} dari {category.count} artikel
          </p>
        </header>

        {/* Display subcategories if available */}
        {subcategories.length > 0 && (
          <div className="mb-8">
            <h2 className="mb-4 text-xl font-bold">Sub Kategori</h2>
            <div className="flex flex-wrap gap-3">
              {subcategories.map((subcategory) => (
                <Link
                  key={subcategory.id}
                  href={`/kategori/${params.slug}/${subcategory.slug}`}
                  className="rounded-md bg-gray-100 px-4 py-2 text-sm font-medium hover:bg-gray-200"
                >
                  {subcategory.name} <span className="text-gray-500">({subcategory.count})</span>
                </Link>
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {posts.map((post, index) => (
            <article key={post.id} className="article-card">
              <Link href={`/${post.slug}`}>
                <div className="aspect-[16/9] relative">
                  {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                    <OptimizedImage
                      src={post._embedded["wp:featuredmedia"][0].source_url}
                      alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                      fill
                      loading={index < 6 ? "eager" : "lazy"} // Load first 6 images eagerly
                      className="object-cover transition-transform duration-300 hover:scale-105"
                      sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, 33vw"
                      quality={75}
                    />
                  ) : (
                    <div className="h-full w-full bg-gray-300" />
                  )}
                </div>
                <div className="p-4">
                  <h2 className="article-title text-lg" dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                  <div className="article-meta mt-2">
                    <span>{formatDate(post.date)}</span>
                  </div>
                  <div
                    className="mt-2 text-sm text-gray-600 line-clamp-2"
                    dangerouslySetInnerHTML={{ __html: post.excerpt.rendered }}
                  />
                </div>
              </Link>
            </article>
          ))}
        </div>

        {posts.length === 0 && (
          <div className="my-12 text-center">
            <p className="text-lg text-gray-600">Tidak ada artikel dalam kategori ini.</p>
            <Link
              href="/"
              className="mt-4 inline-block rounded-md bg-[#00acee] px-6 py-3 text-white hover:bg-[#0096ce]"
            >
              Kembali ke Beranda
            </Link>
          </div>
        )}

        <Pagination
          currentPage={currentPage}
          totalItems={category.count}
          itemsPerPage={postsPerPage}
          baseUrl={`/kategori/${params.slug}`}
        />
      </div>
    </>
  )
}
