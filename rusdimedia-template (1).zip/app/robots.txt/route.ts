export async function GET() {
  const robotsTxt = `# www.robotstxt.org/

User-agent: *
Allow: /

# Sitemaps
Sitemap: https://rusdimedia.com/sitemap-index.xml
Sitemap: https://rusdimedia.com/sitemap.xml
Sitemap: https://rusdimedia.com/post-sitemap.xml
Sitemap: https://rusdimedia.com/category-sitemap.xml
Sitemap: https://rusdimedia.com/tag-sitemap.xml

# Crawl delay
Crawl-delay: 1

# Disallow
Disallow: /api/
Disallow: /_next/
Disallow: /404
Disallow: /search?*
Disallow: /*?preview=*
Disallow: /*&preview=*
`

  return new Response(robotsTxt, {
    headers: {
      "Content-Type": "text/plain",
      "Cache-Control": "public, max-age=3600, s-maxage=3600",
    },
  })
}
