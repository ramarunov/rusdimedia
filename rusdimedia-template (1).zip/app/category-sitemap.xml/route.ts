import { fetchCategories } from "@/lib/api"

export const revalidate = 1800 // Revalidate every 30 minutes

export async function GET() {
  try {
    // Fetch all categories
    const categories = await fetchCategories()

    // Base URL
    const baseUrl = "https://rusdimedia.com"

    // Current date for lastmod
    const today = new Date().toISOString()

    // Create XML content
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${categories
  .map(
    (category) => `
<url>
  <loc>${baseUrl}/kategori/${category.slug}</loc>
  <lastmod>${today}</lastmod>
  <changefreq>daily</changefreq>
  <priority>0.8</priority>
</url>
`,
  )
  .join("")}
</urlset>`

    // Return XML response
    return new Response(xml, {
      headers: {
        "Content-Type": "application/xml",
        "Cache-Control": "public, max-age=1800, s-maxage=3600, stale-while-revalidate=7200",
      },
    })
  } catch (error) {
    console.error("Error generating category sitemap:", error)

    // Return a minimal sitemap in case of error
    const fallbackXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
</urlset>`

    return new Response(fallbackXml, {
      headers: {
        "Content-Type": "application/xml",
        "Cache-Control": "public, max-age=1800, s-maxage=3600",
      },
    })
  }
}
