import { fetchCategories, fetchPosts, fetchPages, fetchTags } from "@/lib/api"
import Link from "next/link"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Sitemap - Rusdimedia.com",
  description: "Sitemap of Rusdimedia.com",
  alternates: {
    canonical: "https://rusdimedia.com/sitemap",
  },
}

export default async function SitemapPage() {
  const [posts, categories, pages, tags] = await Promise.all([
    fetchPosts({ per_page: 100 }),
    fetchCategories(),
    fetchPages(),
    fetchTags(),
  ])

  return (
    <div className="py-6">
      <h1 className="mb-8 text-3xl font-bold">Sitemap</h1>

      <div className="space-y-8">
        {/* Categories */}
        <section>
          <h2 className="mb-4 text-xl font-bold">Kategori</h2>
          <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-3">
            {categories.map((category) => (
              <li key={category.id}>
                <Link href={`/kategori/${category.slug}`} className="hover:text-[#00acee]">
                  {category.name} ({category.count})
                </Link>
              </li>
            ))}
          </ul>
        </section>

        {/* Tags - Added this section */}
        <section>
          <h2 className="mb-4 text-xl font-bold">Tags</h2>
          <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-3">
            {tags.slice(0, 30).map((tag) => (
              <li key={tag.id}>
                <Link href={`/tags/${tag.slug}`} className="hover:text-[#00acee]">
                  #{tag.name} ({tag.count})
                </Link>
              </li>
            ))}
            <li>
              <Link href="/tags" className="text-[#00acee] font-medium hover:underline">
                Lihat Semua Tags...
              </Link>
            </li>
          </ul>
        </section>

        {/* Pages */}
        <section>
          <h2 className="mb-4 text-xl font-bold">Halaman</h2>
          <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-3">
            {pages.map((page) => (
              <li key={page.id}>
                <Link href={`/pages/${page.slug}`} className="hover:text-[#00acee]">
                  <span dangerouslySetInnerHTML={{ __html: page.title.rendered }} />
                </Link>
              </li>
            ))}
          </ul>
        </section>

        {/* Posts */}
        <section>
          <h2 className="mb-4 text-xl font-bold">Artikel Terbaru</h2>
          <ul className="space-y-2">
            {posts.map((post) => (
              <li key={post.id}>
                <Link href={`/${post.slug}`} className="hover:text-[#00acee]">
                  <span dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                </Link>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  )
}
