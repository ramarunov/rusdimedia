import { fetchPageBySlug } from "@/lib/api"
import type { Metadata } from "next"
import { notFound } from "next/navigation"
import { formatDate } from "@/lib/utils"

interface StaticPageProps {
  params: {
    slug: string[]
  }
}

export async function generateMetadata({ params }: StaticPageProps): Promise<Metadata> {
  const slug = params.slug.join("/")
  const page = await fetchPageBySlug(slug)

  if (!page) {
    return {
      title: "Page Not Found - Rusdimedia.com",
      description: "The requested page could not be found.",
    }
  }

  const title = page.title.rendered.replace(/<[^>]*>/g, "")

  return {
    title: `${title} - Rusdimedia.com`,
    description: "Rusdimedia.com - Berita Terkini, Gaya Hidup, Tips & Tricks",
    alternates: {
      canonical: `https://rusdimedia.com/halaman/${slug}`,
    },
  }
}

export default async function StaticPage({ params }: StaticPageProps) {
  const slug = params.slug.join("/")
  const page = await fetchPageBySlug(slug)

  if (!page) {
    notFound()
  }

  return (
    <div className="py-6">
      <article className="mx-auto max-w-3xl">
        <header className="mb-6 text-center">
          <h1
            className="mb-4 text-3xl font-bold leading-tight md:text-4xl"
            dangerouslySetInnerHTML={{ __html: page.title.rendered }}
          />
          <div className="text-sm text-gray-500">Last updated: {formatDate(page.modified || page.date)}</div>
        </header>

        <div
          className="prose max-w-none prose-headings:font-bold prose-a:text-[#00acee]"
          dangerouslySetInnerHTML={{ __html: page.content.rendered }}
        />
      </article>
    </div>
  )
}
