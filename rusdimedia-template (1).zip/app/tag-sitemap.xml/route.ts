import { fetchTags } from "@/lib/api"

export const revalidate = 1800 // Revalidate every 30 minutes

export async function GET() {
  // Fetch all tags
  const tags = await fetchTags()

  // Base URL
  const baseUrl = "https://rusdimedia.com"

  // Current date for lastmod
  const today = new Date().toISOString()

  // Create XML content
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${tags
  .map(
    (tag) => `
<url>
  <loc>${baseUrl}/tags/${tag.slug}</loc>
  <lastmod>${today}</lastmod>
  <changefreq>daily</changefreq>
  <priority>0.6</priority>
</url>
`,
  )
  .join("")}
</urlset>`

  // Return XML response
  return new Response(xml, {
    headers: {
      "Content-Type": "application/xml",
      "Cache-Control": "public, max-age=1800, s-maxage=3600, stale-while-revalidate=7200",
    },
  })
}
