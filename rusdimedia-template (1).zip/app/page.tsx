import React from "react"
import type { Metadata } from "next"
import FeaturedPosts from "@/components/featured-posts"
import TrendingTags from "@/components/trending-tags" // Import the new component
import LatestPosts from "@/components/latest-posts"
import TrendingPosts from "@/components/trending-posts"
import CategorySection from "@/components/category-section"
import TeknologiVideos from "@/components/teknologi-videos"
import Sidebar from "@/components/sidebar"
import AdsBanner from "@/components/ads-banner"
import { generateWebsiteSchema } from "@/lib/schema"
import KesehatanSection from "@/components/kesehatan-section"
import ThreeColumnCategories from "@/components/three-column-categories"
import AdComponent from "@/components/AdComponent"

export const metadata: Metadata = {
  title: "Rusdimedia.com - Berita Terkini, Gaya Hidup, Tips & Tricks",
  description:
    "Baca berita dan informasi terbaru seputar politik, gaya hidup, tips dan trik hari ini hanya di Rusdi Media. Disajikan berdasarkan fakta dan sumber terpercaya!",
  alternates: {
    canonical: "https://rusdimedia.com",
  },
}

export default async function Home() {
  // Generate schema.org structured data
  const websiteSchema = generateWebsiteSchema()

  return (
    <>
      {/* Add schema.org JSON-LD structured data */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }}></script>

      <div className="py-6">
        {/* Featured Posts */}
        <div>
          {/* @ts-ignore - Error boundaries aren't fully typed in React Server Components */}
          <React.Suspense
            fallback={
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-1 space-y-4">
                  {[...Array(2)].map((_, i) => (
                    <div key={`left-${i}`} className="aspect-[4/3] animate-pulse bg-gray-200 rounded-lg"></div>
                  ))}
                </div>
                <div className="md:col-span-1 aspect-[3/4] animate-pulse bg-gray-200 rounded-lg"></div>
                <div className="md:col-span-1 space-y-4">
                  {[...Array(2)].map((_, i) => (
                    <div key={`right-${i}`} className="aspect-[4/3] animate-pulse bg-gray-200 rounded-lg"></div>
                  ))}
                </div>
              </div>
            }
          >
            <FeaturedPosts />
          </React.Suspense>
        </div>

        {/* Move AdSense Banner below Trending Tags */}
        <div className="mt-6 mb-6">
          {/* Ad Banner */}
          <AdsBanner
            slot="6805010756"
            format="rectangle"
            className="bg-gray-50 min-h-[250px] w-full flex items-center justify-center border border-gray-200 rounded-md"
            lazyLoad={true}
          />
        </div>

        {/* Add Trending Tags section right after Featured Posts */}
        <div className="mt-4">
          {/* @ts-ignore */}
          <React.Suspense fallback={<div className="h-10 animate-pulse bg-gray-200 rounded-lg"></div>}>
            <TrendingTags />
          </React.Suspense>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-8 md:grid-cols-3">
          <div className="md:col-span-2">
            {/* Teknologi Videos Section - Moved above Politik */}
            <div>
              {/* @ts-ignore */}
              <React.Suspense fallback={<div className="h-96 animate-pulse bg-gray-200 rounded-lg"></div>}>
                <TeknologiVideos />
              </React.Suspense>
            </div>
            <AdComponent />
            <div>
              {/* @ts-ignore */}
              <React.Suspense fallback={<div className="h-64 animate-pulse bg-gray-200 rounded-lg"></div>}>
                <LatestPosts />
              </React.Suspense>
            </div>

            <div className="mt-8">
              {/* @ts-ignore */}
              <React.Suspense fallback={<div className="h-96 animate-pulse bg-gray-200 rounded-lg"></div>}>
                <KesehatanSection />
              </React.Suspense>
            </div>

            {/* Add Three Column Categories Section */}
            <div className="mt-8">
              {/* @ts-ignore */}
              <React.Suspense fallback={<div className="h-96 animate-pulse bg-gray-200 rounded-lg"></div>}>
                <ThreeColumnCategories
                  categories={[
                    { title: "Hukum", slug: "hukum" },
                    { title: "Bisnis", slug: "bisnis" },
                    { title: "Lifestyle", slug: "lifestyle" },
                  ]}
                  postsPerCategory={4}
                />
              </React.Suspense>
            </div>

            <div className="mt-8">
              {/* @ts-ignore */}
              <React.Suspense fallback={<div className="h-48 animate-pulse bg-gray-200 rounded-lg"></div>}>
                <CategorySection title="Politik" slug="politik" count={4} />
              </React.Suspense>
            </div>

            <div className="mt-8">
              {/* @ts-ignore */}
              <React.Suspense fallback={<div className="h-48 animate-pulse bg-gray-200 rounded-lg"></div>}>
                <CategorySection title="Ekonomi" slug="ekonomi" count={4} />
              </React.Suspense>
            </div>

            <div className="mt-8">
              {/* @ts-ignore */}
              <React.Suspense fallback={<div className="h-48 animate-pulse bg-gray-200 rounded-lg"></div>}>
                <TrendingPosts />
              </React.Suspense>
            </div>
          </div>

          <div>
            {/* @ts-ignore */}
            <React.Suspense fallback={<div className="h-96 animate-pulse bg-gray-200 rounded-lg"></div>}>
              <Sidebar />
            </React.Suspense>
          </div>
        </div>
      </div>
    </>
  )
}
