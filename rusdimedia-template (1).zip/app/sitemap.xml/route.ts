import { fetchPosts, fetchCategories, fetchTags } from "@/lib/api"

export const revalidate = 1800 // Revalidate every 30 minutes

export async function GET() {
  try {
    // Fetch data for sitemap with smaller batch size to avoid 400 errors
    const [posts, categories, tags] = await Promise.all([
      fetchPosts({ per_page: 100 }), // Reduced from 1000 to avoid API limits
      fetchCategories(),
      fetchTags(),
    ])

    // Base URL
    const baseUrl = "https://rusdimedia.com"

    // Create XML content
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${baseUrl}</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${baseUrl}/sitemap</loc>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${baseUrl}/tags</loc>
    <changefreq>daily</changefreq>
    <priority>0.7</priority>
  </url>
  ${categories
    .map(
      (category) => `
  <url>
    <loc>${baseUrl}/kategori/${category.slug}</loc>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
  </url>
  `,
    )
    .join("")}
  ${tags
    .map(
      (tag) => `
  <url>
    <loc>${baseUrl}/tags/${tag.slug}</loc>
    <changefreq>daily</changefreq>
    <priority>0.6</priority>
  </url>
  `,
    )
    .join("")}
  ${posts
    .map(
      (post) => `
  <url>
    <loc>${baseUrl}/${post.slug}</loc>
    <lastmod>${new Date(post.modified || post.date).toISOString()}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.7</priority>
  </url>
  `,
    )
    .join("")}
</urlset>`

    // Return XML response with shorter cache time for dynamic content
    return new Response(xml, {
      headers: {
        "Content-Type": "application/xml",
        "Cache-Control": "public, max-age=1800, s-maxage=3600, stale-while-revalidate=7200",
      },
    })
  } catch (error) {
    console.error("Error generating sitemap:", error)

    // Return a minimal sitemap with just the homepage in case of error
    const baseUrl = "https://rusdimedia.com"
    const fallbackXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${baseUrl}</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>`

    return new Response(fallbackXml, {
      headers: {
        "Content-Type": "application/xml",
        "Cache-Control": "public, max-age=1800, s-maxage=3600",
      },
    })
  }
}
