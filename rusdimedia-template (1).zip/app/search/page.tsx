import type { Metadata } from "next"
import { searchPosts } from "@/lib/api"
import { Shell } from "@/components/shell"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"
import SearchResultItem from "@/components/search-result-item"
import Link from "next/link"
import AdsBanner from "@/components/ads-banner"
import { generateCollectionPageSchema, generateBreadcrumbSchema } from "@/lib/schema"
import { Skeleton } from "@/components/ui/skeleton"
import SearchPagination from "@/components/search-pagination"

interface SearchPageProps {
  params: {}
  searchParams: {
    q?: string
    page?: string
  }
}

export async function generateMetadata({ searchParams }: SearchPageProps): Promise<Metadata> {
  const { q } = searchParams

  if (!q) {
    return {
      title: "Pencarian - Rusdimedia.com",
      description: "Cari artikel dan berita di Rusdimedia.com",
    }
  }

  return {
    title: `Hasil Pencarian: ${q} - Rusdimedia.com`,
    description: `Hasil pencarian untuk "${q}" di Rusdimedia.com`,
    robots: {
      index: false,
      follow: true,
    },
  }
}

export default async function SearchPage({ searchParams }: SearchPageProps) {
  const query = searchParams.q || ""
  const currentPage = searchParams.page ? Number.parseInt(searchParams.page) : 1
  const postsPerPage = 10

  // Generate breadcrumb schema
  const breadcrumbItems = [
    { name: "Beranda", url: "https://rusdimedia.com/" },
    { name: "Pencarian", url: "https://rusdimedia.com/search" },
  ]

  if (query) {
    breadcrumbItems.push({
      name: `Hasil untuk "${query}"`,
      url: `https://rusdimedia.com/search?q=${encodeURIComponent(query)}`,
    })
  }

  const breadcrumbSchema = generateBreadcrumbSchema(breadcrumbItems)
  const collectionPageSchema = generateCollectionPageSchema(
    query ? `Hasil Pencarian: ${query}` : "Pencarian",
    `https://rusdimedia.com/search${query ? `?q=${encodeURIComponent(query)}` : ""}`,
  )

  // If no query, show search form only
  if (!query) {
    return (
      <>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(collectionPageSchema) }} />

        <Shell>
          <div className="py-8 max-w-2xl mx-auto text-center">
            <h1 className="text-3xl font-bold mb-6">Pencarian</h1>
            <p className="text-gray-600 mb-8">Cari artikel dan berita di Rusdimedia.com</p>

            <form action="/search" method="get" className="relative mb-8">
              <Input
                type="text"
                name="q"
                placeholder="Cari artikel, berita, atau topik..."
                className="pl-10 py-3 text-lg"
                required
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <button
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-[#00acee] text-white px-4 py-1 rounded-md hover:bg-[#0096ce]"
              >
                Cari
              </button>
            </form>

            <div className="text-left">
              <h2 className="text-xl font-bold mb-4">Topik Populer</h2>
              <div className="flex flex-wrap gap-2">
                {["Politik", "Ekonomi", "Kesehatan", "Teknologi", "Olahraga", "Lifestyle", "Selebriti"].map((topic) => (
                  <Link
                    key={topic}
                    href={`/search?q=${topic}`}
                    className="bg-gray-100 hover:bg-gray-200 px-3 py-1 rounded-full text-sm"
                  >
                    {topic}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </Shell>
      </>
    )
  }

  // Fetch search results with pagination
  let searchResults = []
  let totalItems = 0

  try {
    // Get the search results for the current page
    const results = await searchPosts(query, currentPage, postsPerPage)
    searchResults = results.posts
    totalItems = results.total

    // If we're on a page with no results but totalItems > 0, redirect to page 1
    if (searchResults.length === 0 && totalItems > 0 && currentPage > 1) {
      return {
        redirect: {
          destination: `/search?q=${encodeURIComponent(query)}`,
          permanent: false,
        },
      }
    }
  } catch (error) {
    console.error("Error fetching search results:", error)
  }

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(collectionPageSchema) }} />

      <Shell>
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2">Hasil Pencarian</h1>
          <p className="text-gray-600">
            {searchResults.length > 0
              ? `Ditemukan ${totalItems} hasil untuk "${query}"`
              : `Tidak ada hasil untuk "${query}"`}
          </p>
        </div>

        <div className="mb-6">
          <form action="/search" method="get" className="relative">
            <Input
              type="text"
              name="q"
              defaultValue={query}
              placeholder="Cari artikel, berita, atau topik..."
              className="pl-10"
              required
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <button
              type="submit"
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-[#00acee] text-white px-3 py-1 rounded-md hover:bg-[#0096ce] text-sm"
            >
              Cari
            </button>
          </form>
        </div>

        {/* Ad Banner */}
        <div className="mb-6">
          <AdsBanner
            slot="6805010756"
            format="auto"
            responsive={true}
            className="bg-gray-50 min-h-[90px] w-full flex items-center justify-center border border-gray-200 rounded-md mx-auto"
            lazyLoad={true}
          />
        </div>

        {searchResults.length > 0 ? (
          <div className="space-y-6">
            {searchResults.map((post) => (
              <SearchResultItem key={post.id} post={post} query={query} />
            ))}
          </div>
        ) : (
          <div className="bg-gray-50 p-8 rounded-lg text-center">
            <h2 className="text-xl font-bold mb-2">Tidak ada hasil yang ditemukan</h2>
            <p className="text-gray-600 mb-4">
              Maaf, kami tidak dapat menemukan hasil yang sesuai dengan pencarian Anda.
            </p>
            <div className="mb-4">
              <h3 className="font-medium mb-2">Saran:</h3>
              <ul className="text-gray-600 list-disc list-inside text-left max-w-md mx-auto">
                <li>Periksa ejaan kata kunci Anda</li>
                <li>Coba gunakan kata kunci yang lebih umum</li>
                <li>Coba kurangi jumlah kata dalam pencarian</li>
                <li>Coba cari dengan topik yang terkait</li>
              </ul>
            </div>
            <Link href="/" className="inline-block bg-[#00acee] text-white px-4 py-2 rounded-md hover:bg-[#0096ce]">
              Kembali ke Beranda
            </Link>
          </div>
        )}

        {/* Pagination */}
        {searchResults.length > 0 && totalItems > postsPerPage && (
          <div className="mt-8">
            <SearchPagination
              currentPage={currentPage}
              totalItems={totalItems}
              itemsPerPage={postsPerPage}
              baseUrl={`/search?q=${encodeURIComponent(query)}`}
            />
          </div>
        )}

        {/* Ad Banner */}
        <div className="mt-8">
          <AdsBanner
            slot="6805010756"
            format="auto"
            responsive={true}
            className="bg-gray-50 min-h-[250px] w-full flex items-center justify-center border border-gray-200 rounded-md mx-auto"
            lazyLoad={true}
          />
        </div>
      </Shell>
    </>
  )
}

// Loading state component
export function SearchPageSkeleton() {
  return (
    <div className="space-y-6">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex flex-col md:flex-row gap-4 border-b border-gray-100 pb-6">
          <div className="md:w-1/4 flex-shrink-0">
            <Skeleton className="aspect-[16/9] w-full rounded-lg" />
          </div>
          <div className="md:w-3/4">
            <Skeleton className="h-4 w-24 mb-2" />
            <Skeleton className="h-6 w-full mb-2" />
            <Skeleton className="h-4 w-32 mb-2" />
            <Skeleton className="h-4 w-full mb-1" />
            <Skeleton className="h-4 w-full mb-1" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        </div>
      ))}
    </div>
  )
}
