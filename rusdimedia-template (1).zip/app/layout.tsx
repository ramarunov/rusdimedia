import React, { Suspense } from "react"
import { Quicksand } from "next/font/google"
import "./globals.css"
import Header from "@/components/header"
import Footer from "@/components/footer"
import BreakingNews from "@/components/breaking-news"
import type { Metadata } from "next"
import Script from "next/script"
import PerformanceMetrics from "./performance-metrics"
import { generateWebsiteSchema, generateBreadcrumbSchema, generateOrganizationSchema } from "@/lib/schema"
import StickySideAds from "@/components/sticky-side-ads"
import { Analytics } from "@vercel/analytics/next"
import { SpeedInsights } from "@vercel/speed-insights/next"

const quicksand = Quicksand({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  display: "swap", // Add display swap for better font loading
  preload: true, // Ensure font is preloaded
  fallback: ["system-ui", "sans-serif"], // Add fallback fonts
  adjustFontFallback: true, // Automatically adjust the font fallback
  variable: "--font-quicksand", // Add variable support
})

export const metadata: Metadata = {
  title: {
    template: "%s | Rusdimedia.com",
    default: "Rusdimedia.com - Berita Terkini, Gaya Hidup, Tips & Tricks",
  },
  description:
    "Baca berita dan informasi terbaru seputar politik, gaya hidup, tips dan trik hari ini hanya di Rusdi Media. Disajikan berdasarkan fakta dan sumber terpercaya!",
  metadataBase: new URL("https://rusdimedia.com"),
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  alternates: {
    canonical: "https://rusdimedia.com",
  },
  openGraph: {
    type: "website",
    locale: "id_ID",
    url: "https://rusdimedia.com",
    siteName: "Rusdimedia.com",
    title: "Rusdimedia.com - Berita Terkini, Gaya Hidup, Tips & Tricks",
    description:
      "Baca berita dan informasi terbaru seputar politik, gaya hidup, tips dan trik hari ini hanya di Rusdi Media.",
    images: [
      {
        url: "https://dash.rusdimedia.com/wp-content/uploads/2024/10/Dosa-Besar-dalam-Islam-e1744014973421.png",
        width: 1200,
        height: 630,
        alt: "Rusdimedia.com",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Rusdimedia.com - Berita Terkini, Gaya Hidup, Tips & Tricks",
    description:
      "Baca berita dan informasi terbaru seputar politik, gaya hidup, tips dan trik hari ini hanya di Rusdi Media.",
    images: ["https://dash.rusdimedia.com/wp-content/uploads/2024/10/Dosa-Besar-dalam-Islam-e1744014973421.png"],
  },
  verification: {
    google: "YOUR_GOOGLE_VERIFICATION_CODE", // Add your Google verification code
  },
  keywords: "berita terkini, gaya hidup, tips dan trik, politik, ekonomi, teknologi, kesehatan, rusdimedia",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // Generate schema.org JSON-LD structured data
  const websiteSchema = generateWebsiteSchema()
  const breadcrumbSchema = generateBreadcrumbSchema()
  const organizationSchema = generateOrganizationSchema()

  // Check if we're in a preview environment - moved to client component
  const isServerRendering = typeof window === "undefined"

  return (
    <html lang="id" className={`${quicksand.className} scroll-smooth`}>
      <head>
        {/* Favicon */}
        <link rel="icon" href="https://dash.rusdimedia.com/wp-content/uploads/2024/10/cropped-favicon-rusdi.png" />
        <link
          rel="apple-touch-icon"
          href="https://dash.rusdimedia.com/wp-content/uploads/2024/10/cropped-favicon-rusdi.png"
        />
        <link
          rel="shortcut icon"
          href="https://dash.rusdimedia.com/wp-content/uploads/2024/10/cropped-favicon-rusdi.png"
        />

        {/* Add these preload links in the head section */}
        <link rel="preload" href="/fonts/quicksand.woff2" as="font" type="font/woff2" crossOrigin="anonymous" />

        {/* Preload critical assets */}
        <link
          rel="preload"
          href="https://dash.rusdimedia.com/wp-content/uploads/2024/10/Dosa-Besar-dalam-Islam-e1744014973421.png"
          as="image"
          fetchPriority="high"
        />

        {/* Preconnect to API domain to speed up data fetching */}
        <link rel="preconnect" href="https://dash.rusdimedia.com" crossOrigin="anonymous" />
        <link rel="dns-prefetch" href="https://dash.rusdimedia.com" />

        {/* Preconnect to ad services */}
        <link rel="preconnect" href="https://pagead2.googlesyndication.com" crossOrigin="anonymous" />
        <link rel="preconnect" href="https://googleads.g.doubleclick.net" crossOrigin="anonymous" />
        <link rel="preconnect" href="https://www.googletagservices.com" crossOrigin="anonymous" />

        {/* Schema.org structured data */}
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }}></script>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
        ></script>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
        ></script>
      </head>
      <body className={`${quicksand.className} min-h-screen font-sans antialiased`}>
        <PerformanceMetrics />
        <Analytics />
        <SpeedInsights />
        <div className="flex min-h-screen flex-col">
          <Header />
          {/* Wrap BreakingNews in Suspense */}
          <React.Suspense fallback={<div className="h-10 bg-gray-100"></div>}>
            <BreakingNews />
          </React.Suspense>
          <main className="flex-1">
            {/* Add sticky side ads - removed conditional rendering */}
            {!isServerRendering && <StickySideAds />}

            {/* Add padding to main content on desktop to make room for ads */}
            <div className="mx-auto w-full max-w-[1080px] px-4">
              {/* Wrap in Suspense to prevent page blocking */}
              <Suspense
                fallback={
                  <div className="min-h-screen flex items-center justify-center">
                    <div className="animate-pulse h-16 w-16 bg-gray-200 rounded-full"></div>
                  </div>
                }
              >
                {children}
              </Suspense>
            </div>
          </main>
          <Footer />
        </div>

        {/* Load scripts at the end of the body - REMOVED onError handler */}
        <Script
          id="google-analytics"
          strategy="afterInteractive"
          src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"
        />
        <Script id="google-analytics-config" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-XXXXXXXXXX');
          `}
        </Script>
        <Script
          id="adsense-script-main"
          strategy="lazyOnload"
          src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7609031768696978"
          crossOrigin="anonymous"
        />
      </body>
    </html>
  )
}
