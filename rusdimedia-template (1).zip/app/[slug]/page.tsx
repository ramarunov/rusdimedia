import { fetchPostBySlug, fetchPosts } from "@/lib/api"
import type { Metadata } from "next"
import { notFound } from "next/navigation"
import { getExcerpt, formatDate, stripHtmlTags } from "@/lib/utils"
import Link from "next/link"
import OptimizedImage from "@/components/optimized-image"
import RelatedPosts from "@/components/related-posts"
import Sidebar from "@/components/sidebar"
import AdsBanner from "@/components/ads-banner"
import PostComments from "@/components/post-comments"
import React from "react"
import { generateArticleSchema, generateBreadcrumbSchema } from "@/lib/schema"
import { ExternalLink } from "lucide-react"
import HeaderBannerAd from "@/components/header-banner-ad"

interface PostPageProps {
  params: {
    slug: string
  }
}

export async function generateMetadata({ params }: PostPageProps): Promise<Metadata> {
  const post = await fetchPostBySlug(params.slug)

  if (!post) {
    return {
      title: "Post Not Found - Rusdimedia.com",
      description: "The requested post could not be found.",
    }
  }

  const title = stripHtmlTags(post.title.rendered)
  const description = getExcerpt(post.excerpt.rendered, 160)
  const category = post._embedded?.["wp:term"]?.[0]?.[0]
  const categoryName = category ? category.name : ""

  // Get tags for keywords
  const tags = post._embedded?.["wp:term"]?.[1] || []
  const keywords = tags.map((tag: any) => tag.name).join(", ")

  return {
    title: title,
    description,
    keywords: keywords,
    alternates: {
      canonical: `https://rusdimedia.com/${post.slug}`,
    },
    openGraph: {
      title,
      description,
      type: "article",
      publishedTime: post.date,
      modifiedTime: post.modified || post.date,
      url: `https://rusdimedia.com/${post.slug}`,
      images: post._embedded?.["wp:featuredmedia"]?.[0]?.source_url
        ? [
            {
              url: post._embedded["wp:featuredmedia"][0].source_url,
              alt: post._embedded["wp:featuredmedia"][0].alt_text || title,
            },
          ]
        : [],
      siteName: "Rusdimedia.com",
      locale: "id_ID",
      authors: ["Rusdimedia.com"],
      section: categoryName,
      tags: tags.map((tag: any) => tag.name),
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: post._embedded?.["wp:featuredmedia"]?.[0]?.source_url
        ? [post._embedded["wp:featuredmedia"][0].source_url]
        : [],
    },
  }
}

export default async function PostPage({ params }: PostPageProps) {
  // Fetch post data
  const post = await fetchPostBySlug(params.slug)

  if (!post) {
    notFound()
  }

  // Get category if available
  const category = post._embedded?.["wp:term"]?.[0]?.[0]

  // Get tags if available
  const tags = post._embedded?.["wp:term"]?.[1] || []

  // Format the date for display
  const formattedDate = formatDate(post.date)

  // Get featured image
  const featuredImage = post._embedded?.["wp:featuredmedia"]?.[0]
  const imageUrl = featuredImage?.source_url || ""
  const imageAlt = featuredImage?.alt_text || stripHtmlTags(post.title.rendered)

  // Generate article schema
  const articleSchema = generateArticleSchema(post)

  // Generate breadcrumb schema
  const breadcrumbItems = [{ name: "Beranda", url: "https://rusdimedia.com/" }]

  if (category) {
    breadcrumbItems.push({
      name: category.name,
      url: `https://rusdimedia.com/kategori/${category.slug}`,
    })
  }

  breadcrumbItems.push({
    name: stripHtmlTags(post.title.rendered),
    url: `https://rusdimedia.com/${post.slug}`,
  })

  const breadcrumbSchema = generateBreadcrumbSchema(breadcrumbItems)

  // Fetch related articles based on tags
  let relatedArticles = []
  if (tags.length > 0) {
    try {
      // Get tag IDs from the current post
      const currentPostTagIds = tags.map((tag: any) => tag.id)

      const posts = await fetchPosts({
        per_page: 10, // Fetch more posts to increase chances of finding matches
        _embed: true,
      })

      // Filter out the current post and posts without featured images
      // Then filter to only include posts that share at least one tag with the current post
      relatedArticles = posts
        .filter((p) => p.id !== post.id)
        .filter((p) => p._embedded?.["wp:featuredmedia"]?.[0]?.source_url)
        .filter((p) => {
          // Get the tags of this post
          const postTags = p._embedded?.["wp:term"]?.[1] || []
          const postTagIds = postTags.map((tag: any) => tag.id)

          // Check if this post shares at least one tag with the current post
          return postTagIds.some((tagId: number) => currentPostTagIds.includes(tagId))
        })
        .slice(0, 3) // Still get up to 3 in case we need fallbacks
    } catch (error) {
      console.error("Error fetching related articles:", error)
    }
  }

  // Split content to insert ads and related articles
  const contentParts = {
    firstParagraph: "",
    beforeRelated: "",
    afterRelated: "",
  }

  // Process the content to insert ads and related articles
  if (post.content && post.content.rendered) {
    const paragraphs = post.content.rendered.split("</p>")

    // Extract first paragraph for the ad insertion
    if (paragraphs.length > 0) {
      contentParts.firstParagraph = paragraphs[0] + "</p>"

      // For related articles insertion (after 3rd paragraph)
      if (paragraphs.length > 3 && relatedArticles.length > 0) {
        const insertPosition = 3
        contentParts.beforeRelated = paragraphs.slice(1, insertPosition).join("</p>") + "</p>"
        contentParts.afterRelated = paragraphs.slice(insertPosition).join("</p>")

        // Make sure we don't lose the closing tag if it exists
        if (!contentParts.afterRelated.endsWith("</p>") && paragraphs.length > insertPosition) {
          contentParts.afterRelated += "</p>"
        }
      } else {
        // If we don't have enough paragraphs or no related articles,
        // put all remaining content in afterRelated
        contentParts.afterRelated = paragraphs.slice(1).join("</p>")

        // Make sure we don't lose the closing tag
        if (!contentParts.afterRelated.endsWith("</p>") && paragraphs.length > 1) {
          contentParts.afterRelated += "</p>"
        }
      }
    } else {
      // If splitting didn't work, just use the whole content
      contentParts.afterRelated = post.content.rendered
    }
  }

  const paragraphs = post.content.rendered.split("</p>")

  return (
    <>
      {/* Add schema.org JSON-LD structured data */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />

      <div className="py-4 md:py-6 min-h-[800px] w-full max-w-[1080px] mx-auto">
        {/* Breadcrumb */}
        <div className="mb-4 text-sm text-gray-500">
          <div className="flex items-center gap-2">
            <Link href="/" className="hover:text-[#00acee]">
              Beranda
            </Link>
            <span>/</span>
            {category && (
              <>
                <Link href={`/kategori/${category.slug}`} className="hover:text-[#00acee]">
                  {category.name}
                </Link>
                <span>/</span>
              </>
            )}
            <span className="truncate max-w-[200px]" title={stripHtmlTags(post.title.rendered)}>
              {stripHtmlTags(post.title.rendered)}
            </span>
          </div>
        </div>

        {/* Header Banner Ad - Only on single post pages */}
        <div className="mb-6">
          <HeaderBannerAd />
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          <article className="md:col-span-2">
            {/* Article Header */}
            <header className="mb-4">
              <h1
                className="mb-3 text-2xl font-bold leading-tight md:text-3xl"
                dangerouslySetInnerHTML={{ __html: post.title.rendered }}
              />
              <div className="mb-4 flex items-center text-sm text-gray-500">
                <time dateTime={post.date}>{formattedDate}</time>
                {post.modified && post.modified !== post.date && (
                  <span className="ml-2">(Diperbarui: {formatDate(post.modified)})</span>
                )}
              </div>
              {/* Category display */}
              {category && (
                <div className="mb-3">
                  <Link
                    href={`/kategori/${category.slug}`}
                    className="inline-block bg-[#00acee] text-white text-sm font-medium px-3 py-1 rounded-md hover:bg-[#0096ce]"
                  >
                    {category.name}
                  </Link>
                </div>
              )}

              {/* Author info */}
              <div className="mb-4 flex items-center">
                <div className="mr-3 h-10 w-10 overflow-hidden rounded-full bg-gray-200">
                  <div className="flex h-full w-full items-center justify-center bg-[#00acee] text-white">SW</div>
                </div>
                <div>
                  <div className="font-medium">Ghallaby Zasy</div>
                  <div className="text-xs text-gray-500">Rusdimedia.com</div>
                </div>
              </div>

              {/* Social Share Buttons */}
              <div className="mb-6 flex flex-wrap items-center gap-2">
                <span className="text-sm font-medium text-gray-700">Bagikan:</span>

                {/* WhatsApp */}
                <a
                  href={`https://api.whatsapp.com/send?text=${encodeURIComponent(stripHtmlTags(post.title.rendered))} - https://rusdimedia.com/${post.slug}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 rounded-md bg-[#25D366] px-3 py-1.5 text-sm font-medium text-white hover:bg-opacity-90"
                  aria-label="Share on WhatsApp"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                  </svg>
                  <span>WhatsApp</span>
                </a>

                {/* Facebook */}
                <a
                  href={`https://www.facebook.com/sharer/sharer.php?u=https://rusdimedia.com/${post.slug}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 rounded-md bg-[#1877F2] px-3 py-1.5 text-sm font-medium text-white hover:bg-opacity-90"
                  aria-label="Share on Facebook"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z" />
                  </svg>
                  <span>Facebook</span>
                </a>

                {/* Twitter/X */}
                <a
                  href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(stripHtmlTags(post.title.rendered))}&url=https://rusdimedia.com/${post.slug}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 rounded-md bg-black px-3 py-1.5 text-sm font-medium text-white hover:bg-opacity-90"
                  aria-label="Share on Twitter/X"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                  </svg>
                  <span>Twitter</span>
                </a>

                {/* LinkedIn */}
                <a
                  href={`https://www.linkedin.com/sharing/share-offsite/?url=https://rusdimedia.com/${post.slug}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 rounded-md bg-[#0077B5] px-3 py-1.5 text-sm font-medium text-white hover:bg-opacity-90"
                  aria-label="Share on LinkedIn"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                  >
                    <path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0v8.399h4.988v-10.131c0-7.88-8.922-7.593-11.018-3.714v-2.155z" />
                  </svg>
                  <span>LinkedIn</span>
                </a>
              </div>
            </header>

            {/* Featured Image */}
            {imageUrl && (
              <figure className="mb-6">
                <div className="aspect-[16/9] relative overflow-hidden rounded-lg">
                  <OptimizedImage
                    src={imageUrl}
                    alt={imageAlt}
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, 66vw"
                    priority
                    quality={85}
                  />
                </div>
                {featuredImage?.caption?.rendered && (
                  <figcaption className="mt-2 text-center text-sm text-gray-500">
                    <div dangerouslySetInnerHTML={{ __html: featuredImage.caption.rendered }} />
                  </figcaption>
                )}
              </figure>
            )}

            {/* First Paragraph */}
            {contentParts.firstParagraph && (
              <div className="article-content mb-4">
                <div
                  dangerouslySetInnerHTML={{ __html: contentParts.firstParagraph }}
                  className="[&_ul]:list-disc [&_ul]:ml-6 [&_ol]:list-decimal [&_ol]:ml-6 [&_li]:my-1"
                />
              </div>
            )}

            {/* Ad Banner after first paragraph */}
            <div className="my-6">
              <AdsBanner
                slot="6805010756"
                format="auto"
                responsive={true}
                className="bg-gray-50 min-h-[90px] w-full flex items-center justify-center border border-gray-200 rounded-md mx-auto"
              />
            </div>

            {/* Content before related articles */}
            {contentParts.beforeRelated && (
              <div className="article-content mb-4">
                <div
                  dangerouslySetInnerHTML={{ __html: contentParts.beforeRelated }}
                  className="[&_ul]:list-disc [&_ul]:ml-6 [&_ol]:list-decimal [&_ol]:ml-6 [&_li]:my-1"
                />
              </div>
            )}

            {/* Inline Related Articles - only show if we have related articles and enough paragraphs */}
            {paragraphs.length > 4 && relatedArticles.length > 0 && (
              <div className="my-6">
                <h4 className="mb-3 text-base font-bold">Artikel Terkait:</h4>
                <div>
                  {/* Only show the first related article */}
                  {relatedArticles.slice(0, 1).map((article) => (
                    <div
                      key={article.id}
                      className="group flex items-center gap-3 rounded-md border border-gray-200 p-2 hover:bg-gray-50"
                    >
                      <div className="relative h-16 w-24 flex-shrink-0 overflow-hidden rounded">
                        {article._embedded?.["wp:featuredmedia"]?.[0]?.source_url && (
                          <OptimizedImage
                            src={article._embedded["wp:featuredmedia"][0].source_url}
                            alt={article._embedded["wp:featuredmedia"][0].alt_text || article.title.rendered}
                            fill
                            className="object-cover"
                            sizes="96px"
                            quality={70}
                          />
                        )}
                      </div>
                      <div className="flex-1">
                        <h5 className="text-sm font-medium leading-tight group-hover:text-[#00acee]">
                          <Link href={`/${article.slug}`}>
                            <span dangerouslySetInnerHTML={{ __html: article.title.rendered }} />
                          </Link>
                        </h5>
                        <div className="mt-1 flex items-center text-xs text-gray-500">
                          <span>Artikel Rusdimedia</span>
                          <ExternalLink className="ml-1 h-3 w-3" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Content after related articles */}
            {contentParts.afterRelated && (
              <div className="article-content mb-8">
                <div
                  dangerouslySetInnerHTML={{ __html: contentParts.afterRelated }}
                  className="[&_ul]:list-disc [&_ul]:ml-6 [&_ol]:list-decimal [&_ol]:ml-6 [&_li]:my-1"
                />
              </div>
            )}

            {/* WhatsApp Channel Button */}
            <div className="mb-8 flex justify-center">
              <a
                href="https://whatsapp.com/channel/0029Vb8EzWY1dAw1ZeNtC30d"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 rounded-lg bg-[#25D366] px-6 py-3 text-white hover:bg-[#128C7E] transition-colors"
              >
                <img
                  src="https://static-00.iconduck.com/assets.00/whatsapp-icon-2040x2048-8b5th74o.png"
                  alt="WhatsApp Icon"
                  className="h-6 w-6"
                />
                <span className="font-medium">Ikuti Kami di Saluran WhatsApp</span>
              </a>
            </div>

            {/* Tags */}
            {tags.length > 0 && (
              <div className="mb-8 flex flex-wrap gap-2">
                {tags.map((tag: any) => (
                  <Link
                    key={tag.id}
                    href={`/tags/${tag.slug}`}
                    className="rounded-full bg-gray-100 px-3 py-1 text-sm hover:bg-gray-200"
                  >
                    #{tag.name}
                  </Link>
                ))}
              </div>
            )}

            {/* Ad Banner */}
            <div className="mb-8">
              <AdsBanner
                slot="6805010756"
                format="auto"
                responsive={true}
                className="bg-gray-50 min-h-[250px] w-full flex items-center justify-center border border-gray-200 rounded-md mx-auto"
                lazyLoad={true}
              />
            </div>

            {/* Comments Section */}
            <PostComments postId={post.id} postTitle={post.title.rendered} />
            {/* Ad Banner */}
            <div className="mb-8">
              <AdsBanner
                slot="6805010756"
                format="auto"
                responsive={true}
                className="bg-gray-50 min-h-[250px] w-full flex items-center justify-center border border-gray-200 rounded-md mx-auto"
                lazyLoad={true}
              />
            </div>
            {/* Related Posts Section */}
            <div className="mt-8">
              <RelatedPosts categoryId={category?.id} currentPostId={post.id} />
            </div>
          </article>

          {/* Sidebar */}
          <aside className="md:col-span-1">
            <React.Suspense fallback={<div className="h-96 animate-pulse bg-gray-200 rounded-lg"></div>}>
              <Sidebar />
            </React.Suspense>
          </aside>
        </div>
      </div>
    </>
  )
}
