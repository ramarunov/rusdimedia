"use client"

import { fetchPostsByCategory } from "@/lib/api"
import Link from "next/link"
import { formatDate } from "@/lib/utils"
import RelatedPosts from "@/components/related-posts"
import OptimizedImage from "@/components/optimized-image"
import Sidebar from "@/components/sidebar"
import React, { useState, useEffect } from "react"
import { Share2, MessageSquare, ThumbsUp, Bookmark } from "lucide-react"
import AdsBanner from "@/components/ads-banner"
import PostComments from "@/components/post-comments"

interface PostPageClientProps {
  post: any // Post data passed from server component
}

// Helper function to strip HTML tags
function stripHtmlTags(html: string): string {
  return html.replace(/<[^>]*>/g, "")
}

export default function PostPageClient({ post }: PostPageClientProps) {
  const [category, setCategory] = useState<any>(null)
  const [tags, setTags] = useState<any[]>([])
  const [relatedPosts, setRelatedPosts] = useState<any[]>([])
  const [formattedDate, setFormattedDate] = useState("")
  const [imageUrl, setImageUrl] = useState("")
  const [imageAlt, setImageAlt] = useState("")

  useEffect(() => {
    const initializeData = async () => {
      try {
        // Get category if available
        const fetchedCategory = post._embedded?.["wp:term"]?.[0]?.[0]
        setCategory(fetchedCategory)

        // Get tags if available
        const fetchedTags = post._embedded?.["wp:term"]?.[1] || []
        setTags(fetchedTags)

        // Get related posts
        if (fetchedCategory) {
          try {
            const fetchedPosts = await fetchPostsByCategory(fetchedCategory.slug, 3)
            // Filter out the current post
            const filteredRelatedPosts = fetchedPosts.filter((p) => p.id !== post.id).slice(0, 2)
            setRelatedPosts(filteredRelatedPosts)
          } catch (error) {
            console.error("Error fetching related posts:", error)
          }
        }

        // Format the date for display
        setFormattedDate(formatDate(post.date))

        // Get featured image
        const featuredImage = post._embedded?.["wp:featuredmedia"]?.[0]
        setImageUrl(featuredImage?.source_url || "")
        setImageAlt(featuredImage?.alt_text || stripHtmlTags(post.title.rendered))
      } catch (error) {
        console.error("Error initializing post data:", error)
      }
    }

    initializeData()
  }, [post])

  return (
    <div className="py-4 md:py-6">
      {/* Breadcrumb */}
      <div className="mb-4 text-sm text-gray-500">
        <div className="flex items-center gap-2">
          <Link href="/" className="hover:text-[#00acee]">
            Beranda
          </Link>
          <span>/</span>
          {category && (
            <>
              <Link href={`/kategori/${category.slug}`} className="hover:text-[#00acee]">
                {category.name}
              </Link>
              <span>/</span>
            </>
          )}
          <span className="truncate max-w-[200px]" title={stripHtmlTags(post.title.rendered)}>
            {stripHtmlTags(post.title.rendered)}
          </span>
        </div>
      </div>
      {/* Ad Banner */}
      <div className="mb-8">
        <AdsBanner
          slot="6805010756"
          format="auto"
          responsive={true}
          className="bg-gray-50 min-h-[250px] w-full flex items-center justify-center border border-gray-200 rounded-md mx-auto"
          lazyLoad={true}
        />
      </div>
      <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
        <article className="md:col-span-2">
          {/* Article Header */}
          <header className="mb-4">
            <h1
              className="mb-3 text-2xl font-bold leading-tight md:text-3xl"
              dangerouslySetInnerHTML={{ __html: post.title.rendered }}
            />

            <div className="mb-4 flex items-center text-sm text-gray-500">
              <time dateTime={post.date}>{formattedDate}</time>
              {post.modified && post.modified !== post.date && (
                <span className="ml-2">(Diperbarui: {formatDate(post.modified)})</span>
              )}
            </div>

            {/* Author info */}
            <div className="mb-4 flex items-center">
              <div className="mr-3 h-10 w-10 overflow-hidden rounded-full bg-gray-200">
                <div className="flex h-full w-full items-center justify-center bg-[#00acee] text-white">R</div>
              </div>
              <div>
                <div className="font-medium">Ghallaby Zasy</div>
                <div className="text-xs text-gray-500">Rusdimedia.com</div>
              </div>
            </div>

            {/* Social sharing */}
            <div className="mb-4 flex items-center space-x-4">
              <button className="flex items-center justify-center rounded-full p-2 hover:bg-gray-100" aria-label="Like">
                <ThumbsUp className="h-5 w-5 text-gray-500" />
              </button>
              <button
                className="flex items-center justify-center rounded-full p-2 hover:bg-gray-100"
                aria-label="Comment"
              >
                <MessageSquare className="h-5 w-5 text-gray-500" />
              </button>
              <button
                className="flex items-center justify-center rounded-full p-2 hover:bg-gray-100"
                aria-label="Share"
              >
                <Share2 className="h-5 w-5 text-gray-500" />
              </button>
              <button className="flex items-center justify-center rounded-full p-2 hover:bg-gray-100" aria-label="Save">
                <Bookmark className="h-5 w-5 text-gray-500" />
              </button>
            </div>
          </header>

          {/* Featured Image */}
          {imageUrl && (
            <figure className="mb-6">
              <div className="aspect-[16/9] relative overflow-hidden rounded-lg">
                <OptimizedImage
                  src={imageUrl}
                  alt={imageAlt}
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 66vw"
                  priority
                  quality={85}
                />
              </div>
              {post._embedded?.["wp:featuredmedia"]?.[0]?.caption?.rendered && (
                <figcaption className="mt-2 text-center text-sm text-gray-500">
                  <div dangerouslySetInnerHTML={{ __html: post._embedded["wp:featuredmedia"][0].caption.rendered }} />
                </figcaption>
              )}
            </figure>
          )}

          {/* Article Content */}
          <div className="article-content mb-8">
            <style jsx global>{`
              .article-content {
                overflow-hidden;
                word-wrap: break-word;
              }
              .article-content h1, 
              .article-content h2, 
              .article-content h3, 
              .article-content h4, 
              .article-content h5, 
              .article-content h6 {
                font-weight: bold;
                margin-top: 1.5em;
                margin-bottom: 0.75em;
                line-height: 1.2;
              }
              .article-content h1 {
                font-size: 1.875rem;
              }
              .article-content h2 {
                font-size: 1.5rem;
              }
              .article-content h3 {
                font-size: 1.25rem;
              }
              .article-content h4 {
                font-size: 1.125rem;
              }
              .article-content p {
                margin-bottom: 1rem;
                line-height: 1.7;
              }
              .article-content p:last-child {
                margin-bottom: 0;
              }
              .article-content ul, 
              .article-content ol {
                margin-bottom: 1rem;
                padding-left: 1.5rem;
              }
              .article-content li {
                margin-bottom: 0.5rem;
              }
              .article-content a {
                color: #00acee;
                text-decoration: none;
              }
              .article-content a:hover {
                text-decoration: underline;
              }
              .article-content img {
                border-radius: 0.375rem;
                margin: 1.5rem 0;
                max-width: 100%;
                height: auto;
              }
              .article-content blockquote {
                margin: 1.5rem 0;
                padding-left: 1rem;
                border-left: 4px solid #00acee;
                font-style: italic;
                color: #4b5563;
              }
              .article-content hr {
                margin: 2rem 0;
                border: 0;
                border-top: 1px solid #e5e7eb;
              }
              .article-content table {
                width: 100%;
                border-collapse: collapse;
                margin: 1.5rem 0;
              }
              .article-content thead {
                background-color: #f3f4f6;
              }
              .article-content th {
                padding: 0.5rem;
                text-align: left;
                font-weight: 600;
              }
              .article-content td {
                padding: 0.5rem;
                border: 1px solid #d1d5db;
              }
              .article-content figure {
                margin: 1.5rem 0;
              }
              .article-content figcaption {
                text-align: center;
                font-size: 0.875rem;
                color: #6b7280;
                margin-top: 0.5rem;
              }
              .article-content pre {
                background-color: #1f2937;
                color: #f9fafb;
                padding: 1rem;
                border-radius: 0.375rem;
                overflow-x: auto;
                margin: 1.5rem 0;
              }
              .article-content code {
                background-color: #f3f4f6;
                padding: 0.25rem 0.5rem;
                border-radius: 0.25rem;
                font-family: monospace;
              }
              .article-content pre code {
                background-color: transparent;
                padding: 0;
              }
              .article-content iframe {
                max-width: 100%;
                margin: 1.5rem 0;
              }
            `}</style>
            <div dangerouslySetInnerHTML={{ __html: post.content.rendered }} />
          </div>

          {/* Tags */}
          {tags.length > 0 && (
            <div className="mb-8 flex flex-wrap gap-2">
              {tags.map((tag: any) => (
                <Link
                  key={tag.id}
                  href={`/tags/${tag.slug}`}
                  className="rounded-full bg-gray-100 px-3 py-1 text-sm hover:bg-gray-200"
                >
                  #{tag.name}
                </Link>
              ))}
            </div>
          )}

          {/* Ad Banner */}
          <div className="mb-8">
            <AdsBanner
              slot="6805010756"
              format="auto"
              responsive={true}
              className="bg-gray-50 min-h-[250px] w-full flex items-center justify-center border border-gray-200 rounded-md mx-auto"
              lazyLoad={true}
            />
          </div>

          {/* Related Articles - Horizontal Cards */}
          {relatedPosts.length > 0 && (
            <div className="mb-8">
              <h3 className="mb-4 text-lg font-bold">Baca Juga:</h3>
              <div className="space-y-4">
                {relatedPosts.map((relatedPost) => (
                  <div key={relatedPost.id} className="border-b border-gray-100 pb-4 last:border-0">
                    <Link href={`/${relatedPost.slug}`} className="group flex gap-4">
                      <div className="relative h-20 w-32 flex-shrink-0 overflow-hidden rounded">
                        {relatedPost._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                          <OptimizedImage
                            src={relatedPost._embedded["wp:featuredmedia"][0].source_url}
                            alt={relatedPost._embedded["wp:featuredmedia"][0].alt_text || relatedPost.title.rendered}
                            fill
                            loading="lazy"
                            className="object-cover transition-transform duration-300 group-hover:scale-105"
                            sizes="128px"
                            quality={70}
                          />
                        ) : (
                          <div className="h-full w-full bg-gray-300" />
                        )}
                      </div>
                      <div>
                        <h4
                          className="font-medium leading-tight group-hover:text-[#00acee]"
                          dangerouslySetInnerHTML={{ __html: relatedPost.title.rendered }}
                        />
                      </div>
                    </Link>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Comments Section */}
          <PostComments postId={post.id} postTitle={post.title.rendered} />
          {/* Ad Banner */}
          <div className="mb-8">
            <AdsBanner
              slot="6805010756"
              format="auto"
              responsive={true}
              className="bg-gray-50 min-h-[250px] w-full flex items-center justify-center border border-gray-200 rounded-md mx-auto"
              lazyLoad={true}
            />
          </div>
          {/* Related Posts Section */}
          <div className="mt-8">
            <RelatedPosts categoryId={category?.id} currentPostId={post.id} />
          </div>
        </article>

        {/* Sidebar */}
        <aside className="md:col-span-1">
          <React.Suspense fallback={<div className="h-96 animate-pulse bg-gray-200 rounded-lg"></div>}>
            <Sidebar />
          </React.Suspense>
        </aside>
      </div>
    </div>
  )
}
