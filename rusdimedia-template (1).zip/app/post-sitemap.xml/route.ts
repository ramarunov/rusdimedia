export const revalidate = 1800 // Revalidate every 30 minutes

// Direct API fetch instead of using the fetchPosts function that might have client dependencies
async function fetchPostsDirectly(page = 1, perPage = 100) {
  try {
    const response = await fetch(
      `https://dash.rusdimedia.com/wp-json/wp/v2/posts?page=${page}&per_page=${perPage}`,
      { next: { revalidate: 3600 } }, // Cache for 1 hour
    )

    if (!response.ok) {
      throw new Error(`Failed to fetch posts: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error fetching posts:", error)
    return []
  }
}

export async function GET() {
  try {
    // Initialize variables for pagination
    let allPosts = []
    let page = 1
    const perPage = 100 // WordPress API typically limits to 100 per page
    let hasMorePosts = true
    const maxPages = 10 // Limit to 10 pages (1000 posts) to prevent excessive requests

    // Fetch posts with pagination
    while (hasMorePosts && page <= maxPages) {
      const posts = await fetchPostsDirectly(page, perPage)

      if (!posts || posts.length === 0) {
        hasMorePosts = false
      } else {
        allPosts = [...allPosts, ...posts]
        page++
      }
    }

    console.log(`Fetched ${allPosts.length} posts for sitemap`)

    // Base URL
    const baseUrl = "https://rusdimedia.com"

    // Create XML content
    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">
${allPosts
  .map((post) => {
    // Format the date for the news sitemap (YYYY-MM-DD)
    const pubDate = new Date(post.date)
    const formattedPubDate = pubDate.toISOString().split("T")[0]

    // Escape special characters in title
    const escapedTitle = post.title.rendered
      .replace(/<[^>]*>/g, "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;")

    return `  <url>
    <loc>${baseUrl}/${post.slug}</loc>
    <lastmod>${new Date(post.modified || post.date).toISOString()}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.8</priority>
    <news:news>
      <news:publication>
        <news:name>Rusdimedia.com</news:name>
        <news:language>id</news:language>
      </news:publication>
      <news:publication_date>${formattedPubDate}</news:publication_date>
      <news:title>${escapedTitle}</news:title>
    </news:news>
  </url>`
  })
  .join("\n")}
</urlset>`

    // Return XML response with proper headers
    return new Response(xml, {
      headers: {
        "Content-Type": "application/xml",
        "Cache-Control": "public, max-age=1800, s-maxage=3600, stale-while-revalidate=7200",
      },
    })
  } catch (error) {
    console.error("Error generating post sitemap:", error)
    return new Response("Error generating sitemap", { status: 500 })
  }
}
