"use client"

import { useEffect } from "react"

// Simple implementation of core web vitals without external dependencies
export default function PerformanceMetrics() {
  useEffect(() => {
    // Only run on client side
    if (typeof window === "undefined") return

    // Wait for the page to be fully loaded
    if (document.readyState !== "complete") {
      window.addEventListener("load", initPerformanceMetrics)
      return () => window.removeEventListener("load", initPerformanceMetrics)
    } else {
      initPerformanceMetrics()
    }

    function initPerformanceMetrics() {
      // Basic performance metrics using the Performance API
      setTimeout(() => {
        if (window.performance) {
          // Get navigation timing
          const navTiming = performance.getEntriesByType("navigation")[0] as PerformanceNavigationTiming
          if (navTiming) {
            // Time to First Byte (TTFB)
            const ttfb = Math.round(navTiming.responseStart)
            logMetric("TTFB", ttfb)

            // Document Load Time
            const loadTime = Math.round(navTiming.loadEventEnd - navTiming.loadEventStart)
            logMetric("Load", loadTime)

            // DOM Content Loaded
            const dcl = Math.round(navTiming.domContentLoadedEventEnd - navTiming.domContentLoadedEventStart)
            logMetric("DCL", dcl)
          }

          // Get paint timing
          const paintMetrics = performance.getEntriesByType("paint")
          paintMetrics.forEach((entry) => {
            if (entry.name === "first-paint") {
              logMetric("FP", Math.round(entry.startTime))
            }
            if (entry.name === "first-contentful-paint") {
              logMetric("FCP", Math.round(entry.startTime))
            }
          })
        }
      }, 1000) // Delay to ensure metrics are available
    }

    function logMetric(name: string, value: number) {
      console.log(`Performance Metric: ${name}`, { value })

      // In production, you could send this data to an analytics endpoint
      // Example:
      // if (process.env.NODE_ENV === "production") {
      //   fetch("/api/analytics", {
      //     method: "POST",
      //     body: JSON.stringify({ name, value }),
      //     headers: { "Content-Type": "application/json" }
      //   }).catch(err => console.error("Failed to send metric:", err))
      // }
    }
  }, [])

  return null
}
