/**
 * Utility functions for environment detection
 */

/**
 * Checks if the current environment is a preview environment
 * This includes Vercel preview deployments, localhost, and v0 preview environments
 */
export function isPreviewEnvironment(): boolean {
  if (typeof window === "undefined") {
    // Server-side - can't determine, default to false
    return false
  }

  const hostname = window.location.hostname
  return (
    hostname.includes("vusercontent.net") ||
    hostname.includes("localhost") ||
    hostname.includes("vercel.app") ||
    hostname.includes("preview")
  )
}

/**
 * Checks if the current environment is production
 */
export function isProduction(): boolean {
  if (typeof window === "undefined") {
    // Server-side - check environment variables
    return process.env.NODE_ENV === "production" && process.env.NEXT_PUBLIC_VERCEL_ENV === "production"
  }

  // Client-side - check hostname
  return !isPreviewEnvironment() && window.location.hostname === "rusdimedia.com"
}
