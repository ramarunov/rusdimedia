// Check if we're in a preview environment
export function isPreviewEnvironment(): boolean {
  if (typeof window === "undefined") return false

  const hostname = window.location.hostname
  return hostname.includes("vusercontent.net") || hostname.includes("localhost") || hostname.includes("vercel.app")
}

// Check if AdSense is loaded
export function isAdSenseLoaded(): boolean {
  return typeof window !== "undefined" && typeof window.adsbygoogle !== "undefined" && Array.isArray(window.adsbygoogle)
}

// Initialize an ad slot
export function initializeAdSlot(): void {
  if (isAdSenseLoaded() && !isPreviewEnvironment()) {
    try {
      ;(window.adsbygoogle = window.adsbygoogle || []).push({})
    } catch (error) {
      console.error("Error initializing ad slot:", error)
    }
  }
}

// Ensure the AdSense script is loaded
export async function ensureAdSenseLoaded(timeout = 5000): Promise<boolean> {
  // If already loaded, return immediately
  if (isAdSenseLoaded()) return true

  // If in preview, don't load
  if (isPreviewEnvironment()) return false

  return new Promise((resolve) => {
    // Set a timeout to resolve false if script doesn't load
    const timeoutId = setTimeout(() => resolve(false), timeout)

    // Check periodically if AdSense is loaded
    const interval = setInterval(() => {
      if (isAdSenseLoaded()) {
        clearInterval(interval)
        clearTimeout(timeoutId)
        resolve(true)
      }
    }, 200)

    // Safety cleanup after timeout
    setTimeout(() => clearInterval(interval), timeout + 100)
  })
}
