export interface Post {
  id: number
  date: string
  title: {
    rendered: string
  }
  excerpt: {
    rendered: string
  }
  content: {
    rendered: string
  }
  slug: string
  _embedded?: {
    "wp:featuredmedia"?: Array<{
      source_url: string
      alt_text: string
    }>
    "wp:term"?: Array<
      Array<{
        id: number
        name: string
        slug: string
      }>
    >
  }
}

export interface Category {
  id: number
  count: number
  name: string
  slug: string
}

export interface FetchPostsParams {
  per_page?: number
  page?: number
  categories?: number
  search?: string
  orderby?: "date" | "relevance" | "title" | "slug" | "modified"
  _embed?: boolean
}

const API_URL = "https://dash.rusdimedia.com/wp-json/wp/v2"

// Cache for API responses
const apiCache = new Map<string, { data: any; timestamp: number }>()
const CACHE_TTL = 5 * 60 * 1000 // 5 minutes in milliseconds

// Update the fetchWithCache function for better performance
async function fetchWithCache(url: string, options: RequestInit = {}, cacheTTL = CACHE_TTL): Promise<any> {
  // Check if we have a valid cached response
  const cacheKey = `${url}-${JSON.stringify(options)}`
  const cachedResponse = apiCache.get(cacheKey)
  const now = Date.now()

  if (cachedResponse && now - cachedResponse.timestamp < cacheTTL) {
    return cachedResponse.data
  }

  // Maximum number of retries
  const maxRetries = 2
  let retries = 0
  let lastError

  while (retries <= maxRetries) {
    try {
      // Add a timeout to the fetch request
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

      // Don't override an existing signal
      const signal = options.signal || controller.signal

      const mergedOptions = {
        ...options,
        signal,
        next: { revalidate: 60 }, // Revalidate every 60 seconds
      }

      // Use SWR-like strategy: return stale data while revalidating
      if (cachedResponse) {
        // Start fetch in background but return cached data immediately
        fetchAndUpdateCache(url, mergedOptions, cacheKey, now).catch(console.error)
        return cachedResponse.data
      }

      const response = await fetch(url, mergedOptions)
      clearTimeout(timeoutId)

      if (!response.ok) {
        console.error(`API responded with status: ${response.status} for URL: ${url}`)

        // If we get a 404 or 5xx error, don't retry
        if (response.status === 404 || response.status >= 500) {
          return null
        }

        // For other errors, retry
        throw new Error(`API responded with status: ${response.status}`)
      }

      const data = await response.json()

      // Cache the response
      apiCache.set(cacheKey, { data, timestamp: now })

      return data
    } catch (error) {
      lastError = error

      // Don't retry if the request was aborted by the caller
      if (error instanceof DOMException && error.name === "AbortError" && options.signal?.aborted) {
        console.error(`Request aborted by caller for ${url}`)
        throw error
      }

      // If this was our own timeout or a network error, retry
      retries++

      if (retries <= maxRetries) {
        console.warn(`Retrying fetch for ${url} (attempt ${retries} of ${maxRetries})`)
        // Wait before retrying (exponential backoff)
        await new Promise((resolve) => setTimeout(resolve, 1000 * retries))
      }
    }
  }

  console.error(`Failed to fetch from ${url} after ${maxRetries} retries:`, lastError)
  return null
}

// Helper function to fetch and update cache without blocking
async function fetchAndUpdateCache(url: string, options: RequestInit, cacheKey: string, timestamp: number) {
  try {
    const response = await fetch(url, options)
    if (!response.ok) return

    const data = await response.json()
    apiCache.set(cacheKey, { data, timestamp })
  } catch (error) {
    console.error(`Background fetch failed for ${url}:`, error)
  }
}

// Update the fetchPosts function to be more robust with better error handling
export async function fetchPosts(params: FetchPostsParams = {}): Promise<Post[]> {
  const defaultParams = {
    per_page: 10,
    _embed: true,
  }

  // Create a clean params object without undefined values
  const cleanParams: Record<string, string> = {}

  // Merge default params with user params
  const mergedParams = { ...defaultParams, ...params }

  // Convert to proper string values for URL params
  Object.entries(mergedParams).forEach(([key, value]) => {
    if (value !== undefined) {
      cleanParams[key] = String(value)
    }
  })

  const queryParams = new URLSearchParams(cleanParams).toString()
  const url = `${API_URL}/posts?${queryParams}`

  const data = await fetchWithCache(url)
  return data || []
}

// Add this function after the fetchPosts function:
export async function searchPosts(query: string, page = 1, perPage = 10): Promise<{ posts: Post[]; total: number }> {
  try {
    // Create search parameters
    const searchParams: Record<string, string> = {
      search: query,
      per_page: perPage.toString(),
      page: page.toString(),
      _embed: "true",
    }

    // Don't cache search results as long as regular content
    const url = `${API_URL}/posts?${new URLSearchParams(searchParams).toString()}`

    // Use a shorter cache time for search results
    const response = await fetch(url, {
      next: { revalidate: 60 }, // Short cache time for search results
    })

    if (!response.ok) {
      console.error(`Search API responded with status: ${response.status}`)
      return { posts: [], total: 0 }
    }

    // Get the total count from the headers
    const totalPosts = Number.parseInt(response.headers.get("X-WP-Total") || "0", 10)
    const posts = await response.json()

    return { posts, total: totalPosts }
  } catch (error) {
    console.error("Error searching posts:", error)
    return { posts: [], total: 0 }
  }
}

// The rest of the API functions remain the same but use fetchWithCache
export async function fetchPostsByCategory(slug: string, count = 5): Promise<Post[]> {
  try {
    // First, get the category ID from the slug
    const categoryUrl = `${API_URL}/categories?slug=${slug}`
    const categories = await fetchWithCache(categoryUrl, {}, 3600 * 1000) // Cache for 1 hour

    if (!categories || !categories.length) {
      return []
    }

    const categoryId = categories[0].id

    // Then, fetch posts by category ID
    const postsUrl = `${API_URL}/posts?categories=${categoryId}&per_page=${count}&_embed=true`
    const posts = await fetchWithCache(postsUrl)

    return posts || []
  } catch (error) {
    console.error(`Error fetching posts for category ${slug}:`, error)
    return []
  }
}

export async function fetchPostBySlug(slug: string): Promise<Post | null> {
  const url = `${API_URL}/posts?slug=${slug}&_embed=true`
  const posts = await fetchWithCache(url)

  if (!posts || !posts.length) {
    return null
  }

  return posts[0]
}

export async function fetchCategories(): Promise<Category[]> {
  const url = `${API_URL}/categories?per_page=100`
  const categories = await fetchWithCache(url, {}, 3600 * 1000) // Cache for 1 hour

  return categories || []
}

export async function fetchPages(): Promise<Post[]> {
  const url = `${API_URL}/pages?per_page=100`
  const pages = await fetchWithCache(url, {}, 3600 * 1000) // Cache for 1 hour

  return pages || []
}

export async function fetchPageBySlug(slug: string): Promise<Post | null> {
  const url = `${API_URL}/pages?slug=${slug}&_embed=true`
  const pages = await fetchWithCache(url)

  if (!pages || !pages.length) {
    return null
  }

  return pages[0]
}

// Add this function to fetch posts by tag
export async function fetchPostsByTag(slug: string, count = 10, page = 1): Promise<{ posts: Post[]; total: number }> {
  try {
    // First, get the tag ID from the slug
    const tagUrl = `${API_URL}/tags?slug=${slug}`
    const tags = await fetchWithCache(tagUrl, {}, 3600 * 1000) // Cache for 1 hour

    if (!tags || !tags.length) {
      console.error(`No tag found with slug ${slug}`)
      return { posts: [], total: 0 }
    }

    const tagId = tags[0].id
    const tagCount = tags[0].count || 0

    // Then, fetch posts by tag ID
    const postsUrl = `${API_URL}/posts?tags=${tagId}&per_page=${count}&page=${page}&_embed=true`
    const posts = await fetchWithCache(postsUrl)

    if (!posts) {
      console.error(`Failed to fetch posts for tag ${slug}`)
      return { posts: [], total: 0 }
    }

    return { posts, total: tagCount }
  } catch (error) {
    console.error(`Error fetching posts for tag ${slug}:`, error)
    return { posts: [], total: 0 }
  }
}

// Add this function to fetch all tags
export async function fetchTags(): Promise<any[]> {
  try {
    const url = `${API_URL}/tags?per_page=100`
    const tags = await fetchWithCache(url, {}, 3600 * 1000) // Cache for 1 hour

    if (!tags) {
      console.error("Failed to fetch tags")
      return []
    }

    return tags
  } catch (error) {
    console.error("Error fetching tags:", error)
    return []
  }
}

// Add these functions to fetch subcategories and posts by subcategory

// Function to fetch subcategories of a parent category
export async function fetchSubcategories(parentSlug: string): Promise<Category[]> {
  try {
    // First, get the parent category ID
    const parentUrl = `${API_URL}/categories?slug=${parentSlug}`
    const parentCategories = await fetchWithCache(parentUrl, {}, 3600 * 1000) // Cache for 1 hour

    if (!parentCategories || !parentCategories.length) {
      return []
    }

    const parentId = parentCategories[0].id

    // Then, fetch subcategories by parent ID
    const subcategoriesUrl = `${API_URL}/categories?parent=${parentId}&per_page=100`
    const subcategories = await fetchWithCache(subcategoriesUrl, {}, 3600 * 1000) // Cache for 1 hour

    return subcategories || []
  } catch (error) {
    console.error(`Error fetching subcategories for ${parentSlug}:`, error)
    return []
  }
}

// Function to check if a category is a subcategory of another category
export async function isSubcategoryOf(subCategorySlug: string, parentCategorySlug: string): Promise<boolean> {
  try {
    // Get the parent category
    const parentUrl = `${API_URL}/categories?slug=${parentCategorySlug}`
    const parentCategories = await fetchWithCache(parentUrl, {}, 3600 * 1000)

    if (!parentCategories || !parentCategories.length) {
      return false
    }

    const parentId = parentCategories[0].id

    // Get the subcategory
    const subUrl = `${API_URL}/categories?slug=${subCategorySlug}`
    const subCategories = await fetchWithCache(subUrl, {}, 3600 * 1000)

    if (!subCategories || !subCategories.length) {
      return false
    }

    // Check if the subcategory's parent ID matches the parent category's ID
    return subCategories[0].parent === parentId
  } catch (error) {
    console.error(`Error checking if ${subCategorySlug} is subcategory of ${parentCategorySlug}:`, error)
    return false
  }
}

// Function to fetch a category by slug
export async function fetchCategoryBySlug(slug: string): Promise<Category | null> {
  const url = `${API_URL}/categories?slug=${slug}`
  const categories = await fetchWithCache(url, {}, 3600 * 1000) // Cache for 1 hour

  if (!categories || !categories.length) {
    return null
  }

  return categories[0]
}
