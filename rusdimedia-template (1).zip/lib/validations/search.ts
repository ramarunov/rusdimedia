// Simple validation schema for search results
// Since we don't have Zod as a dependency, we'll create a simple validation function

export const SearchResultSchema = {
  safeParse: (data: any) => {
    // Check if data is an array
    if (!Array.isArray(data)) {
      return {
        success: false,
        error: new Error("Data is not an array"),
      }
    }

    // Check if each item has the required properties
    for (const item of data) {
      if (!item.id || !item.title || !item.slug) {
        return {
          success: false,
          error: new Error("Invalid post data structure"),
        }
      }
    }

    return {
      success: true,
      data,
    }
  },
}
