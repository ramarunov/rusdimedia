import { cache } from "react"

const API_URL = "https://dash.rusdimedia.com/wp-json/wp/v2"

// Cache for API responses
const apiCache = new Map<string, { data: any; timestamp: number }>()
const CACHE_TTL = 5 * 60 * 1000 // 5 minutes in milliseconds

// Cached fetch function
export const fetchWithCache = cache(async (url: string, options: RequestInit = {}, cacheTTL = CACHE_TTL) => {
  // Check if we have a valid cached response
  const cacheKey = `${url}-${JSON.stringify(options)}`
  const cachedResponse = apiCache.get(cacheKey)
  const now = Date.now()

  if (cachedResponse && now - cachedResponse.timestamp < cacheTTL) {
    return cachedResponse.data
  }

  try {
    // Add a timeout to the fetch request
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

    // Don't override an existing signal
    const signal = options.signal || controller.signal

    const mergedOptions = {
      ...options,
      signal,
      next: { revalidate: 60 }, // Revalidate every 60 seconds
    }

    const response = await fetch(url, mergedOptions)
    clearTimeout(timeoutId)

    if (!response.ok) {
      console.error(`API responded with status: ${response.status} for URL: ${url}`)
      return null
    }

    const data = await response.json()

    // Cache the response
    apiCache.set(cacheKey, { data, timestamp: now })

    return data
  } catch (error) {
    console.error(`Failed to fetch from ${url}:`, error)
    return null
  }
})

// Function to fetch popular tags with fallback
export async function fetchPopularTagsWithFallback() {
  try {
    // Try to fetch tags from the API
    const url = `${API_URL}/tags?per_page=30&orderby=count&order=desc`
    const tags = await fetchWithCache(url, {}, 3600 * 1000) // Cache for 1 hour

    if (tags && tags.length > 0) {
      return tags.filter((tag: any) => tag.count > 0).slice(0, 15)
    }

    // If API fails or returns empty, use fallback tags
    return [
      { id: 1, name: "Politik", slug: "politik", count: 100 },
      { id: 2, name: "Ekonomi", slug: "ekonomi", count: 90 },
      { id: 3, name: "Kesehatan", slug: "kesehatan", count: 80 },
      { id: 4, name: "Teknologi", slug: "teknologi", count: 70 },
      { id: 5, name: "Lifestyle", slug: "lifestyle", count: 60 },
      { id: 6, name: "Olahraga", slug: "olahraga", count: 50 },
      { id: 7, name: "Pendidikan", slug: "pendidikan", count: 40 },
      { id: 8, name: "Hiburan", slug: "hiburan", count: 30 },
    ]
  } catch (error) {
    console.error("Error fetching popular tags:", error)
    // Return fallback tags on error
    return [
      { id: 1, name: "Politik", slug: "politik", count: 100 },
      { id: 2, name: "Ekonomi", slug: "ekonomi", count: 90 },
      { id: 3, name: "Kesehatan", slug: "kesehatan", count: 80 },
      { id: 4, name: "Teknologi", slug: "teknologi", count: 70 },
      { id: 5, name: "Lifestyle", slug: "lifestyle", count: 60 },
    ]
  }
}
