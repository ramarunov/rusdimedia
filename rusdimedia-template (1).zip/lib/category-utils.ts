import type { Post } from "./api"

// Function to fetch posts by category with fallback mechanisms
export async function fetchCategoryPostsWithFallback(
  categorySlug: string,
  count = 5,
): Promise<{ posts: Post[]; error: string | null }> {
  try {
    // First, try to get the category ID
    let categoryId = null

    try {
      const categoryResponse = await fetch(
        `https://dash.rusdimedia.com/wp-json/wp/v2/categories?slug=${categorySlug}`,
        { next: { revalidate: 3600 } }, // Cache for 1 hour
      )

      if (categoryResponse.ok) {
        const categories = await categoryResponse.json()
        if (categories && categories.length) {
          categoryId = categories[0].id
        }
      } else {
        console.warn(`Category API responded with status: ${categoryResponse.status} for ${categorySlug}`)
      }
    } catch (categoryError) {
      console.error(`Error fetching ${categorySlug} category:`, categoryError)
    }

    // If we couldn't get the category ID, use a fallback approach
    if (!categoryId) {
      // Try to fetch recent posts and filter them client-side
      const fallbackResponse = await fetch(
        `https://dash.rusdimedia.com/wp-json/wp/v2/posts?per_page=20&_embed=true`,
        { next: { revalidate: 300 } }, // Cache for 5 minutes
      )

      if (fallbackResponse.ok) {
        const allPosts = await fallbackResponse.json()

        // Try to find posts that might be related to the category
        // This is a simple approach - you might want to enhance this logic
        const filteredPosts = allPosts.filter((post) => {
          if (!post.title || !post.excerpt) return false

          const title = post.title.rendered.toLowerCase()
          const excerpt = post.excerpt.rendered.toLowerCase()
          return title.includes(categorySlug) || excerpt.includes(categorySlug)
        })

        if (filteredPosts.length > 0) {
          return {
            posts: filteredPosts.slice(0, count),
            error: null,
          }
        }
      }

      return {
        posts: [],
        error: `Konten ${categorySlug} tidak tersedia saat ini`,
      }
    }

    // If we have the category ID, fetch posts as normal
    try {
      const postsResponse = await fetch(
        `https://dash.rusdimedia.com/wp-json/wp/v2/posts?categories=${categoryId}&per_page=${count}&_embed=true`,
        { next: { revalidate: 300 } }, // Cache for 5 minutes
      )

      if (postsResponse.ok) {
        const postsData = await postsResponse.json()
        return {
          posts: postsData,
          error: null,
        }
      } else {
        console.error(`Posts API responded with status: ${postsResponse.status} for ${categorySlug}`)
        return {
          posts: [],
          error: `Gagal memuat artikel ${categorySlug}`,
        }
      }
    } catch (postsError) {
      console.error(`Error fetching ${categorySlug} posts:`, postsError)
      return {
        posts: [],
        error: `Gagal memuat artikel ${categorySlug}`,
      }
    }
  } catch (error) {
    console.error(`Error in ${categorySlug} section:`, error)
    return {
      posts: [],
      error: "Terjadi kesalahan saat memuat konten",
    }
  }
}

// Function to get keywords for common categories to help with fallback filtering
export function getCategoryKeywords(categorySlug: string): string[] {
  const keywordMap: Record<string, string[]> = {
    kesehatan: ["kesehatan", "health", "sehat", "penyakit", "obat", "dokter", "rumah sakit", "medical"],
    politik: ["politik", "political", "pemerintah", "presiden", "menteri", "dpr", "partai", "pemilu"],
    ekonomi: ["ekonomi", "economy", "keuangan", "finance", "bank", "investasi", "saham", "bisnis"],
    teknologi: ["teknologi", "technology", "tech", "digital", "komputer", "internet", "aplikasi", "software"],
    olahraga: ["olahraga", "sport", "sepak bola", "bola", "basket", "atlet", "pertandingan", "turnamen"],
    hiburan: ["hiburan", "entertainment", "film", "musik", "artis", "selebriti", "konser", "bioskop"],
    pendidikan: ["pendidikan", "education", "sekolah", "universitas", "kuliah", "belajar", "siswa", "mahasiswa"],
    lifestyle: ["lifestyle", "gaya hidup", "fashion", "trend", "makanan", "kuliner", "travel", "wisata"],
  }

  return keywordMap[categorySlug.toLowerCase()] || [categorySlug]
}
