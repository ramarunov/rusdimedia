// Schema.org utility functions for structured data

// Generate WebSite schema
export function generateWebsiteSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: "Rusdimedia.com",
    url: "https://rusdimedia.com",
    potentialAction: {
      "@type": "SearchAction",
      target: "https://rusdimedia.com/search?q={search_term_string}",
      "query-input": "required name=search_term_string",
    },
    description:
      "Baca berita dan informasi terbaru seputar politik, gaya hidup, tips dan trik hari ini hanya di Rusdi Media. Disajikan berdasarkan fakta dan sumber terpercaya!",
    inLanguage: "id-ID",
    publisher: {
      "@type": "Organization",
      name: "Rusdimedia.com",
      logo: {
        "@type": "ImageObject",
        url: "https://dash.rusdimedia.com/wp-content/uploads/2024/10/Dosa-Besar-dalam-Islam-e1744014973421.png",
        width: 600,
        height: 60,
      },
    },
  }
}

// Generate Organization schema
export function generateOrganizationSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Rusdimedia.com",
    url: "https://rusdimedia.com",
    logo: {
      "@type": "ImageObject",
      url: "https://dash.rusdimedia.com/wp-content/uploads/2024/10/Dosa-Besar-dalam-Islam-e1744014973421.png",
      width: 600,
      height: 60,
    },
    sameAs: [
      "https://whatsapp.com/channel/0029Vb8EzWY1dAw1ZeNtC30d",
      "https://news.google.com/publications/CAAqBwgKMNPGlAswk9CxAw",
    ],
    contactPoint: {
      "@type": "ContactPoint",
      telephone: "+62-896-2449-0220",
      contactType: "customer service",
      email: "mediarusdi@gmail.com",
      availableLanguage: "Indonesian",
    },
    address: {
      "@type": "PostalAddress",
      addressLocality: "Lampung",
      addressRegion: "Lampung",
      addressCountry: "ID",
    },
  }
}

// Update the generateBreadcrumbSchema function to provide a default value for items
export function generateBreadcrumbSchema(items?: Array<{ name: string; url: string }>) {
  // Handle case where items is undefined
  const breadcrumbItems = items || [{ name: "Beranda", url: "https://rusdimedia.com" }]

  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: breadcrumbItems.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: item.url,
    })),
  }
}

// Generate Article schema
export function generateArticleSchema(post: any) {
  if (!post) return null

  const title = post.title.rendered.replace(/<[^>]*>/g, "")
  const imageUrl = post._embedded?.["wp:featuredmedia"]?.[0]?.source_url || ""
  const authorName = "Rusdimedia.com"
  const publishDate = post.date
  const modifiedDate = post.modified || post.date

  // Extract category information
  const categories = post._embedded?.["wp:term"]?.[0] || []
  const categoryNames = categories.map((cat: any) => cat.name)

  // Extract tags information
  const tags = post._embedded?.["wp:term"]?.[1] || []
  const tagNames = tags.map((tag: any) => tag.name)

  return {
    "@context": "https://schema.org",
    "@type": "NewsArticle",
    headline: title,
    image: [imageUrl],
    datePublished: publishDate,
    dateModified: modifiedDate,
    author: {
      "@type": "Organization",
      name: authorName,
      url: "https://rusdimedia.com",
    },
    publisher: {
      "@type": "Organization",
      name: "Rusdimedia.com",
      logo: {
        "@type": "ImageObject",
        url: "https://dash.rusdimedia.com/wp-content/uploads/2024/10/Dosa-Besar-dalam-Islam-e1744014973421.png",
        width: 600,
        height: 60,
      },
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": `https://rusdimedia.com/${post.slug}`,
    },
    description: post.excerpt.rendered.replace(/<[^>]*>/g, "").substring(0, 200),
    articleSection: categoryNames.join(", "),
    keywords: tagNames.join(", "),
    inLanguage: "id-ID",
    isAccessibleForFree: "True",
  }
}

// Generate CollectionPage schema for category pages
export function generateCollectionPageSchema(title: string, url: string, description = "") {
  return {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: title,
    url: url,
    description: description,
    inLanguage: "id-ID",
    publisher: {
      "@type": "Organization",
      name: "Rusdimedia.com",
      logo: {
        "@type": "ImageObject",
        url: "https://dash.rusdimedia.com/wp-content/uploads/2024/10/Dosa-Besar-dalam-Islam-e1744014973421.png",
        width: 600,
        height: 60,
      },
    },
  }
}

// Generate FAQ schema
export function generateFAQSchema(faqs: Array<{ question: string; answer: string }>) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
  }
}

// Generate LocalBusiness schema
export function generateLocalBusinessSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: "Rusdimedia.com",
    image: "https://dash.rusdimedia.com/wp-content/uploads/2024/10/Dosa-Besar-dalam-Islam-e1744014973421.png",
    url: "https://rusdimedia.com",
    telephone: "+62-896-2449-0220",
    address: {
      "@type": "PostalAddress",
      addressLocality: "Lampung",
      addressRegion: "Lampung",
      addressCountry: "ID",
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: -5.45,
      longitude: 105.26667,
    },
    openingHoursSpecification: {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
      opens: "09:00",
      closes: "17:00",
    },
  }
}
