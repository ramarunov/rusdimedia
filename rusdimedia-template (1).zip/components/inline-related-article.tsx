"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import OptimizedImage from "./optimized-image"
import { fetchPosts } from "@/lib/api"
import { ExternalLink } from "lucide-react"

interface InlineRelatedArticleProps {
  tags: Array<{
    id: number
    name: string
    slug: string
  }>
  currentPostId: number
}

export default function InlineRelatedArticle({ tags, currentPostId }: InlineRelatedArticleProps) {
  const [relatedArticles, setRelatedArticles] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function fetchRelatedArticles() {
      if (!tags || tags.length === 0) return

      try {
        setIsLoading(true)

        // Get tag IDs
        const tagIds = tags.map((tag) => tag.id)

        // Fetch posts with matching tags
        const posts = await fetchPosts({
          per_page: 5,
          _embed: true,
        })

        // Filter out the current post and posts without featured images
        const filteredPosts = posts
          .filter((post) => post.id !== currentPostId)
          .filter((post) => post._embedded?.["wp:featuredmedia"]?.[0]?.source_url)

        // Take the first 3 posts
        setRelatedArticles(filteredPosts.slice(0, 3))
      } catch (error) {
        console.error("Error fetching related articles:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchRelatedArticles()
  }, [tags, currentPostId])

  if (isLoading || relatedArticles.length === 0) {
    return null
  }

  return (
    <div className="my-6">
      <h4 className="mb-3 text-base font-bold">Baca Juga:</h4>
      <div className="space-y-3">
        {relatedArticles.map((article) => (
          <div
            key={article.id}
            className="group flex items-center gap-3 rounded-md border border-gray-200 p-2 hover:bg-gray-50"
          >
            <div className="relative h-16 w-24 flex-shrink-0 overflow-hidden rounded">
              {article._embedded?.["wp:featuredmedia"]?.[0]?.source_url && (
                <OptimizedImage
                  src={article._embedded["wp:featuredmedia"][0].source_url}
                  alt={article._embedded["wp:featuredmedia"][0].alt_text || article.title.rendered}
                  fill
                  className="object-cover"
                  sizes="96px"
                  quality={70}
                />
              )}
            </div>
            <div className="flex-1">
              <h5 className="text-sm font-medium leading-tight group-hover:text-[#00acee]">
                <Link href={`/${article.slug}`}>
                  <span dangerouslySetInnerHTML={{ __html: article.title.rendered }} />
                </Link>
              </h5>
              <div className="mt-1 flex items-center text-xs text-gray-500">
                <span>Artikel Rusdimedia</span>
                <ExternalLink className="ml-1 h-3 w-3" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
