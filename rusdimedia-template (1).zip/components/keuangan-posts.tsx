"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { formatDate } from "@/lib/utils"
import OptimizedImage from "./optimized-image"

interface Post {
  id: number
  date: string
  title: {
    rendered: string
  }
  excerpt: {
    rendered: string
  }
  slug: string
  _embedded?: {
    "wp:featuredmedia"?: Array<{
      source_url: string
      alt_text: string
    }>
    "wp:term"?: Array<
      Array<{
        id: number
        name: string
        slug: string
      }>
    >
  }
}

export default function KeuanganPosts() {
  const [posts, setPosts] = useState<Post[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchKeuanganPosts() {
      try {
        setIsLoading(true)

        // First, get the category ID for "keuangan"
        const categoryResponse = await fetch("https://dash.rusdimedia.com/wp-json/wp/v2/categories?slug=keuangan")

        if (!categoryResponse.ok) {
          throw new Error(`Failed to fetch keuangan category: ${categoryResponse.status}`)
        }

        const categories = await categoryResponse.json()

        if (!categories.length) {
          // If category doesn't exist, try to fetch recent posts as fallback
          const postsResponse = await fetch(`https://dash.rusdimedia.com/wp-json/wp/v2/posts?per_page=4&_embed=true`)

          if (!postsResponse.ok) {
            throw new Error(`Failed to fetch posts: ${postsResponse.status}`)
          }

          const postsData = await postsResponse.json()
          setPosts(postsData)
          return
        }

        const categoryId = categories[0].id

        // Then fetch posts from that category
        const postsResponse = await fetch(
          `https://dash.rusdimedia.com/wp-json/wp/v2/posts?categories=${categoryId}&per_page=4&_embed=true`,
        )

        if (!postsResponse.ok) {
          throw new Error(`Failed to fetch posts: ${postsResponse.status}`)
        }

        const postsData = await postsResponse.json()
        setPosts(postsData)
      } catch (error) {
        console.error("Error fetching keuangan posts:", error)
        setError("Failed to load keuangan posts")
      } finally {
        setIsLoading(false)
      }
    }

    fetchKeuanganPosts()
  }, [])

  // Function to strip HTML tags
  const stripHtml = (html: string) => {
    return html.replace(/<[^>]*>/g, "")
  }

  if (isLoading) {
    return (
      <div className="mb-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="section-title mb-0 text-[#00acee]">Keuangan</h2>
        </div>
        <div className="animate-pulse">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="mb-4 flex gap-3">
              <div className="h-16 w-16 bg-gray-200 rounded-md flex-shrink-0"></div>
              <div className="flex-1">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/3"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  if (error || posts.length === 0) {
    return null
  }

  // Get the first post with a featured image for the main display
  const featuredPost = posts.find((post) => post._embedded?.["wp:featuredmedia"]?.[0]?.source_url) || posts[0]
  const otherPosts = posts.filter((post) => post.id !== featuredPost.id)

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="section-title mb-0 text-[#00acee]">Keuangan</h2>
        <Link href="/kategori/keuangan" className="text-sm font-medium text-[#00acee] hover:underline">
          Lihat Semua
        </Link>
      </div>

      {/* Featured Post */}
      {featuredPost && (
        <article className="mb-4">
          <Link href={`/${featuredPost.slug}`} className="block">
            {featuredPost._embedded?.["wp:featuredmedia"]?.[0]?.source_url && (
              <div className="relative aspect-[16/9] overflow-hidden rounded-md mb-2">
                <OptimizedImage
                  src={featuredPost._embedded["wp:featuredmedia"][0].source_url}
                  alt={featuredPost._embedded["wp:featuredmedia"][0].alt_text || featuredPost.title.rendered}
                  fill
                  loading="lazy"
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 300px"
                  quality={75}
                />
              </div>
            )}
            <h3 className="text-sm font-bold leading-tight hover:text-[#00acee]">
              <span dangerouslySetInnerHTML={{ __html: featuredPost.title.rendered }} />
            </h3>
            <div className="mt-1 text-xs text-gray-500">{formatDate(featuredPost.date)}</div>
          </Link>
        </article>
      )}

      {/* Other Posts */}
      <div className="space-y-3">
        {otherPosts.map((post) => (
          <article key={post.id} className="border-t border-gray-100 pt-3">
            <Link href={`/${post.slug}`} className="block">
              <h3 className="text-sm font-medium leading-tight hover:text-[#00acee]">
                <span dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
              </h3>
              <div className="mt-1 text-xs text-gray-500">{formatDate(post.date)}</div>
            </Link>
          </article>
        ))}
      </div>
    </div>
  )
}
