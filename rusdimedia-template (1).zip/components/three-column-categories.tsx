import Link from "next/link"
import { fetchPostsByCategory } from "@/lib/api"
import { formatDate } from "@/lib/utils"
import OptimizedImage from "./optimized-image"

interface ThreeColumnCategoriesProps {
  categories: Array<{
    title: string
    slug: string
  }>
  postsPerCategory?: number
}

export default async function ThreeColumnCategories({ categories, postsPerCategory = 4 }: ThreeColumnCategoriesProps) {
  // Fetch posts for each category in parallel
  const categoryPostsPromises = categories.map(async (category) => {
    const posts = await fetchPostsByCategory(category.slug, postsPerCategory)
    return {
      ...category,
      posts,
    }
  })

  const categoryPosts = await Promise.all(categoryPostsPromises)

  return (
    <div className="my-8">
      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        {categoryPosts.map((category) => (
          <div key={category.slug} className="flex flex-col">
            {/* Category Header with Arrow */}
            <div className="mb-4 flex items-center justify-between">
              <Link href={`/kategori/${category.slug}`} className="text-[#00acee] hover:underline">
                <h3 className="text-lg font-bold uppercase">{category.title}</h3>
              </Link>
            </div>

            {/* Posts List */}
            <div className="space-y-4">
              {category.posts.map((post, index) => (
                <article key={post.id} className={index === 0 ? "mb-4" : "border-t border-gray-200 pt-4"}>
                  {index === 0 && post._embedded?.["wp:featuredmedia"]?.[0]?.source_url && (
                    <Link href={`/${post.slug}`} className="mb-3 block">
                      <div className="relative aspect-[16/9] overflow-hidden rounded-md">
                        <OptimizedImage
                          src={post._embedded["wp:featuredmedia"][0].source_url}
                          alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                          fill
                          className="object-cover transition-transform duration-300 hover:scale-105"
                          sizes="(max-width: 768px) 100vw, 33vw"
                          quality={75}
                        />
                      </div>
                    </Link>
                  )}
                  <h4 className="text-sm font-bold leading-tight">
                    <Link href={`/${post.slug}`} className="hover:text-[#00acee]">
                      <span dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                    </Link>
                  </h4>
                  <div className="mt-1 text-xs text-gray-500">{formatDate(post.date)}</div>
                  {index === 0 && (
                    <div
                      className="mt-2 text-sm text-gray-600 line-clamp-2"
                      dangerouslySetInnerHTML={{ __html: post.excerpt.rendered }}
                    />
                  )}
                </article>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
