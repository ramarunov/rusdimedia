import Link from "next/link"

interface SearchPaginationProps {
  currentPage: number
  totalItems: number
  itemsPerPage: number
  baseUrl: string
}

export default function SearchPagination({ currentPage, totalItems, itemsPerPage, baseUrl }: SearchPaginationProps) {
  const totalPages = Math.ceil(totalItems / itemsPerPage)

  if (totalPages <= 1) {
    return null
  }

  // Create an array of page numbers to display
  const getPageNumbers = () => {
    const pages = []
    const maxPagesToShow = 5

    if (totalPages <= maxPagesToShow) {
      // Show all pages if there are fewer than maxPagesToShow
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i)
      }
    } else {
      // Always show first page
      pages.push(1)

      // Calculate start and end of page range
      let start = Math.max(2, currentPage - 1)
      let end = Math.min(totalPages - 1, currentPage + 1)

      // Adjust if we're at the start or end
      if (currentPage <= 2) {
        end = 4
      } else if (currentPage >= totalPages - 1) {
        start = totalPages - 3
      }

      // Add ellipsis if needed
      if (start > 2) {
        pages.push("...")
      }

      // Add page numbers
      for (let i = start; i <= end; i++) {
        pages.push(i)
      }

      // Add ellipsis if needed
      if (end < totalPages - 1) {
        pages.push("...")
      }

      // Always show last page
      pages.push(totalPages)
    }

    return pages
  }

  const pageNumbers = getPageNumbers()

  // Helper function to construct the URL with the page parameter
  const getPageUrl = (page: number) => {
    // If the URL already has a query parameter
    if (baseUrl.includes("?")) {
      // Check if it already has a page parameter
      if (baseUrl.includes("page=")) {
        return baseUrl.replace(/page=\d+/, `page=${page}`)
      } else {
        return `${baseUrl}&page=${page}`
      }
    } else {
      return `${baseUrl}${page === 1 ? "" : `?page=${page}`}`
    }
  }

  return (
    <nav className="mt-8 flex justify-center" aria-label="Pagination">
      <ul className="flex items-center space-x-1">
        {/* Previous page */}
        {currentPage > 1 && (
          <li>
            <Link
              href={getPageUrl(currentPage - 1)}
              className="flex h-10 w-10 items-center justify-center rounded-md border border-gray-300 hover:bg-gray-50"
              aria-label="Previous page"
            >
              &laquo;
            </Link>
          </li>
        )}

        {/* Page numbers */}
        {pageNumbers.map((page, index) => (
          <li key={index}>
            {page === "..." ? (
              <span className="flex h-10 w-10 items-center justify-center">...</span>
            ) : (
              <Link
                href={getPageUrl(page as number)}
                className={`flex h-10 w-10 items-center justify-center rounded-md ${
                  currentPage === page ? "bg-[#00acee] text-white" : "border border-gray-300 hover:bg-gray-50"
                }`}
                aria-current={currentPage === page ? "page" : undefined}
              >
                {page}
              </Link>
            )}
          </li>
        ))}

        {/* Next page */}
        {currentPage < totalPages && (
          <li>
            <Link
              href={getPageUrl(currentPage + 1)}
              className="flex h-10 w-10 items-center justify-center rounded-md border border-gray-300 hover:bg-gray-50"
              aria-label="Next page"
            >
              &raquo;
            </Link>
          </li>
        )}
      </ul>
    </nav>
  )
}
