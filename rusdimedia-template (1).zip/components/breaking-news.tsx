"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"

interface Post {
  id: number
  title: {
    rendered: string
  }
  slug: string
  date: string
  _embedded?: {
    "wp:featuredmedia"?: Array<{
      source_url: string
      alt_text: string
    }>
  }
}

// Hardcoded fallback data that will always be available
const FALLBACK_NEWS = [
  {
    id: 1,
    title: { rendered: "Berita terbaru akan segera hadir" },
    slug: "/",
    date: new Date().toISOString(),
  },
  {
    id: 2,
    title: { rendered: "Kunjungi halaman utama untuk berita terkini" },
    slug: "/",
    date: new Date().toISOString(),
  },
  {
    id: 3,
    title: { rendered: "Silakan refresh halaman untuk memuat ulang berita" },
    slug: "/",
    date: new Date().toISOString(),
  },
  {
    id: 4,
    title: { rendered: "Temukan artikel menarik di kategori Teknologi" },
    slug: "/kategori/teknologi",
    date: new Date().toISOString(),
  },
  {
    id: 5,
    title: { rendered: "Jelajahi berita terbaru di Rusdimedia" },
    slug: "/",
    date: new Date().toISOString(),
  },
]

export default function BreakingNews() {
  const [breakingNews, setBreakingNews] = useState<Post[]>(FALLBACK_NEWS)
  const [isLoading, setIsLoading] = useState(false) // Start with false since we have fallback data
  const pathname = usePathname()

  useEffect(() => {
    // Don't even attempt to fetch if we're in a preview environment
    // This helps avoid errors in environments where the API might not be accessible
    if (process.env.NEXT_PUBLIC_VERCEL_ENV === "preview") {
      return
    }

    // Function to fetch breaking news
    async function fetchBreakingNews() {
      setIsLoading(true)

      try {
        // Try to get data from localStorage first
        const cachedData = localStorage.getItem("breaking_news_cache")
        const cacheTimestamp = localStorage.getItem("breaking_news_timestamp")

        // Check if we have valid cached data (less than 15 minutes old)
        if (cachedData && cacheTimestamp) {
          const parsedData = JSON.parse(cachedData)
          const timestamp = Number.parseInt(cacheTimestamp, 10)

          // If cache is less than 15 minutes old, use it
          if (Date.now() - timestamp < 15 * 60 * 1000) {
            setBreakingNews(parsedData)
            setIsLoading(false)

            // Still try to update cache in the background
            updateCacheInBackground()
            return
          }
        }

        // If no valid cache, make a simple fetch request with a timeout
        const controller = new AbortController()
        const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

        const response = await fetch("https://dash.rusdimedia.com/wp-json/wp/v2/posts?per_page=5&_embed=true", {
          signal: controller.signal,
          method: "GET",
          headers: {
            Accept: "application/json",
          },
          // Explicitly avoid sending credentials to prevent CORS issues
          credentials: "omit",
          // Use no-cors mode as a last resort if regular fetch fails
          // Note: This will make the response opaque and not readable as JSON
          // mode: "no-cors"
        })

        clearTimeout(timeoutId)

        if (!response.ok) {
          throw new Error(`API responded with status: ${response.status}`)
        }

        const data = await response.json()

        // Update state with the fetched data
        if (data && Array.isArray(data) && data.length > 0) {
          setBreakingNews(data)

          // Cache the successful response
          localStorage.setItem("breaking_news_cache", JSON.stringify(data))
          localStorage.setItem("breaking_news_timestamp", Date.now().toString())
        }
      } catch (error) {
        console.error("Breaking news fetch error:", error instanceof Error ? error.message : "Unknown error")

        // Try to load from cache even if it's older than 15 minutes as a fallback
        try {
          const cachedData = localStorage.getItem("breaking_news_cache")
          if (cachedData) {
            setBreakingNews(JSON.parse(cachedData))
          }
        } catch (cacheError) {
          // If all else fails, we already have the fallback data
          console.warn("Could not load from cache:", cacheError)
        }
      } finally {
        setIsLoading(false)
      }
    }

    // Function to update cache in the background without affecting UI
    async function updateCacheInBackground() {
      try {
        const response = await fetch("https://dash.rusdimedia.com/wp-json/wp/v2/posts?per_page=5&_embed=true", {
          method: "GET",
          headers: {
            Accept: "application/json",
          },
          credentials: "omit",
        })

        if (!response.ok) return

        const data = await response.json()

        if (data && Array.isArray(data) && data.length > 0) {
          // Only update cache, don't update UI
          localStorage.setItem("breaking_news_cache", JSON.stringify(data))
          localStorage.setItem("breaking_news_timestamp", Date.now().toString())
        }
      } catch (error) {
        // Silently fail for background updates
        console.warn("Background cache update failed:", error)
      }
    }

    // Only run the fetch if localStorage is available (client-side)
    if (typeof window !== "undefined") {
      fetchBreakingNews()
    }
  }, [])

  // Don't show on single post pages (paths with just a slug)
  const pathSegments = pathname.split("/").filter(Boolean)
  if (
    pathSegments.length === 1 &&
    pathSegments[0] !== "kategori" &&
    pathSegments[0] !== "category" &&
    pathSegments[0] !== "tags" &&
    pathSegments[0] !== "sitemap" &&
    pathSegments[0] !== "halaman" &&
    pathSegments[0] !== "pages"
  ) {
    return null
  }

  // If loading, show a simple loading state
  if (isLoading && breakingNews === FALLBACK_NEWS) {
    return (
      <div className="bg-gray-100 py-2" aria-hidden="true">
        <div className="mx-auto max-w-[1080px] px-4">
          <div className="flex items-center">
            <div className="mr-4 bg-[#00acee] px-3 py-1 text-sm font-bold text-white">Berita Terbaru</div>
            <div className="w-full h-6 flex items-center">
              <div className="animate-pulse h-4 bg-gray-300 rounded w-3/4"></div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-gray-100 py-2 md:py-2">
      <div className="mx-auto max-w-[1080px] px-4">
        <div className="flex items-center">
          <div className="flex-shrink-0 bg-[#00acee] px-3 py-1 text-sm font-bold text-white">Berita Terbaru</div>

          <div className="relative flex-1 overflow-hidden ml-4">
            <div className="marquee-container">
              <div className="marquee-content">
                {breakingNews.map((post) => (
                  <Link
                    key={post.id}
                    href={post.slug ? `/${post.slug}` : "#"}
                    className="mx-4 flex items-center whitespace-nowrap text-sm font-medium hover:text-[#00acee]"
                    {...(post.slug ? {} : { onClick: (e) => e.preventDefault() })}
                  >
                    {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url && (
                      <div className="relative h-6 w-6 mr-2 overflow-hidden rounded-full flex-shrink-0">
                        <img
                          src={post._embedded?.["wp:featuredmedia"]?.[0]?.source_url || "/placeholder.svg"}
                          alt=""
                          className="h-full w-full object-cover"
                        />
                      </div>
                    )}
                    <span dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                  </Link>
                ))}
              </div>
              <div className="marquee-content" aria-hidden="true">
                {breakingNews.map((post) => (
                  <Link
                    key={`duplicate-${post.id}`}
                    href={post.slug ? `/${post.slug}` : "#"}
                    className="mx-4 flex items-center whitespace-nowrap text-sm font-medium hover:text-[#00acee]"
                    {...(post.slug ? {} : { onClick: (e) => e.preventDefault() })}
                  >
                    {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url && (
                      <div className="relative h-6 w-6 mr-2 overflow-hidden rounded-full flex-shrink-0">
                        <img
                          src={post._embedded?.["wp:featuredmedia"]?.[0]?.source_url || "/placeholder.svg"}
                          alt=""
                          className="h-full w-full object-cover"
                        />
                      </div>
                    )}
                    <span dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .marquee-container {
          display: flex;
          width: 100%;
          overflow: hidden;
          position: relative;
        }
        
        .marquee-content {
          display: flex;
          animation: marquee 30s linear infinite;
          white-space: nowrap;
          will-change: transform;
          position: relative;
        }
        
        @keyframes marquee {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-100%);
          }
        }
        
        /* Pause animation when hovered */
        .marquee-container:hover .marquee-content {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  )
}
