"use client"

import { useState, useEffect, useRef } from "react"
import { X } from "lucide-react"
import Script from "next/script"

export default function StickySideAds() {
  const [leftAdClosed, setLeftAdClosed] = useState(false)
  const [rightAdClosed, setRightAdClosed] = useState(false)
  const [isDesktop, setIsDesktop] = useState(false)
  const [isPreviewEnvironment, setIsPreviewEnvironment] = useState(false)
  const [adsInitialized, setAdsInitialized] = useState(false)

  const leftAdRef = useRef<HTMLDivElement>(null)
  const rightAdRef = useRef<HTMLDivElement>(null)

  // Check if we're on desktop and if we're in a preview environment
  useEffect(() => {
    // Check if we're in a preview environment
    const checkPreviewEnvironment = () => {
      const hostname = window.location.hostname
      return hostname.includes("vusercontent.net") || hostname.includes("localhost") || hostname.includes("vercel.app")
    }

    const checkIfDesktop = () => {
      setIsDesktop(window.innerWidth >= 1280) // xl breakpoint
    }

    // Initial checks
    setIsPreviewEnvironment(checkPreviewEnvironment())
    checkIfDesktop()

    // Add event listener for window resize
    window.addEventListener("resize", checkIfDesktop)

    // Cleanup
    return () => {
      window.removeEventListener("resize", checkIfDesktop)
    }
  }, [])

  // Load saved preferences from localStorage
  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedLeftAdClosed = localStorage.getItem("leftAdClosed") === "true"
      const storedRightAdClosed = localStorage.getItem("rightAdClosed") === "true"

      setLeftAdClosed(storedLeftAdClosed)
      setRightAdClosed(storedRightAdClosed)
    }
  }, [])

  // Initialize ads when component mounts
  useEffect(() => {
    // Don't initialize ads in preview environment
    if (isPreviewEnvironment || !isDesktop || (leftAdClosed && rightAdClosed) || adsInitialized) return

    const isAdsenseLoaded = () => {
      return typeof window.adsbygoogle !== "undefined" && Array.isArray(window.adsbygoogle)
    }

    const initializeAds = () => {
      try {
        if (isAdsenseLoaded()) {
          // Initialize left ad if not closed and ref exists
          if (!leftAdClosed && leftAdRef.current) {
            ;(window.adsbygoogle = window.adsbygoogle || []).push({})
          }

          // Initialize right ad if not closed and ref exists
          if (!rightAdClosed && rightAdRef.current) {
            ;(window.adsbygoogle = window.adsbygoogle || []).push({})
          }

          setAdsInitialized(true)
        }
      } catch (error) {
        console.error("Error initializing sticky ads:", error)
      }
    }

    // If AdSense is already loaded, initialize immediately
    if (isAdsenseLoaded()) {
      initializeAds()
    } else {
      // Otherwise wait for the adsense script to load
      const checkAdsenseInterval = setInterval(() => {
        if (isAdsenseLoaded()) {
          initializeAds()
          clearInterval(checkAdsenseInterval)
        }
      }, 300)

      // Cleanup interval after 10 seconds to avoid infinite checking
      setTimeout(() => clearInterval(checkAdsenseInterval), 10000)

      return () => clearInterval(checkAdsenseInterval)
    }
  }, [isDesktop, leftAdClosed, rightAdClosed, isPreviewEnvironment, adsInitialized])

  // Handle closing the left ad
  const closeLeftAd = () => {
    setLeftAdClosed(true)
    localStorage.setItem("leftAdClosed", "true")
  }

  // Handle closing the right ad
  const closeRightAd = () => {
    setRightAdClosed(true)
    localStorage.setItem("rightAdClosed", "true")
  }

  // If in preview environment, don't render ads
  if (isPreviewEnvironment) {
    return null
  }

  // If not desktop or both ads are closed, don't render anything
  if (!isDesktop || (leftAdClosed && rightAdClosed)) {
    return null
  }

  return (
    <>
      {!isPreviewEnvironment && (
        <Script
          id="adsense-sticky"
          strategy="afterInteractive"
          src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7609031768696978"
          crossOrigin="anonymous"
          onLoad={() => {
            if (!adsInitialized && ((!leftAdClosed && leftAdRef.current) || (!rightAdClosed && rightAdRef.current))) {
              try {
                // Initialize left ad if not closed and ref exists
                if (!leftAdClosed && leftAdRef.current) {
                  ;(window.adsbygoogle = window.adsbygoogle || []).push({})
                }

                // Initialize right ad if not closed and ref exists
                if (!rightAdClosed && rightAdRef.current) {
                  ;(window.adsbygoogle = window.adsbygoogle || []).push({})
                }

                setAdsInitialized(true)
              } catch (error) {
                console.error("Error in sticky ad script onLoad:", error)
              }
            }
          }}
        />
      )}

      {/* Left Ad */}
      {!leftAdClosed && (
        <div className="fixed left-0 top-1/2 -translate-y-1/2 z-30 hidden xl:block">
          <div className="relative">
            <button
              onClick={closeLeftAd}
              className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-white shadow-md hover:bg-gray-100"
              aria-label="Close left advertisement"
            >
              <X className="h-4 w-4" />
            </button>
            <div className="bg-white p-1 shadow-md">
              <ins
                ref={leftAdRef}
                className="adsbygoogle"
                style={{ display: "inline-block", width: "120px", height: "600px" }}
                data-ad-client="ca-pub-7609031768696978"
                data-ad-slot="3984599194"
              ></ins>
            </div>
          </div>
        </div>
      )}

      {/* Right Ad */}
      {!rightAdClosed && (
        <div className="fixed right-0 top-1/2 -translate-y-1/2 z-30 hidden xl:block">
          <div className="relative">
            <button
              onClick={closeRightAd}
              className="absolute -left-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-white shadow-md hover:bg-gray-100"
              aria-label="Close right advertisement"
            >
              <X className="h-4 w-4" />
            </button>
            <div className="bg-white p-1 shadow-md">
              <ins
                ref={rightAdRef}
                className="adsbygoogle"
                style={{ display: "inline-block", width: "120px", height: "600px" }}
                data-ad-client="ca-pub-7609031768696978"
                data-ad-slot="3984599194"
              ></ins>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
