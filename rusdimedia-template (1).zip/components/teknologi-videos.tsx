import { fetchPostsByCategory } from "@/lib/api"
import Link from "next/link"
import { formatDate } from "@/lib/utils"
import OptimizedImage from "./optimized-image"

export default async function TeknologiArticles() {
  // Fetch posts from the "teknologi" category
  const posts = await fetchPostsByCategory("teknologi", 5)

  if (!posts || posts.length === 0) {
    return null
  }

  // Split posts for different layouts
  const featuredPost = posts[0]
  const secondaryPosts = posts.slice(1, 5)

  return (
    <div className="mb-8 px-2 sm:px-0">
      <div className="flex items-center justify-between mb-4">
        <h2 className="section-title mb-0">Teknologi</h2>
        <Link href="/kategori/teknologi" className="text-sm font-medium text-[#00acee] hover:underline">
          Lihat Semua
        </Link>
      </div>

      <div className="space-y-6">
        {/* Featured Article */}
        {featuredPost && (
          <article className="overflow-hidden rounded-lg border border-gray-100 hover:shadow-md transition-all duration-300">
            <Link href={`/${featuredPost.slug}`} className="block">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="relative aspect-[16/9] overflow-hidden">
                  {featuredPost._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                    <OptimizedImage
                      src={featuredPost._embedded["wp:featuredmedia"][0].source_url}
                      alt={featuredPost._embedded["wp:featuredmedia"][0].alt_text || featuredPost.title.rendered}
                      fill
                      loading="lazy"
                      className="object-cover transition-transform duration-300 hover:scale-105"
                      sizes="(max-width: 768px) 100vw, 50vw"
                      quality={80}
                    />
                  ) : (
                    <div className="h-full w-full bg-gray-300" />
                  )}
                </div>

                <div className="p-3 md:p-4">
                  <div className="mb-2">
                    <span className="inline-block rounded bg-[#00acee] px-2 py-1 text-xs font-bold text-white">
                      Teknologi
                    </span>
                    <span className="ml-2 text-xs text-gray-500">{formatDate(featuredPost.date)}</span>
                  </div>
                  <h3 className="text-sm md:text-xl font-bold leading-tight mb-2 hover:text-[#00acee] line-clamp-3 md:line-clamp-none">
                    <span dangerouslySetInnerHTML={{ __html: featuredPost.title.rendered }} />
                  </h3>
                  <div
                    className="text-xs md:text-sm text-gray-600 line-clamp-2 md:line-clamp-3"
                    dangerouslySetInnerHTML={{ __html: featuredPost.excerpt.rendered }}
                  />
                </div>
              </div>
            </Link>
          </article>
        )}

        {/* Secondary Articles Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {secondaryPosts.map((post) => (
            <article
              key={post.id}
              className="overflow-hidden rounded-lg border border-gray-100 hover:shadow-md transition-all duration-300"
            >
              <Link href={`/${post.slug}`}>
                <div className="relative aspect-[4/3] overflow-hidden">
                  {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                    <OptimizedImage
                      src={post._embedded["wp:featuredmedia"][0].source_url}
                      alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                      fill
                      loading="lazy"
                      className="object-cover transition-transform duration-300 hover:scale-105"
                      sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, 25vw"
                      quality={70}
                    />
                  ) : (
                    <div className="h-full w-full bg-gray-300" />
                  )}
                </div>
                <div className="p-2 sm:p-3">
                  <div className="mb-1 flex items-center justify-between">
                    <span className="text-xs text-gray-500">{formatDate(post.date)}</span>
                  </div>
                  <h4 className="text-xs sm:text-sm font-bold leading-tight hover:text-[#00acee] line-clamp-2">
                    <span dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                  </h4>
                </div>
              </Link>
            </article>
          ))}
        </div>
      </div>
    </div>
  )
}
