import { fetchPostsByCategory } from "@/lib/api"
import Link from "next/link"
import { formatDate } from "@/lib/utils"
import AdsBanner from "./ads-banner"
import OptimizedImage from "./optimized-image"

interface CategorySectionProps {
  title: string
  slug: string
  count?: number
}

export default async function CategorySection({ title, slug, count = 3 }: CategorySectionProps) {
  const posts = await fetchPostsByCategory(slug, count)

  if (!posts || posts.length === 0) {
    return null
  }

  const mainPost = posts[0]
  const otherPosts = posts.slice(1)

  return (
    <div>
      {/* AdSense Banner above Category Section */}
      <div className="mb-6 w-full">
        <AdsBanner
          slot="5489675951"
          format="horizontal"
          className="bg-gray-50 min-h-[90px] w-full flex items-center justify-center border border-gray-200 rounded-md mx-auto"
          lazyLoad={true}
        />
      </div>

      <div className="flex items-center justify-between">
        <h2 className="section-title">{title}</h2>
        <Link href={`/kategori/${slug}`} className="text-sm font-medium text-[#00acee] hover:underline">
          Lihat Semua
        </Link>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
        {/* Main post */}
        <div className="sm:col-span-2">
          <article className="article-card">
            <Link href={`/${mainPost.slug}`}>
              <div className="aspect-[16/9] relative">
                {mainPost._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                  <OptimizedImage
                    src={mainPost._embedded["wp:featuredmedia"][0].source_url}
                    alt={mainPost._embedded["wp:featuredmedia"][0].alt_text || mainPost.title.rendered}
                    fill
                    loading="lazy"
                    className="object-cover transition-transform duration-300 hover:scale-105"
                    sizes="(max-width: 640px) 100vw, (max-width: 768px) 66vw, 33vw"
                    quality={75}
                  />
                ) : (
                  <div className="h-full w-full bg-gray-300" />
                )}
              </div>
              <div className="p-4">
                <h3 className="article-title text-lg" dangerouslySetInnerHTML={{ __html: mainPost.title.rendered }} />
                <div className="article-meta mt-2">
                  <span>{formatDate(mainPost.date)}</span>
                </div>
                <div
                  className="mt-2 text-sm text-gray-600 line-clamp-2"
                  dangerouslySetInnerHTML={{ __html: mainPost.excerpt.rendered }}
                />
              </div>
            </Link>
          </article>
        </div>

        {/* Other posts */}
        <div className="space-y-4">
          {otherPosts.map((post) => (
            <article key={post.id} className="flex gap-4">
              <div className="flex-none">
                <div className="relative h-16 w-16 overflow-hidden rounded-md">
                  {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                    <OptimizedImage
                      src={post._embedded["wp:featuredmedia"][0].source_url}
                      alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                      fill
                      loading="lazy"
                      className="object-cover"
                      sizes="64px"
                      quality={70} // Lower quality for smaller thumbnails
                    />
                  ) : (
                    <div className="h-full w-full bg-gray-300" />
                  )}
                </div>
              </div>
              <div>
                <h3 className="text-sm font-bold leading-tight">
                  <Link href={`/${post.slug}`} className="hover:text-red-600">
                    <span dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                  </Link>
                </h3>
                <div className="mt-1 text-xs text-gray-500">{formatDate(post.date)}</div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  )
}
