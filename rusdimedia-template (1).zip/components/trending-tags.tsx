"use client"

import React from "react"

import { useEffect, useState, useRef } from "react"
import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { fetchPopularTagsWithFallback } from "@/lib/fetch-utils"

interface Tag {
  id: number
  name: string
  slug: string
  count: number
}

export default function TrendingTags() {
  const [tags, setTags] = useState<Tag[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    async function loadTags() {
      try {
        setIsLoading(true)
        // Use the enhanced fetch function with fallback
        const popularTags = await fetchPopularTagsWithFallback()
        setTags(popularTags)
      } catch (err) {
        console.error("Error loading tags:", err)
        // Fallback is handled in the fetchPopularTagsWithFallback function
      } finally {
        setIsLoading(false)
      }
    }

    loadTags()
  }, [])

  const scroll = (direction: "left" | "right") => {
    if (!scrollContainerRef.current) return

    const scrollAmount = 200
    const container = scrollContainerRef.current

    if (direction === "left") {
      container.scrollBy({ left: -scrollAmount, behavior: "smooth" })
    } else {
      container.scrollBy({ left: scrollAmount, behavior: "smooth" })
    }
  }

  if (isLoading) {
    return (
      <div className="relative bg-gray-50 border-y border-gray-200 py-2 overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="flex items-center space-x-4">
            <span className="text-blue-600 font-medium whitespace-nowrap">TRENDING:</span>
            <div className="flex-1 overflow-hidden">
              <div className="flex space-x-6">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="h-5 bg-gray-200 animate-pulse rounded w-32"></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (tags.length === 0) {
    return null
  }

  return (
    <div className="relative bg-gray-50 border-y border-gray-200 py-2 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="flex items-center">
          <button
            onClick={() => scroll("left")}
            className="text-gray-500 hover:text-gray-700 focus:outline-none"
            aria-label="Scroll left"
          >
            <ChevronLeft size={20} />
          </button>

          <span className="text-primary font-medium mx-2 whitespace-nowrap">TRENDING:</span>

          <div className="flex-1 overflow-hidden">
            <div
              ref={scrollContainerRef}
              className="flex overflow-x-auto scrollbar-hide"
              style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
            >
              {tags.map((tag, index) => (
                <React.Fragment key={tag.id}>
                  <Link href={`/tags/${tag.slug}`} className="whitespace-nowrap text-gray-700 hover:text-gray-900 px-1">
                    {tag.name}
                  </Link>
                  {index < tags.length - 1 && <span className="text-gray-300 mx-2">|</span>}
                </React.Fragment>
              ))}
            </div>
          </div>

          <button
            onClick={() => scroll("right")}
            className="text-gray-500 hover:text-gray-700 focus:outline-none"
            aria-label="Scroll right"
          >
            <ChevronRight size={20} />
          </button>
        </div>
      </div>
    </div>
  )
}
