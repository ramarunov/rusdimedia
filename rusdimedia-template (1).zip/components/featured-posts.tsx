"use client"

import { useEffect, useState, useRef } from "react"
import Link from "next/link"
import { formatDate } from "@/lib/utils"
import OptimizedImage from "./optimized-image"

interface Post {
  id: number
  date: string
  title: {
    rendered: string
  }
  slug: string
  _embedded?: {
    "wp:featuredmedia"?: Array<{
      source_url: string
      alt_text: string
    }>
    "wp:term"?: Array<
      Array<{
        id: number
        name: string
        slug: string
      }>
    >
  }
}

// Function to calculate time since publication
function getTimeSince(dateString: string): string {
  const now = new Date()
  const publishedDate = new Date(dateString)
  const diffInSeconds = Math.floor((now.getTime() - publishedDate.getTime()) / 1000)

  if (diffInSeconds < 60) {
    return `${diffInSeconds} detik yang lalu`
  }

  const diffInMinutes = Math.floor(diffInSeconds / 60)
  if (diffInMinutes < 60) {
    return `${diffInMinutes} menit yang lalu`
  }

  const diffInHours = Math.floor(diffInMinutes / 60)
  if (diffInHours < 24) {
    return `${diffInHours} jam yang lalu`
  }

  const diffInDays = Math.floor(diffInHours / 24)
  if (diffInDays < 30) {
    return `${diffInDays} hari yang lalu`
  }

  const diffInMonths = Math.floor(diffInDays / 30)
  if (diffInMonths < 12) {
    return `${diffInMonths} bulan yang lalu`
  }

  const diffInYears = Math.floor(diffInMonths / 12)
  return `${diffInYears} tahun yang lalu`
}

export default function LatestPosts() {
  const [posts, setPosts] = useState<Post[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const abortControllerRef = useRef<AbortController | null>(null)
  const hasMounted = useRef(false)

  async function fetchLatestPosts() {
    try {
      setIsLoading(true)

      // Cancel any previous requests
      if (abortControllerRef.current) {
        abortControllerRef.current.abort()
      }

      // Create a new abort controller for this request
      abortControllerRef.current = new AbortController()

      // Fetch latest posts directly without category filtering
      const url = "https://dash.rusdimedia.com/wp-json/wp/v2/posts?per_page=5&_embed=true"

      const postsResponse = await fetch(url, {
        signal: abortControllerRef.current.signal,
        cache: "force-cache",
      })

      if (!postsResponse.ok) {
        throw new Error(`Failed to fetch posts: ${postsResponse.status}`)
      }

      const postsData = await postsResponse.json()
      setPosts(postsData)
    } catch (error) {
      // Only set error if it's not an abort error
      if (error instanceof Error && error.name !== "AbortError") {
        console.error("Error fetching latest posts:", error)
        setError("Failed to load latest posts")
      }
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    // Avoid duplicate fetches on strict mode double-render
    if (hasMounted.current) return
    hasMounted.current = true

    // Add preconnect for image domain to speed up image loading
    const linkEl = document.createElement("link")
    linkEl.rel = "preconnect"
    linkEl.href = "https://dash.rusdimedia.com"
    document.head.appendChild(linkEl)

    fetchLatestPosts()

    // Cleanup function
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort()
      }
      // Remove the preconnect link on unmount
      document.head.removeChild(linkEl)
    }
  }, [])

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-1 space-y-4">
          {[...Array(2)].map((_, i) => (
            <div key={`left-${i}`} className="aspect-[4/3] animate-pulse bg-gray-200 rounded-lg"></div>
          ))}
        </div>
        <div className="md:col-span-1 aspect-[3/4] animate-pulse bg-gray-200 rounded-lg"></div>
        <div className="md:col-span-1 space-y-4">
          {[...Array(2)].map((_, i) => (
            <div key={`right-${i}`} className="aspect-[4/3] animate-pulse bg-gray-200 rounded-lg"></div>
          ))}
        </div>
      </div>
    )
  }

  if (error || posts.length === 0) {
    return null
  }

  // Ensure we have at least 5 posts
  const latestPosts = posts.slice(0, Math.min(5, posts.length))

  // If we have less than 5 posts, duplicate the last one to fill the grid
  while (latestPosts.length < 5) {
    latestPosts.push(latestPosts[latestPosts.length - 1])
  }

  const mainPost = latestPosts[0]
  const leftTopPost = latestPosts[1]
  const leftBottomPost = latestPosts[2]
  const rightTopPost = latestPosts[3]
  const rightBottomPost = latestPosts[4]

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      {/* Left Column - 2 posts */}
      <div className="md:col-span-1 space-y-4">
        {/* Left Top Post - Modified for mobile left image layout */}
        <article className="overflow-hidden rounded-lg border border-gray-100 hover:shadow-md transition-all duration-300 flex flex-row md:flex-col">
          <Link href={`/${leftTopPost.slug}`} className="flex flex-row md:block w-full">
            <div className="relative w-1/3 md:w-full aspect-square md:aspect-[16/9]">
              {leftTopPost._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                <OptimizedImage
                  src={leftTopPost._embedded["wp:featuredmedia"][0].source_url}
                  alt={leftTopPost._embedded["wp:featuredmedia"][0].alt_text || leftTopPost.title.rendered}
                  fill
                  loading="lazy"
                  className="object-cover"
                  sizes="(max-width: 768px) 33vw, 33vw"
                  quality={70}
                />
              ) : (
                <div className="h-full w-full bg-gray-300" />
              )}
            </div>
            <div className="p-3 flex-1 flex flex-col justify-between">
              <div>
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-xs font-medium text-[#00acee]">
                    {leftTopPost._embedded?.["wp:term"]?.[0]?.[0]?.name || "Berita"}
                  </span>
                  <span className="text-xs text-gray-500">{getTimeSince(leftTopPost.date)}</span>
                </div>
                <h3
                  className="text-sm font-bold leading-tight line-clamp-2 md:line-clamp-3"
                  dangerouslySetInnerHTML={{ __html: leftTopPost.title.rendered }}
                />
              </div>
            </div>
          </Link>
        </article>

        {/* Left Bottom Post - Modified for mobile left image layout */}
        <article className="overflow-hidden rounded-lg border border-gray-100 hover:shadow-md transition-all duration-300 flex flex-row md:flex-col">
          <Link href={`/${leftBottomPost.slug}`} className="flex flex-row md:block w-full">
            <div className="relative w-1/3 md:w-full aspect-square md:aspect-[16/9]">
              {leftBottomPost._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                <OptimizedImage
                  src={leftBottomPost._embedded["wp:featuredmedia"][0].source_url}
                  alt={leftBottomPost._embedded["wp:featuredmedia"][0].alt_text || leftBottomPost.title.rendered}
                  fill
                  loading="lazy"
                  className="object-cover"
                  sizes="(max-width: 768px) 33vw, 33vw"
                  quality={70}
                />
              ) : (
                <div className="h-full w-full bg-gray-300" />
              )}
            </div>
            <div className="p-3 flex-1 flex flex-col justify-between">
              <div>
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-xs font-medium text-[#00acee]">
                    {leftBottomPost._embedded?.["wp:term"]?.[0]?.[0]?.name || "Berita"}
                  </span>
                  <span className="text-xs text-gray-500">{getTimeSince(leftBottomPost.date)}</span>
                </div>
                <h3
                  className="text-sm font-bold leading-tight line-clamp-2 md:line-clamp-3"
                  dangerouslySetInnerHTML={{ __html: leftBottomPost.title.rendered }}
                />
              </div>
            </div>
          </Link>
        </article>
      </div>

      {/* Center Column - Main Post - Modified for mobile left image layout */}
      <div className="md:col-span-1">
        <article className="overflow-hidden rounded-lg border border-gray-100 hover:shadow-md transition-all duration-300 h-full flex flex-row md:flex-col">
          <Link href={`/${mainPost.slug}`} className="flex flex-row md:flex-col h-full w-full">
            <div className="relative w-1/3 md:w-full aspect-square md:aspect-auto md:h-[70%]">
              {mainPost._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                <OptimizedImage
                  src={mainPost._embedded["wp:featuredmedia"][0].source_url}
                  alt={mainPost._embedded["wp:featuredmedia"][0].alt_text || mainPost.title.rendered}
                  fill
                  priority
                  fetchPriority="high"
                  loading="eager"
                  className="object-cover"
                  sizes="(max-width: 768px) 33vw, 33vw"
                  quality={85}
                />
              ) : (
                <div className="h-full w-full bg-gray-300" />
              )}
            </div>
            <div className="p-4 flex-1 md:h-[30%] flex flex-col justify-between">
              <div>
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-xs font-medium text-[#00acee]">
                    {mainPost._embedded?.["wp:term"]?.[0]?.[0]?.name || "Berita"}
                  </span>
                  <span className="text-xs text-gray-500">{getTimeSince(mainPost.date)}</span>
                </div>
                <h2
                  className="text-base md:text-lg font-bold leading-tight md:text-xl line-clamp-3 md:line-clamp-none"
                  dangerouslySetInnerHTML={{ __html: mainPost.title.rendered }}
                />
              </div>
              <div className="mt-auto text-xs text-gray-500 pt-2 hidden md:block">{formatDate(mainPost.date)}</div>
            </div>
          </Link>
        </article>
      </div>

      {/* Right Column - 2 posts */}
      <div className="md:col-span-1 space-y-4">
        {/* Right Top Post - Modified for mobile left image layout */}
        <article className="overflow-hidden rounded-lg border border-gray-100 hover:shadow-md transition-all duration-300 flex flex-row md:flex-col">
          <Link href={`/${rightTopPost.slug}`} className="flex flex-row md:block w-full">
            <div className="relative w-1/3 md:w-full aspect-square md:aspect-[16/9]">
              {rightTopPost._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                <OptimizedImage
                  src={rightTopPost._embedded["wp:featuredmedia"][0].source_url}
                  alt={rightTopPost._embedded["wp:featuredmedia"][0].alt_text || rightTopPost.title.rendered}
                  fill
                  loading="lazy"
                  className="object-cover"
                  sizes="(max-width: 768px) 33vw, 33vw"
                  quality={70}
                />
              ) : (
                <div className="h-full w-full bg-gray-300" />
              )}
            </div>
            <div className="p-3 flex-1 flex flex-col justify-between">
              <div>
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-xs font-medium text-[#00acee]">
                    {rightTopPost._embedded?.["wp:term"]?.[0]?.[0]?.name || "Berita"}
                  </span>
                  <span className="text-xs text-gray-500">{getTimeSince(rightTopPost.date)}</span>
                </div>
                <h3
                  className="text-sm font-bold leading-tight line-clamp-2 md:line-clamp-3"
                  dangerouslySetInnerHTML={{ __html: rightTopPost.title.rendered }}
                />
              </div>
            </div>
          </Link>
        </article>

        {/* Right Bottom Post - Modified for mobile left image layout */}
        <article className="overflow-hidden rounded-lg border border-gray-100 hover:shadow-md transition-all duration-300 flex flex-row md:flex-col">
          <Link href={`/${rightBottomPost.slug}`} className="flex flex-row md:block w-full">
            <div className="relative w-1/3 md:w-full aspect-square md:aspect-[16/9]">
              {rightBottomPost._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                <OptimizedImage
                  src={rightBottomPost._embedded["wp:featuredmedia"][0].source_url}
                  alt={rightBottomPost._embedded["wp:featuredmedia"][0].alt_text || rightBottomPost.title.rendered}
                  fill
                  loading="lazy"
                  className="object-cover"
                  sizes="(max-width: 768px) 33vw, 33vw"
                  quality={70}
                />
              ) : (
                <div className="h-full w-full bg-gray-300" />
              )}
            </div>
            <div className="p-3 flex-1 flex flex-col justify-between">
              <div>
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-xs font-medium text-[#00acee]">
                    {rightBottomPost._embedded?.["wp:term"]?.[0]?.[0]?.name || "Berita"}
                  </span>
                  <span className="text-xs text-gray-500">{getTimeSince(rightBottomPost.date)}</span>
                </div>
                <h3
                  className="text-sm font-bold leading-tight line-clamp-2 md:line-clamp-3"
                  dangerouslySetInnerHTML={{ __html: rightBottomPost.title.rendered }}
                />
              </div>
            </div>
          </Link>
        </article>
      </div>
    </div>
  )
}
