"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { formatDate } from "@/lib/utils"
import OptimizedImage from "./optimized-image"

interface Post {
  id: number
  date: string
  title: {
    rendered: string
  }
  excerpt: {
    rendered: string
  }
  slug: string
  _embedded?: {
    "wp:featuredmedia"?: Array<{
      source_url: string
      alt_text: string
    }>
    "wp:term"?: Array<
      Array<{
        id: number
        name: string
        slug: string
      }>
    >
  }
}

export default function KesehatanSection() {
  const [posts, setPosts] = useState<Post[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchKesehatanPosts() {
      try {
        setIsLoading(true)

        // First, try to get the category ID for "kesehatan" with better error handling
        let categoryId = null

        try {
          const categoryResponse = await fetch(
            "https://dash.rusdimedia.com/wp-json/wp/v2/categories?slug=kesehatan",
            { next: { revalidate: 3600 } }, // Cache for 1 hour
          )

          if (categoryResponse.ok) {
            const categories = await categoryResponse.json()
            if (categories && categories.length) {
              categoryId = categories[0].id
            }
          } else {
            console.warn(`Category API responded with status: ${categoryResponse.status}`)
          }
        } catch (categoryError) {
          console.error("Error fetching kesehatan category:", categoryError)
        }

        // If we couldn't get the category ID, use a fallback approach
        if (!categoryId) {
          // Try to fetch recent posts and filter them client-side
          const fallbackResponse = await fetch(
            `https://dash.rusdimedia.com/wp-json/wp/v2/posts?per_page=20&_embed=true`,
            { next: { revalidate: 300 } }, // Cache for 5 minutes
          )

          if (fallbackResponse.ok) {
            const allPosts = await fallbackResponse.json()
            // Try to find posts that might be related to health
            const healthPosts = allPosts.filter((post) => {
              const title = post.title.rendered.toLowerCase()
              const excerpt = post.excerpt.rendered.toLowerCase()
              const healthKeywords = ["kesehatan", "health", "sehat", "penyakit", "obat", "dokter", "rumah sakit"]
              return healthKeywords.some((keyword) => title.includes(keyword) || excerpt.includes(keyword))
            })

            if (healthPosts.length > 0) {
              setPosts(healthPosts.slice(0, 5))
              setIsLoading(false)
              return
            }
          }

          // If all else fails, use hardcoded fallback data
          setPosts([])
          setError("Konten kesehatan tidak tersedia saat ini")
          setIsLoading(false)
          return
        }

        // If we have the category ID, fetch posts as normal
        try {
          const postsResponse = await fetch(
            `https://dash.rusdimedia.com/wp-json/wp/v2/posts?categories=${categoryId}&per_page=5&_embed=true`,
            { next: { revalidate: 300 } }, // Cache for 5 minutes
          )

          if (postsResponse.ok) {
            const postsData = await postsResponse.json()
            setPosts(postsData)
          } else {
            console.error(`Posts API responded with status: ${postsResponse.status}`)
            setError("Gagal memuat artikel kesehatan")
          }
        } catch (postsError) {
          console.error("Error fetching kesehatan posts:", postsError)
          setError("Gagal memuat artikel kesehatan")
        }
      } catch (error) {
        console.error("Error in kesehatan section:", error)
        setError("Terjadi kesalahan saat memuat konten")
      } finally {
        setIsLoading(false)
      }
    }

    fetchKesehatanPosts()
  }, [])

  // Function to strip HTML tags
  const stripHtml = (html: string) => {
    return html.replace(/<[^>]*>/g, "")
  }

  if (isLoading) {
    return (
      <div className="mb-8">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="section-title mb-0">Kesehatan</h2>
        </div>
        <div className="animate-pulse">
          <div className="mb-6">
            <div className="aspect-[16/9] w-full bg-gray-200 rounded-lg"></div>
            <div className="mt-3 h-6 bg-gray-200 rounded w-3/4"></div>
            <div className="mt-2 h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="mt-2 h-4 bg-gray-200 rounded w-full"></div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex gap-3">
                <div className="h-20 w-20 bg-gray-200 rounded-lg flex-shrink-0"></div>
                <div className="flex-1">
                  <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-full mb-1"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (error || posts.length === 0) {
    return (
      <div className="mb-8 px-2 sm:px-4 py-4 bg-white rounded-lg border border-gray-100 shadow-sm">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="section-title mb-0">Kesehatan</h2>
          <Link href="/kategori/kesehatan" className="text-sm font-medium text-primary hover:underline">
            Lihat Semua
          </Link>
        </div>

        {error ? (
          <div className="p-4 text-center">
            <p className="text-gray-500">{error}</p>
            <p className="mt-2 text-sm text-gray-400">Silakan coba lagi nanti</p>
          </div>
        ) : (
          <div className="p-4 text-center">
            <p className="text-gray-500">Belum ada artikel kesehatan terbaru</p>
            <Link href="/kategori/kesehatan" className="mt-2 inline-block text-sm text-primary hover:underline">
              Jelajahi semua artikel kesehatan
            </Link>
          </div>
        )}
      </div>
    )
  }

  // Split posts for different layouts
  const mainPost = posts[0]
  const smallPosts = posts.slice(1, 5)

  return (
    <div className="mb-8 px-2 sm:px-4 py-4 bg-white rounded-lg border border-gray-100 shadow-sm">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="section-title mb-0">Kesehatan</h2>
        <Link href="/kategori/kesehatan" className="text-sm font-medium text-[#00acee] hover:underline">
          Lihat Semua
        </Link>
      </div>

      {/* Main Featured Post */}
      {mainPost && (
        <div className="mb-6 overflow-hidden rounded-lg border border-gray-100 hover:shadow-md transition-all duration-300">
          <Link href={`/${mainPost.slug}`} className="block">
            <div className="relative aspect-[16/9] overflow-hidden">
              {mainPost._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                <OptimizedImage
                  src={mainPost._embedded["wp:featuredmedia"][0].source_url}
                  alt={mainPost._embedded["wp:featuredmedia"][0].alt_text || mainPost.title.rendered}
                  fill
                  loading="eager"
                  className="object-cover transition-transform duration-300 hover:scale-105"
                  sizes="(max-width: 768px) 100vw, 50vw"
                  quality={80}
                />
              ) : (
                <div className="h-full w-full bg-gray-300" />
              )}

              {/* Category label */}
              <div className="absolute top-0 left-0 bg-primary text-white text-xs font-bold px-3 py-1 m-3">
                KESEHATAN
              </div>

              {/* Purple triangle in corner */}
              <div className="absolute bottom-0 right-0 w-0 h-0 border-solid border-t-[20px] border-l-[20px] border-t-transparent border-l-transparent border-b-primary border-r-primary transform rotate-180"></div>
            </div>

            <div className="p-4">
              {/* Date */}
              <div className="text-xs text-gray-500 mb-2">{formatDate(mainPost.date)}</div>

              {/* Title */}
              <h3 className="text-xl font-bold leading-tight mb-2 hover:text-[#00acee]">
                <span dangerouslySetInnerHTML={{ __html: mainPost.title.rendered }} />
              </h3>

              {/* Excerpt */}
              <div className="text-sm text-gray-600 line-clamp-2">{stripHtml(mainPost.excerpt.rendered)}</div>
            </div>
          </Link>
        </div>
      )}

      {/* Grid of smaller posts */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {smallPosts.map((post) => (
          <article
            key={post.id}
            className="flex gap-3 overflow-hidden rounded-lg border border-gray-100 hover:shadow-md transition-all duration-300 p-3"
          >
            {/* Thumbnail */}
            <div className="relative h-20 w-20 flex-shrink-0 overflow-hidden rounded-lg">
              {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                <OptimizedImage
                  src={post._embedded["wp:featuredmedia"][0].source_url}
                  alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                  fill
                  loading="lazy"
                  className="object-cover"
                  sizes="80px"
                  quality={70}
                />
              ) : (
                <div className="h-full w-full bg-gray-300" />
              )}
            </div>

            <div className="flex-1">
              {/* Category label */}
              <div className="text-xs font-bold text-primary mb-1">
                {post._embedded?.["wp:term"]?.[0]?.[0]?.name || "KESEHATAN"}
              </div>

              {/* Title */}
              <h4 className="text-sm font-bold leading-tight hover:text-[#00acee] line-clamp-2">
                <Link href={`/${post.slug}`}>
                  <span dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                </Link>
              </h4>

              {/* Date */}
              <div className="mt-1 text-xs text-gray-500">{formatDate(post.date)}</div>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}
