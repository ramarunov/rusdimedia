"use client"

import Image, { type ImageProps } from "next/image"
import { useState, useEffect, memo } from "react"

interface BetterImageProps extends Omit<ImageProps, "onLoad" | "onError"> {
  fallbackSrc?: string
}

// Create a memoized version of the component to prevent unnecessary re-renders
const BetterImage = memo(function BetterImage({
  src,
  alt,
  fallbackSrc = "/placeholder.svg",
  className = "",
  priority = false,
  ...props
}: BetterImageProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(false)
  const [imgSrc, setImgSrc] = useState<string | any>(src)

  // Reset loading state when src changes
  useEffect(() => {
    setIsLoading(true)
    setError(false)
    setImgSrc(src)
  }, [src])

  // Generate a simple color placeholder based on the alt text
  const generateColorPlaceholder = (text: string) => {
    let hash = 0
    for (let i = 0; i < text.length; i++) {
      hash = text.charCodeAt(i) + ((hash << 5) - hash)
    }
    const color = `hsl(${hash % 360}, 70%, 80%)`
    return color
  }

  const placeholderColor = generateColorPlaceholder(alt)

  // Check if the URL is valid (not a future date)
  const isFutureDate = (url: string) => {
    if (typeof url !== "string") return false
    const currentYear = new Date().getFullYear()
    const match = url.match(/\/(\d{4})\/\d{2}\//)
    return match && Number.parseInt(match[1]) > currentYear
  }

  // Format image URL for better loading
  const getOptimizedImageUrl = (url: string) => {
    if (typeof url !== "string" || !url.includes("dash.rusdimedia.com")) {
      return url
    }

    // If the URL already has a query parameter
    if (url.includes("?")) {
      return `${url}&format=webp&quality=80`
    }

    // Otherwise, add a new query parameter
    return `${url}?format=webp&quality=80`
  }

  // Use smaller image dimensions for thumbnails
  const getImageSrc = () => {
    if (typeof src !== "string") {
      return imgSrc
    }

    // Check for future dates that would cause 404s
    if (isFutureDate(src)) {
      return fallbackSrc
    }

    // Only process WordPress URLs
    if (!src.includes("dash.rusdimedia.com")) {
      return imgSrc
    }

    // Try to use WebP format
    const webpUrl = getOptimizedImageUrl(src)

    // If height or width is small (thumbnail), use smaller image
    const isSmallImage =
      (props.width && typeof props.width === "number" && props.width < 200) ||
      (props.height && typeof props.height === "number" && props.height < 200)

    if (isSmallImage && webpUrl.includes("/uploads/")) {
      // Add -300x200 before the extension for WordPress thumbnails
      if (!webpUrl.match(/-\d+x\d+\.[^.]+$/)) {
        return webpUrl.replace(/(\.[^.]+)$/, "-300x200$1")
      }
    }

    return webpUrl
  }

  // Determine if we should use the fallback
  const finalSrc = error || isFutureDate(typeof src === "string" ? src : "") ? fallbackSrc : getImageSrc()

  return (
    <>
      {isLoading && !priority && (
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gray-200"
          style={{
            backgroundColor: placeholderColor,
            aspectRatio: props.width && props.height ? `${props.width}/${props.height}` : undefined,
          }}
        />
      )}
      <Image
        src={finalSrc || "/placeholder.svg"}
        alt={alt}
        className={`${className} transition-opacity duration-300`}
        style={{
          opacity: isLoading && !priority ? 0 : 1,
          objectFit: "cover",
        }}
        onLoadingComplete={() => setIsLoading(false)}
        onError={() => {
          setError(true)
          setIsLoading(false)
        }}
        {...props}
      />
    </>
  )
})

export default BetterImage
