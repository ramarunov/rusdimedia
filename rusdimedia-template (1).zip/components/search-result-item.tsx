import Link from "next/link"
import { formatDate } from "@/lib/utils"
import OptimizedImage from "./optimized-image"

interface SearchResultItemProps {
  post: any
  query: string
}

export default function SearchResultItem({ post, query }: SearchResultItemProps) {
  // Highlight search terms in the title and excerpt
  const highlightSearchTerms = (text: string, searchTerm: string) => {
    if (!searchTerm.trim()) return text

    // First, strip HTML tags
    const strippedText = text.replace(/<[^>]*>/g, "")

    // Create a regex that matches the search term (case insensitive)
    const regex = new RegExp(`(${searchTerm.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi")

    // Replace matches with highlighted version
    return strippedText.replace(regex, '<mark class="bg-yellow-100 px-1 rounded">$1</mark>')
  }

  // Get highlighted title and excerpt
  const highlightedTitle = highlightSearchTerms(post.title.rendered, query)
  const highlightedExcerpt = highlightSearchTerms(post.excerpt.rendered, query)

  return (
    <article className="flex flex-col md:flex-row gap-4 border-b border-gray-100 pb-6">
      {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url && (
        <div className="md:w-1/4 flex-shrink-0">
          <Link href={`/${post.slug}`} className="block">
            <div className="aspect-[16/9] relative overflow-hidden rounded-lg">
              <OptimizedImage
                src={post._embedded["wp:featuredmedia"][0].source_url}
                alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                fill
                loading="lazy"
                className="object-cover transition-transform duration-300 hover:scale-105"
                sizes="(max-width: 768px) 100vw, 25vw"
                quality={75}
              />
            </div>
          </Link>
        </div>
      )}
      <div className={post._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? "md:w-3/4" : "w-full"}>
        {post._embedded?.["wp:term"]?.[0]?.[0] && (
          <Link
            href={`/kategori/${post._embedded["wp:term"][0][0].slug}`}
            className="mb-2 inline-block text-sm font-medium text-[#00acee] hover:underline"
          >
            {post._embedded["wp:term"][0][0].name}
          </Link>
        )}
        <h2 className="mb-2 text-xl font-bold leading-tight">
          <Link href={`/${post.slug}`} className="hover:text-[#00acee]">
            <span dangerouslySetInnerHTML={{ __html: highlightedTitle }} />
          </Link>
        </h2>
        <div className="mb-2 text-sm text-gray-500">{formatDate(post.date)}</div>
        <div className="text-gray-600 line-clamp-3" dangerouslySetInnerHTML={{ __html: highlightedExcerpt }} />
      </div>
    </article>
  )
}
