import { fetchPostsByCategory } from "@/lib/api"
import Link from "next/link"
import { formatDate } from "@/lib/utils"
import OptimizedImage from "./optimized-image"

export default async function SerbaSerbiPosts() {
  // Fetch posts from the "serba-serbi" category
  let posts = []

  try {
    posts = await fetchPostsByCategory("serba-serbi", 4)
  } catch (error) {
    console.error("Error fetching serba-serbi posts:", error)
    return null
  }

  if (!posts || posts.length === 0) {
    return null
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="section-title mb-0">Serba-serbi</h2>
        <Link href="/kategori/serba-serbi" className="text-sm font-medium text-[#00acee] hover:underline">
          Lihat Semua
        </Link>
      </div>
      <div className="space-y-4">
        {posts.map((post) => (
          <article key={post.id} className="flex gap-4">
            <div className="flex-none">
              <div className="relative h-20 w-20 overflow-hidden rounded-md">
                {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                  <OptimizedImage
                    src={post._embedded["wp:featuredmedia"][0].source_url}
                    alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                    fill
                    loading="lazy"
                    className="object-cover"
                    sizes="80px"
                    quality={70}
                  />
                ) : (
                  <div className="h-full w-full bg-gray-300" />
                )}
              </div>
            </div>
            <div>
              <h3 className="text-sm font-bold leading-tight">
                <Link href={`/${post.slug}`} className="hover:text-[#00acee]">
                  <span dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                </Link>
              </h3>
              <div className="mt-1 text-xs text-gray-500">{formatDate(post.date)}</div>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}
