"use client"

import AdsBanner from "./ads-banner"

export default function HeaderBannerAd() {
  return (
    <div className="w-full bg-gray-50 py-3">
      <div className="mx-auto max-w-[1080px] px-4">
        <AdsBanner
          slot="6805010756"
          format="horizontal"
          responsive={true}
          className="mx-auto"
          lazyLoad={false} // Load immediately for header visibility
        />
      </div>
    </div>
  )
}
