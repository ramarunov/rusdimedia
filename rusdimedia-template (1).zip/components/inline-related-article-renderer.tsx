"use client"

import { useEffect } from "react"
import InlineRelatedArticle from "./inline-related-article"

interface InlineRelatedArticleRendererProps {
  tags: Array<{
    id: number
    name: string
    slug: string
  }>
  currentPostId: number
}

export default function InlineRelatedArticleRenderer({ tags, currentPostId }: InlineRelatedArticleRendererProps) {
  useEffect(() => {
    // Find the placeholder in the content
    const placeholder = document.getElementById("inline-related-articles-placeholder")

    if (placeholder) {
      // Create a new div to render the related articles
      const relatedArticlesContainer = document.createElement("div")
      placeholder.appendChild(relatedArticlesContainer)

      // Render the InlineRelatedArticle component into the container
      const root = document.createRoot(relatedArticlesContainer)
      root.render(<InlineRelatedArticle tags={tags} currentPostId={currentPostId} />)
    }
  }, [tags, currentPostId])

  return null
}
