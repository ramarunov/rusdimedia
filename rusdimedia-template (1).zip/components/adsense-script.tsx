"use client"

export default function AdSenseScript() {
  // This component is now empty as we're handling the script directly in layout.tsx
  return null
}
