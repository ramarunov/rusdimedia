"use client"

import { useEffect, useState, useRef } from "react"
import { X, Hash } from "lucide-react"
import { useRouter } from "next/navigation"

interface Category {
  id: number
  name: string
  slug: string
  count: number
}

interface MobileMenuProps {
  isOpen: boolean
  onClose: () => void
}

export default function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const menuRef = useRef<HTMLDivElement>(null)
  const router = useRouter()

  // Fetch categories from the API
  useEffect(() => {
    async function fetchCategories() {
      try {
        const response = await fetch("https://dash.rusdimedia.com/wp-json/wp/v2/categories?per_page=100")
        if (!response.ok) {
          throw new Error("Failed to fetch categories")
        }
        const data = await response.json()

        // Sort categories by count (most posts first)
        const sortedCategories = data.sort((a: Category, b: Category) => b.count - a.count)

        // Filter out categories with no posts
        const filteredCategories = sortedCategories.filter((cat: Category) => cat.count > 0)

        setCategories(filteredCategories)
      } catch (error) {
        console.error("Error fetching categories:", error)
      } finally {
        setLoading(false)
      }
    }

    if (isOpen) {
      fetchCategories()
    }
  }, [isOpen])

  // Close menu when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose()
      }
    }

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside)
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [isOpen, onClose])

  // Prevent body scrolling when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = ""
    }

    return () => {
      document.body.style.overflow = ""
    }
  }, [isOpen])

  // Handle navigation and close menu
  const handleNavigation = (href: string) => {
    router.push(href)
    onClose()
  }

  return (
    <div
      className={`fixed inset-0 z-50 bg-black bg-opacity-50 transition-opacity duration-300 ${
        isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
      }`}
    >
      <div
        ref={menuRef}
        className={`fixed top-0 right-0 h-full w-[80%] max-w-sm bg-white transform transition-transform duration-300 ease-in-out overflow-y-auto ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h2 className="text-lg font-bold">Menu</h2>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-100" aria-label="Close menu">
            <X className="h-6 w-6" />
          </button>
        </div>

        <nav className="p-4">
          <ul className="space-y-2">
            <li>
              <button
                onClick={() => handleNavigation("/")}
                className="w-full text-left py-2 px-3 rounded-md hover:bg-gray-100 font-medium"
              >
                Beranda
              </button>
            </li>

            {/* Add Tags link */}
            <li>
              <button
                onClick={() => handleNavigation("/tags")}
                className="w-full text-left py-2 px-3 rounded-md hover:bg-gray-100 font-medium flex items-center"
              >
                <Hash className="h-4 w-4 mr-2" />
                Semua Tag
              </button>
            </li>

            <li className="pt-2 border-t border-gray-100">
              <h3 className="px-3 text-sm font-semibold text-gray-500 uppercase">Kategori</h3>
            </li>

            {loading ? (
              <div className="p-4 space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="h-8 bg-gray-200 rounded animate-pulse"></div>
                ))}
              </div>
            ) : (
              categories.map((category) => (
                <li key={category.id}>
                  <button
                    onClick={() => handleNavigation(`/kategori/${category.slug}`)}
                    className="w-full text-left py-2 px-3 rounded-md hover:bg-gray-100 flex items-center justify-between"
                  >
                    <span>{category.name}</span>
                    <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">{category.count}</span>
                  </button>
                </li>
              ))
            )}
          </ul>
        </nav>
      </div>
    </div>
  )
}
