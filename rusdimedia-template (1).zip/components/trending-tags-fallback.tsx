export default function TrendingTagsFallback() {
  return (
    <div className="relative bg-gray-50 border-y border-gray-200 py-2 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="flex items-center">
          <span className="text-red-600 font-medium mx-2">TRENDING:</span>
          <div className="flex-1 overflow-hidden">
            <div className="flex space-x-4">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-5 bg-gray-200 animate-pulse rounded w-24"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
