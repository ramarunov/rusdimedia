import type React from "react"
import { cn } from "@/lib/utils"

interface ShellProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode
  className?: string
}

export function Shell({ children, className, ...props }: ShellProps) {
  return (
    <div className={cn("mx-auto w-full max-w-[1080px] px-4 py-6", className)} {...props}>
      {children}
    </div>
  )
}
