import Image from "next/image"

interface AuthorInfoProps {
  name: string
  avatar?: string
  role?: string
  bio?: string
}

export default function AuthorInfo({ name, avatar, role = "Penulis", bio }: AuthorInfoProps) {
  return (
    <div className="flex items-start">
      <div className="mr-3 h-10 w-10 overflow-hidden rounded-full bg-gray-200">
        {avatar ? (
          <Image
            src={avatar || "/placeholder.svg"}
            alt={name}
            width={40}
            height={40}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-[#00acee] text-white">
            {name.charAt(0).toUpperCase()}
          </div>
        )}
      </div>
      <div>
        <div className="font-medium">{name}</div>
        {role && <div className="text-xs text-gray-500">{role}</div>}
        {bio && <div className="mt-1 text-sm text-gray-600">{bio}</div>}
      </div>
    </div>
  )
}
