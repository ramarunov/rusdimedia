"use client"

import { useEffect, useRef, useState } from "react"
import Script from "next/script"

interface AdsBannerProps {
  slot: string
  format?: "auto" | "rectangle" | "horizontal" | "vertical" | "skyscraper"
  responsive?: boolean
  className?: string
  size?: { width: number; height: number }
  lazyLoad?: boolean
}

export default function AdsBanner({
  slot,
  format = "auto",
  responsive = true,
  className = "",
  size,
  lazyLoad = true,
}: AdsBannerProps) {
  const adRef = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(!lazyLoad)
  const [isAdLoaded, setIsAdLoaded] = useState(false)
  const [isPreviewEnvironment, setIsPreviewEnvironment] = useState(false)

  // Determine minimum height based on format to prevent layout shifts
  const getMinHeight = () => {
    if (size?.height) return `${size.height}px`

    switch (format) {
      case "rectangle":
        return "250px"
      case "horizontal":
        return "90px"
      case "vertical":
        return "600px"
      case "skyscraper":
        return "600px"
      default:
        return "100px"
    }
  }

  useEffect(() => {
    // Only run on client side
    if (typeof window === "undefined") return

    // Check if we're in a preview environment
    const hostname = window.location.hostname
    const isPreview =
      hostname.includes("vusercontent.net") || hostname.includes("localhost") || hostname.includes("vercel.app")

    setIsPreviewEnvironment(isPreview)

    // If lazyLoad is enabled, set up intersection observer
    if (lazyLoad && adRef.current) {
      const observer = new IntersectionObserver(
        (entries) => {
          if (entries[0].isIntersecting) {
            setIsVisible(true)
            observer.disconnect()
          }
        },
        { rootMargin: "200px" }, // Load ads when they're within 200px of viewport
      )

      observer.observe(adRef.current)
      return () => observer.disconnect()
    }
  }, [lazyLoad])

  useEffect(() => {
    // Only proceed if the ad is visible, we're on the client side, and not in preview environment
    if (!isVisible || typeof window === "undefined" || isPreviewEnvironment) return

    // Check if AdSense script is already loaded
    const isAdsenseLoaded = () => {
      return typeof window.adsbygoogle !== "undefined" && Array.isArray(window.adsbygoogle)
    }

    const initializeAd = () => {
      if (!adRef.current) return

      try {
        // Check if this specific ad unit has already been initialized
        const adElement = adRef.current.querySelector(".adsbygoogle")
        if (!adElement) return

        // Check if this ad already has the data-ad-status attribute (means it's already initialized)
        if (adElement.getAttribute("data-ad-status")) {
          console.log("Ad already initialized, skipping:", slot)
          return
        }

        // Only push the ad if it hasn't been loaded yet
        if (!isAdLoaded && isAdsenseLoaded()) {
          console.log("Initializing ad:", slot)
          ;(window.adsbygoogle = window.adsbygoogle || []).push({})
          setIsAdLoaded(true)
        }
      } catch (error) {
        console.error("Error initializing ad:", error)
      }
    }

    // If AdSense is already loaded, initialize immediately
    if (isAdsenseLoaded()) {
      initializeAd()
    } else {
      // Otherwise wait for the adsense script to load
      const checkAdsenseInterval = setInterval(() => {
        if (isAdsenseLoaded()) {
          initializeAd()
          clearInterval(checkAdsenseInterval)
        }
      }, 300)

      // Cleanup interval after 10 seconds to avoid infinite checking
      setTimeout(() => clearInterval(checkAdsenseInterval), 10000)

      return () => clearInterval(checkAdsenseInterval)
    }
  }, [isVisible, isPreviewEnvironment, slot, isAdLoaded])

  return (
    <>
      {/* Ensure AdSense script is properly loaded once per page */}
      {!isPreviewEnvironment && (
        <Script
          id={`adsense-init-${slot}`} // Add unique ID based on slot
          strategy="afterInteractive"
          src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-7609031768696978"
          crossOrigin="anonymous"
          onLoad={() => {
            // Don't try to initialize here, let the useEffect handle it
            console.log("AdSense script loaded for slot:", slot)
          }}
        />
      )}

      <div
        ref={adRef}
        className={`ad-container ${className}`}
        style={{
          display: "block",
          minHeight: getMinHeight(),
          width: size?.width ? `${size.width}px` : "100%",
          height: size?.height ? `${size.height}px` : "auto",
          overflow: "hidden",
          backgroundColor: "transparent", // Changed from #f9f9f9 to transparent
          border: "none", // Removed border that might interfere with ad rendering
          borderRadius: "0", // Removed border radius
          margin: "0 auto", // Center the ad
        }}
      >
        {isVisible ? (
          isPreviewEnvironment ? (
            <div className="text-xs text-gray-400 p-4 text-center">
              Ad placeholder - ads are disabled in preview environment
            </div>
          ) : (
            <ins
              className="adsbygoogle"
              style={{
                display: "block",
                width: size ? `${size.width}px` : "100%",
                height: size ? `${size.height}px` : "100%",
                minHeight: getMinHeight(),
              }}
              data-ad-client="ca-pub-7609031768696978"
              data-ad-slot={slot}
              data-ad-format={format}
              data-full-width-responsive={responsive ? "true" : "false"}
            />
          )
        ) : (
          <div className="text-xs text-gray-400 text-center">Ad Loading...</div>
        )}
      </div>
    </>
  )
}
