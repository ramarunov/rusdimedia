import { fetchPostsByCategory } from "@/lib/api"
import Link from "next/link"
import { formatDate } from "@/lib/utils"
import OptimizedImage from "./optimized-image"

export default async function OlahragaPosts() {
  // Fetch posts from the "olahraga" category
  const posts = await fetchPostsByCategory("olahraga", 6)

  if (!posts || posts.length === 0) {
    return null
  }

  // Split posts for different layouts
  const featuredPost = posts[0]
  const smallPosts = posts.slice(1, 5)

  return (
    <div className="mb-8">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="section-title mb-0">Olahraga</h2>
        <Link href="/kategori/olahraga" className="text-sm font-medium text-[#00acee] hover:underline">
          Lihat lainnya
        </Link>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        {/* Left column - Small posts */}
        <div className="space-y-4 md:col-span-2">
          {smallPosts.map((post) => (
            <article key={post.id} className="flex gap-3 border-b border-gray-100 pb-4 last:border-0">
              <div className="flex-none">
                <div className="relative h-20 w-20 overflow-hidden rounded-md">
                  {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                    <OptimizedImage
                      src={post._embedded["wp:featuredmedia"][0].source_url}
                      alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                      fill
                      loading="lazy"
                      className="object-cover"
                      sizes="80px"
                      quality={70}
                    />
                  ) : (
                    <div className="h-full w-full bg-gray-300" />
                  )}
                </div>
              </div>
              <div>
                <h3 className="text-sm font-bold leading-tight">
                  <Link href={`/${post.slug}`} className="hover:text-[#00acee]">
                    <span dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                  </Link>
                </h3>
                <div className="mt-1 text-xs text-gray-500">{formatDate(post.date)}</div>
              </div>
            </article>
          ))}
        </div>

        {/* Right column - Featured post */}
        {featuredPost && (
          <div className="md:col-span-1">
            <article className="h-full">
              <Link href={`/${featuredPost.slug}`} className="group block h-full">
                <div className="relative aspect-[4/3] overflow-hidden rounded-md">
                  {featuredPost._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                    <OptimizedImage
                      src={featuredPost._embedded["wp:featuredmedia"][0].source_url}
                      alt={featuredPost._embedded["wp:featuredmedia"][0].alt_text || featuredPost.title.rendered}
                      fill
                      loading="lazy"
                      className="object-cover transition-transform duration-300 group-hover:scale-105"
                      sizes="(max-width: 768px) 100vw, 33vw"
                      quality={75}
                    />
                  ) : (
                    <div className="h-full w-full bg-gray-300" />
                  )}
                </div>
                <div className="mt-3">
                  {featuredPost._embedded?.["wp:term"]?.[0]?.[0] && (
                    <span className="mb-2 inline-block rounded bg-[#00acee] px-1.5 py-0.5 text-xs font-bold text-white">
                      {featuredPost._embedded["wp:term"][0][0].name}
                    </span>
                  )}
                  <h3 className="mt-1 text-base font-bold leading-tight md:text-lg">
                    <span dangerouslySetInnerHTML={{ __html: featuredPost.title.rendered }} />
                  </h3>
                  <div className="mt-1 text-xs text-gray-500">{formatDate(featuredPost.date)}</div>
                </div>
              </Link>
            </article>
          </div>
        )}
      </div>
    </div>
  )
}
