"use client"

import React from "react"
import { fetchPosts, fetchPostsByCategory } from "@/lib/api"
import Link from "next/link"
import { formatDate } from "@/lib/utils"
import AdsBanner from "./ads-banner"
import SerbaSerbiPosts from "./serba-serbi-posts"
import OptimizedImage from "./optimized-image"
import KeuanganPosts from "./keuangan-posts"

export default async function Sidebar() {
  // Wrap each API call in a try/catch to prevent the entire component from failing
  let popularPosts = []
  let trendingPosts = []
  let selebritiPosts = []

  try {
    // Get popular posts
    popularPosts = await fetchPosts({
      per_page: 5,
      _embed: true,
    })
  } catch (error) {
    console.error("Error fetching popular posts for sidebar:", error)
  }

  try {
    // Get trending posts (using the same data for now)
    trendingPosts = await fetchPosts({
      per_page: 5,
      _embed: true,
    })
  } catch (error) {
    console.error("Error fetching trending posts for sidebar:", error)
  }

  try {
    // Get posts from the selebriti category - with fallback
    try {
      selebritiPosts = await fetchPostsByCategory("selebriti", 3)
    } catch (error) {
      console.error("Error fetching selebriti posts, trying to fetch recent posts instead:", error)
      // Fallback to recent posts if category fetch fails
      selebritiPosts = await fetchPosts({
        per_page: 3,
        _embed: true,
      })
    }
  } catch (error) {
    console.error("Error fetching all fallback posts for sidebar:", error)
  }

  return (
    <div className="sticky top-20 space-y-8 pb-8">
      {/* Popular Posts */}
      {popularPosts.length > 0 && (
        <div>
          <h2 className="section-title">Berita Terbaru</h2>
          <div className="space-y-4">
            {popularPosts.map((post) => (
              <article key={post.id} className="flex gap-4">
                <div className="flex-none">
                  <div className="relative h-20 w-20 overflow-hidden rounded-md">
                    {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                      <OptimizedImage
                        src={post._embedded["wp:featuredmedia"][0].source_url}
                        alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                        fill
                        loading="lazy"
                        className="object-cover"
                        sizes="80px"
                        quality={70}
                      />
                    ) : (
                      <div className="h-full w-full bg-gray-300" />
                    )}
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-bold leading-tight">
                    <Link href={`/${post.slug}`} className="hover:text-[#00acee]">
                      <span dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                    </Link>
                  </h3>
                  <div className="mt-1 text-xs text-gray-500">{formatDate(post.date)}</div>
                </div>
              </article>
            ))}
          </div>
        </div>
      )}

      {/* Ad Banner */}
      <AdsBanner
        slot="6805010756"
        format="rectangle"
        className="bg-gray-50 min-h-[300px] w-full flex items-center justify-center border border-gray-200 rounded-md"
        lazyLoad={true}
      />

      {/* Selebriti Section */}
      {selebritiPosts.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="section-title mb-0">Selebriti</h2>
            <Link href="/kategori/selebriti" className="text-sm font-medium text-[#00acee] hover:underline">
              Lihat Semua
            </Link>
          </div>
          <div className="space-y-4">
            {selebritiPosts.map((post) => (
              <article key={post.id} className="flex gap-4">
                <div className="flex-none">
                  <div className="relative h-20 w-20 overflow-hidden rounded-md">
                    {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                      <OptimizedImage
                        src={post._embedded["wp:featuredmedia"][0].source_url}
                        alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                        fill
                        loading="lazy"
                        className="object-cover"
                        sizes="80px"
                        quality={70}
                      />
                    ) : (
                      <div className="h-full w-full bg-gray-300" />
                    )}
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-bold leading-tight">
                    <Link href={`/${post.slug}`} className="hover:text-[#00acee]">
                      <span dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                    </Link>
                  </h3>
                  <div className="mt-1 text-xs text-gray-500">{formatDate(post.date)}</div>
                </div>
              </article>
            ))}
          </div>
        </div>
      )}
      {/* Image Banner */}
      <div className="rounded-md overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
        <Link href="https://wa.me/628561555398" className="block">
          <div className="relative w-full h-full">
            <img
              src="https://bbsnews.co.id/wp-content/uploads/2025/04/banner-pendaftaran-smk-miftahul-falah.jpg"
              alt="Iklan Sekolah"
              className="object-cover w-full h-full"
              onError={(e) => {
                // Fallback image if the main one fails to load
                e.currentTarget.src = "https://via.placeholder.com/400x300/00acee/ffffff?text=Promo+Spesial"
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-4">
              <h3 className="text-white font-bold text-lg leading-tight">PENERIMAAN MURID BARU</h3>
              <p className="text-white/90 text-sm mt-1">Tahun Pelajaran 2025/2026</p>
              <button className="mt-3 bg-[#00acee] hover:bg-[#0096ce] text-white text-sm font-medium py-1.5 px-4 rounded-md transition-colors duration-200 w-fit">
                Daftar Sekarang
              </button>
            </div>
          </div>
        </Link>
      </div>
      {/* Trending Posts - New Design */}
      {trendingPosts.length > 0 && (
        <div className="bg-gray-900 text-white rounded-md overflow-hidden">
          <h2 className="px-4 py-3 text-lg font-bold border-b border-gray-700">Terpopuler</h2>
          <div className="divide-y divide-gray-700">
            {trendingPosts.slice(0, 5).map((post, index) => (
              <article key={post.id} className="p-4 flex gap-3">
                <div className="flex-none">
                  <div className="relative text-3xl font-bold text-white w-8 flex items-start">
                    <span className="leading-none text-2xl" style={{ textShadow: "1px 1px 0 rgba(255,255,255,0.2)" }}>
                      #{index + 1}
                    </span>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium leading-tight">
                    <Link href={`/${post.slug}`} className="hover:text-[#00acee]">
                      <span dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                    </Link>
                  </h3>
                </div>
              </article>
            ))}
          </div>
        </div>
      )}

      {/* Keuangan Posts Section */}
      <React.Suspense
        fallback={
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="section-title mb-0">Keuangan</h2>
              <span className="text-sm font-medium text-[#00acee]">Lihat Semua</span>
            </div>
            {[1, 2, 3, 4].map((i) => (
              <article key={i} className="flex gap-4">
                <div className="flex-none">
                  <div className="relative h-20 w-20 overflow-hidden rounded-md bg-gray-200 animate-pulse" />
                </div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded animate-pulse mb-2" />
                  <div className="h-3 bg-gray-200 rounded animate-pulse w-1/3" />
                </div>
              </article>
            ))}
          </div>
        }
      >
        <KeuanganPosts />
      </React.Suspense>

      {/* Second Ad Banner */}
      <AdsBanner
        slot="6805010756"
        format="rectangle"
        className="bg-gray-50 min-h-[300px] w-full flex items-center justify-center border border-gray-200 rounded-md"
        lazyLoad={true}
      />

      {/* Newsletter - Always show this section even if API calls fail */}
      <div className="rounded-lg border border-gray-200 p-4">
        <h3 className="mb-2 font-bold">Berlangganan Newsletter</h3>
        <p className="mb-4 text-sm text-gray-600">Dapatkan berita terbaru langsung ke email Anda</p>
        <form className="space-y-3">
          <input
            type="email"
            placeholder="Email Anda"
            className="w-full rounded-md border border-gray-300 px-3 py-2 focus:border-[#00acee] focus:outline-none"
            required
          />
          <button type="submit" className="w-full rounded-md bg-[#00acee] px-4 py-2 text-white hover:bg-[#0096ce]">
            Berlangganan
          </button>
        </form>
      </div>

      {/* Serba-serbi Section */}
      <React.Suspense
        fallback={
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="section-title mb-0">Serba-serbi</h2>
              <span className="text-sm font-medium text-[#00acee]">Lihat Semua</span>
            </div>
            {[1, 2, 3, 4].map((i) => (
              <article key={i} className="flex gap-4">
                <div className="flex-none">
                  <div className="relative h-20 w-20 overflow-hidden rounded-md bg-gray-200 animate-pulse" />
                </div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded animate-pulse mb-2" />
                  <div className="h-3 bg-gray-200 rounded animate-pulse w-1/3" />
                </div>
              </article>
            ))}
          </div>
        }
      >
        <SerbaSerbiPosts />
      </React.Suspense>
    </div>
  )
}
