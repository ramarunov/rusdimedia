"use client"

import { fetchPostsByCategory } from "@/lib/api"
import Link from "next/link"
import { formatDate } from "@/lib/utils"
import OptimizedImage from "./optimized-image"
import { useState, useEffect, useRef } from "react"

export default function LatestPosts() {
  const [posts, setPosts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isMobile, setIsMobile] = useState(false)
  const carouselRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    async function loadPosts() {
      try {
        // Fetch posts from Pendidikan category instead of latest posts
        const fetchedPosts = await fetchPostsByCategory("pendidikan", 6)
        setPosts(fetchedPosts)
      } catch (error) {
        console.error("Error fetching Pendidikan posts:", error)
      } finally {
        setLoading(false)
      }
    }

    loadPosts()
  }, [])

  // Check if we're on mobile
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 640)
    }

    checkIfMobile()
    window.addEventListener("resize", checkIfMobile)

    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  // Navigation functions
  const nextSlide = () => {
    if (posts.length <= 1) return
    setCurrentIndex((prevIndex) => (prevIndex === posts.length - 1 ? 0 : prevIndex + 1))
  }

  const prevSlide = () => {
    if (posts.length <= 1) return
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? posts.length - 1 : prevIndex - 1))
  }

  const goToSlide = (index: number) => {
    setCurrentIndex(index)
  }

  if (loading) {
    return (
      <div>
        <div className="flex items-center justify-between">
          <h2 className="section-title">Pendidikan</h2>
          <Link href="/kategori/pendidikan" className="text-sm text-[#00acee] hover:text-[#0096ce] font-medium">
            Lihat Semua
          </Link>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="aspect-[16/9] bg-gray-200 rounded-md"></div>
              <div className="p-4">
                <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-full"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  if (!posts || posts.length === 0) {
    return (
      <div>
        <div className="flex items-center justify-between">
          <h2 className="section-title">Pendidikan</h2>
          <Link href="/kategori/pendidikan" className="text-sm text-[#00acee] hover:text-[#0096ce] font-medium">
            Lihat Semua
          </Link>
        </div>
        <p className="text-center text-gray-500 my-8">Tidak ada artikel ditemukan dalam kategori Pendidikan.</p>
      </div>
    )
  }

  return (
    <div>
      <div className="flex items-center justify-between">
        <h2 className="section-title">Pendidikan</h2>
        <Link href="/kategori/pendidikan" className="text-sm text-[#00acee] hover:text-[#0096ce] font-medium">
          Lihat Semua
        </Link>
      </div>

      {/* Mobile Horizontal Scroll View */}
      <div className="sm:hidden">
        <div className="flex overflow-x-auto pb-4 gap-4 snap-x snap-mandatory scrollbar-hide -mx-4 px-4">
          {posts.map((post, index) => (
            <article key={post.id} className="article-card flex-shrink-0 w-[70%] snap-start">
              <Link href={`/${post.slug}`}>
                <div className="aspect-[16/9] relative rounded-lg overflow-hidden">
                  {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                    <OptimizedImage
                      src={post._embedded["wp:featuredmedia"][0].source_url}
                      alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                      fill
                      loading={index < 2 ? "eager" : "lazy"}
                      className="object-cover"
                      sizes="70vw"
                      quality={75}
                    />
                  ) : (
                    <div className="h-full w-full bg-gray-300" />
                  )}
                </div>
                <div className="p-3">
                  <h3
                    className="article-title text-sm font-bold line-clamp-2"
                    dangerouslySetInnerHTML={{ __html: post.title.rendered }}
                  />
                  <div className="article-meta mt-1">
                    <span className="text-xs">{formatDate(post.date)}</span>
                    {post._embedded?.["wp:term"]?.[0]?.[0]?.name && (
                      <>
                        <span className="text-xs">•</span>
                        <span className="text-xs">{post._embedded["wp:term"][0][0].name}</span>
                      </>
                    )}
                  </div>
                </div>
              </Link>
            </article>
          ))}
        </div>
      </div>

      {/* Desktop Grid View - Unchanged */}
      <div className="hidden sm:grid grid-cols-1 gap-6 sm:grid-cols-2">
        {posts.map((post, index) => (
          <article key={post.id} className="article-card">
            <Link href={`/${post.slug}`}>
              <div className="aspect-[16/9] relative">
                {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                  <OptimizedImage
                    src={post._embedded["wp:featuredmedia"][0].source_url}
                    alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                    fill
                    loading={index < 2 ? "eager" : "lazy"}
                    className="object-cover transition-transform duration-300 hover:scale-105"
                    sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, 33vw"
                    quality={75}
                  />
                ) : (
                  <div className="h-full w-full bg-gray-300" />
                )}
              </div>
              <div className="p-4">
                <h3 className="article-title text-lg" dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                <div className="article-meta mt-2">
                  <span>{formatDate(post.date)}</span>
                  {post._embedded?.["wp:term"]?.[0]?.[0]?.name && (
                    <>
                      <span>•</span>
                      <span>{post._embedded["wp:term"][0][0].name}</span>
                    </>
                  )}
                </div>
                <div
                  className="mt-2 text-sm text-gray-600 line-clamp-2"
                  dangerouslySetInnerHTML={{ __html: post.excerpt.rendered }}
                />
              </div>
            </Link>
          </article>
        ))}
      </div>
    </div>
  )
}
