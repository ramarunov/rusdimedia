"use client"

import { fetchPosts } from "@/lib/api"
import Link from "next/link"
import { formatDate } from "@/lib/utils"
import OptimizedImage from "./optimized-image"
import { useState, useEffect } from "react"

interface RelatedPostsProps {
  categoryId?: number
  currentPostId: number
}

export default function RelatedPosts({ categoryId, currentPostId }: RelatedPostsProps) {
  const [relatedPosts, setRelatedPosts] = useState<any[]>([])
  const [latestPosts, setLatestPosts] = useState<any[]>([])
  const [visibleLatestPosts, setVisibleLatestPosts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [hasMore, setHasMore] = useState(true)
  const postsPerPage = 5

  useEffect(() => {
    async function loadPosts() {
      try {
        setLoading(true)
        // Fetch related posts by category
        if (categoryId) {
          // Fetch posts specifically from the same category as the current post
          const relatedPostsResponse = await fetchPosts({
            per_page: 6,
            _embed: true,
            categories: categoryId,
            exclude: [currentPostId], // Exclude current post
          })

          setRelatedPosts(relatedPostsResponse)

          if (relatedPostsResponse.length === 0) {
            setLoading(false)
            return
          }

          // Fetch latest posts (different from related posts)
          const latestPostsResponse = await fetchPosts({
            per_page: 12, // Fetch more to have some for "load more"
            _embed: true,
            exclude: [currentPostId],
          })

          // Filter out any posts that are already in related posts to avoid duplication
          const relatedPostIds = relatedPostsResponse.map((post) => post.id)
          const allLatestPosts = latestPostsResponse
            .filter((post) => !relatedPostIds.includes(post.id))
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()) // Sort by date, newest first

          setLatestPosts(allLatestPosts)
          setVisibleLatestPosts(allLatestPosts.slice(0, postsPerPage))
          setHasMore(allLatestPosts.length > postsPerPage)
        } else {
          // If no category ID is provided, just fetch latest posts
          const latestPostsResponse = await fetchPosts({
            per_page: 12,
            _embed: true,
            exclude: [currentPostId],
          })

          const allLatestPosts = latestPostsResponse.sort(
            (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime(),
          )

          setLatestPosts(allLatestPosts)
          setVisibleLatestPosts(allLatestPosts.slice(0, postsPerPage))
          setHasMore(allLatestPosts.length > postsPerPage)
          setRelatedPosts([]) // No related posts if no category
        }
      } catch (error) {
        console.error("Error loading posts:", error)
      } finally {
        setLoading(false)
      }
    }

    loadPosts()
  }, [categoryId, currentPostId])

  const loadMorePosts = () => {
    setLoadingMore(true)
    // Simulate a slight delay for better UX
    setTimeout(() => {
      const currentlyVisible = visibleLatestPosts.length
      const newPosts = latestPosts.slice(currentlyVisible, currentlyVisible + postsPerPage)
      setVisibleLatestPosts([...visibleLatestPosts, ...newPosts])
      setHasMore(currentlyVisible + newPosts.length < latestPosts.length)
      setLoadingMore(false)
    }, 300)
  }

  if (loading) {
    return <div className="animate-pulse h-40 bg-gray-100 rounded-md"></div>
  }

  return (
    <div>
      {/* Related Posts Section */}
      {relatedPosts.length > 0 && (
        <div className="mb-8">
          <h2 className="section-title">Artikel Terkait</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3">
            {relatedPosts.map((post) => (
              <article
                key={post.id}
                className="article-card border border-gray-100 rounded-lg overflow-hidden hover:shadow-md transition-all duration-300"
              >
                <Link href={`/${post.slug}`} className="block">
                  <div className="aspect-[4/3] relative">
                    {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                      <OptimizedImage
                        src={post._embedded["wp:featuredmedia"][0].source_url}
                        alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                        fill
                        loading="lazy"
                        className="object-cover transition-transform duration-300 hover:scale-105"
                        sizes="(max-width: 640px) 100vw, (max-width: 768px) 50vw, 33vw"
                        quality={75}
                      />
                    ) : (
                      <div className="h-full w-full bg-gray-300" />
                    )}
                  </div>
                  <div className="p-3">
                    <h3
                      className="text-sm font-bold leading-tight hover:text-[#00acee] line-clamp-2"
                      dangerouslySetInnerHTML={{ __html: post.title.rendered }}
                    />
                    <div className="mt-2 flex items-center text-xs text-gray-500">
                      <span>{formatDate(post.date)}</span>
                    </div>
                  </div>
                </Link>
              </article>
            ))}
          </div>
        </div>
      )}

      {/* Latest Posts Section */}
      {visibleLatestPosts.length > 0 && (
        <div>
          <h2 className="section-title">Berita Terbaru</h2>
          <div className="space-y-4" key="latest-posts-list">
            {visibleLatestPosts.map((post) => (
              <article
                key={post.id}
                className="article-card border border-gray-100 rounded-lg overflow-hidden hover:shadow-md transition-all duration-300"
              >
                <Link href={`/${post.slug}`} className="flex flex-row">
                  <div className="relative h-24 w-32 flex-shrink-0">
                    {post._embedded?.["wp:featuredmedia"]?.[0]?.source_url ? (
                      <OptimizedImage
                        src={post._embedded["wp:featuredmedia"][0].source_url}
                        alt={post._embedded["wp:featuredmedia"][0].alt_text || post.title.rendered}
                        fill
                        loading="lazy"
                        className="object-cover"
                        sizes="128px"
                        quality={70}
                      />
                    ) : (
                      <div className="h-full w-full bg-gray-300" />
                    )}
                  </div>
                  <div className="flex-1 p-3">
                    <h3
                      className="text-sm font-bold leading-tight hover:text-[#00acee] line-clamp-2"
                      dangerouslySetInnerHTML={{ __html: post.title.rendered }}
                    />
                    <div className="mt-2 flex items-center text-xs text-gray-500">
                      <span>{formatDate(post.date)}</span>
                    </div>
                  </div>
                </Link>
              </article>
            ))}
          </div>

          {hasMore && (
            <div className="mt-6 text-center">
              <button
                onClick={loadMorePosts}
                disabled={loadingMore}
                className="inline-block rounded-md bg-[#00acee] px-4 py-2 text-white hover:bg-[#0096ce] transition-colors disabled:opacity-70"
              >
                {loadingMore ? "Memuat..." : "Lihat Lebih Banyak"}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
