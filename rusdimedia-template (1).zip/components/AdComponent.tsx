"use client"

import { useEffect, useRef, useState } from "react"

const AdComponent = () => {
  const adRef = useRef<HTMLDivElement>(null)
  const [isInitialized, setIsInitialized] = useState(false)

  useEffect(() => {
    // Only run on client side
    if (typeof window === "undefined") return

    // Check if we're in a preview environment
    const hostname = window.location.hostname
    const isPreview =
      hostname.includes("vusercontent.net") || hostname.includes("localhost") || hostname.includes("vercel.app")

    // Don't initialize ads in preview environments
    if (isPreview) return

    // Check if AdSense is loaded
    const isAdsenseLoaded = () => {
      return typeof window.adsbygoogle !== "undefined" && Array.isArray(window.adsbygoogle)
    }

    const initializeAd = () => {
      if (!adRef.current || isInitialized) return

      try {
        // Check if this specific ad unit has already been initialized
        const adElement = adRef.current.querySelector(".adsbygoogle")
        if (!adElement) return

        // Check if this ad already has the data-ad-status attribute
        if (adElement.getAttribute("data-ad-status")) {
          console.log("Ad already initialized, skipping autorelaxed")
          return
        }

        console.log("Initializing autorelaxed ad")
        ;(window.adsbygoogle = window.adsbygoogle || []).push({})
        setIsInitialized(true)
      } catch (e) {
        console.error("AdSense error:", e)
      }
    }

    // If AdSense is already loaded, initialize immediately
    if (isAdsenseLoaded()) {
      initializeAd()
    } else {
      // Otherwise wait for the adsense script to load
      const checkAdsenseInterval = setInterval(() => {
        if (isAdsenseLoaded()) {
          initializeAd()
          clearInterval(checkAdsenseInterval)
        }
      }, 300)

      // Cleanup interval after 10 seconds
      setTimeout(() => clearInterval(checkAdsenseInterval), 10000)

      return () => clearInterval(checkAdsenseInterval)
    }
  }, [isInitialized])

  return (
    <div ref={adRef}>
      <ins
        className="adsbygoogle"
        style={{ display: "block" }}
        data-ad-client="ca-pub-7609031768696978"
        data-ad-slot="8215077496"
        data-ad-format="autorelaxed"
      ></ins>
    </div>
  )
}

export default AdComponent
