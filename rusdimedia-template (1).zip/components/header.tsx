"use client"

import { useState, useCallback } from "react"
import Link from "next/link"
import Image from "next/image"
import { Search, Menu, Sun, Moon } from "lucide-react"
import MobileMenu from "./mobile-menu"

// Add CSS for hiding scrollbars
const scrollbarHideStyles = `
  .scrollbar-hide {
    -ms-overflow-style: none;  /* IE and Edge */
    scrollbar-width: none;  /* Firefox */
  }
  .scrollbar-hide::-webkit-scrollbar {
    display: none;  /* Chrome, Safari and Opera */
  }
`

const menuItems = [
  { name: "Beranda", href: "/" },
  { name: "Berita", href: "/category/berita" },
  { name: "Kecantikan", href: "/category/kecantikan" },
  { name: "Kesehatan", href: "/category/kesehatan" },
  { name: "Teknologi", href: "/category/teknologi" },
  { name: "Olahraga", href: "/kategori/berita/olahraga" }, // This is now a subcategory
  { name: "Relationship", href: "/category/relationship" },
  { name: "Lifestyle", href: "/category/lifestyle" },
  { name: "Selebriti", href: "/category/selebriti" },
  { name: "Parenting", href: "/category/parenting" },
  { name: "Serba-serbi", href: "/category/serba-serbi" },
]

export default function Header() {
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  // Use useCallback to memoize these functions
  const toggleSearch = useCallback(() => {
    setIsSearchOpen((prev) => !prev)
  }, [])

  const toggleDarkMode = useCallback(() => {
    setIsDarkMode((prev) => !prev)
    // In a real implementation, you would toggle a dark mode class or context here
  }, [])

  // Replace the toggleMobileMenu function with a more efficient implementation
  const toggleMobileMenu = useCallback(() => {
    if (isMobileMenuOpen) {
      // When closing, set state immediately
      setIsMobileMenuOpen(false)
    } else {
      // When opening, set state with requestAnimationFrame for better performance
      requestAnimationFrame(() => {
        setIsMobileMenuOpen(true)
      })
    }
  }, [isMobileMenuOpen])

  const closeMobileMenu = useCallback(() => {
    setIsMobileMenuOpen(false)
  }, [])

  return (
    <>
      <header className="sticky top-0 z-40 bg-black text-white">
        {/* Add style tag for scrollbar hiding */}
        <style jsx global>
          {`
            .scrollbar-hide {
              -ms-overflow-style: none;  /* IE and Edge */
              scrollbar-width: none;  /* Firefox */
            }
            .scrollbar-hide::-webkit-scrollbar {
              display: none;  /* Chrome, Safari and Opera */
            }
          `}
        </style>

        {/* Top header with logo, search and actions */}
        <div className="mx-auto max-w-[1080px] px-4 py-3">
          <div className="flex items-center justify-between">
            {/* Logo */}
            {/* Replace image loading in the logo section with priority loading */}
            <Link href="/" className="flex items-center">
              <Image
                src="https://dash.rusdimedia.com/wp-content/uploads/2024/10/Dosa-Besar-dalam-Islam-e1744014973421.png"
                alt="Rusdimedia Logo"
                width={102}
                height={48}
                className="h-auto"
                priority
                fetchPriority="high"
              />
            </Link>

            {/* Desktop search bar */}
            <div className="hidden md:flex flex-1 max-w-md mx-4">
              <form action="/search" method="get" className="relative w-full">
                <input
                  type="text"
                  name="q"
                  placeholder="Cari berita, artikel, atau topik..."
                  className="w-full rounded-md border border-gray-600 bg-gray-800 px-4 py-2 pr-10 text-white placeholder-gray-400 focus:border-[#00acee] focus:outline-none"
                  required
                />
                <button
                  type="submit"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                >
                  <Search className="h-5 w-5" />
                </button>
              </form>
            </div>

            {/* Mobile action buttons - styled like the reference image */}
            <div className="flex items-center gap-3 md:hidden">
              {/* Theme toggle button */}
              <button
                onClick={toggleDarkMode}
                className="flex h-8 w-8 items-center justify-center rounded-full text-white"
                aria-label={isDarkMode ? "Switch to light mode" : "Switch to dark mode"}
              >
                {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </button>

              {/* Search button */}
              <button
                onClick={toggleSearch}
                className="flex h-8 w-8 items-center justify-center rounded-full text-white"
                aria-label="Search"
              >
                <Search className="h-5 w-5" />
              </button>

              {/* Menu button */}
              {/* Replace the mobile menu trigger button with a more accessible version */}
              <button
                onClick={toggleMobileMenu}
                className="flex h-8 w-8 items-center justify-center rounded-full text-white"
                aria-label="Toggle menu"
                aria-expanded={isMobileMenuOpen}
                aria-controls="mobile-menu"
              >
                <Menu className="h-5 w-5" />
              </button>
            </div>

            {/* Desktop action buttons */}
            <div className="hidden md:flex items-center gap-3">
              {/* WhatsApp button */}
              <Link
                href="https://whatsapp.com/channel/0029Vb8EzWY1dAw1ZeNtC30d"
                target="_blank"
                className="flex items-center gap-1.5 rounded-md bg-[#25D366] px-2.5 py-1.5 text-sm font-medium text-white hover:bg-[#128C7E]"
              >
                <span>Whatsapp</span>
              </Link>

              {/* Google News button */}
              <Link
                href="https://news.google.com/publications/CAAqBwgKMNPGlAswk9CxAw"
                target="_blank"
                className="flex items-center gap-1.5 rounded-md bg-[#DB4437] px-2.5 py-1.5 text-sm font-medium text-white hover:bg-[#C53929]"
              >
                <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 11h6v2h-6v-2zm-6 6h12v-2H6v2zm0-4h4V7H6v6zm16-7.22v12.44c0 1.54-1.34 2.78-3 2.78H5c-1.66 0-3-1.24-3-2.78V5.78C2 4.24 3.34 3 5 3h14c1.66 0 3 1.24 3 2.78z" />
                </svg>
                <span>Google News</span>
              </Link>
            </div>
          </div>

          {/* Mobile search */}
          {isSearchOpen && (
            <div className="mt-3 md:hidden">
              <form action="/search" method="get" className="relative w-full">
                <input
                  type="text"
                  name="q"
                  placeholder="Cari berita..."
                  className="w-full rounded-md border border-gray-600 bg-gray-800 px-4 py-2 pr-10 text-white placeholder-gray-400 focus:border-[#00acee] focus:outline-none"
                  required
                />
                <button
                  type="submit"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                >
                  <Search className="h-5 w-5" />
                </button>
              </form>
            </div>
          )}
        </div>

        {/* Navigation - styled like the reference image */}
        <nav className="border-t border-gray-800 bg-black">
          <div className="mx-auto max-w-[1080px] px-4">
            {/* Desktop menu */}
            <ul className="hidden md:flex md:items-center md:space-x-6 md:py-3">
              {menuItems.map((item) => (
                <li key={item.name}>
                  <Link href={item.href} className="block py-2 font-medium hover:text-[#00acee] md:py-0">
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>

            {/* Mobile horizontal scrolling menu - styled like the reference image */}
            <div className="overflow-x-auto scrollbar-hide py-3 md:hidden">
              <ul className="flex whitespace-nowrap space-x-6 pb-1">
                {menuItems.map((item) => (
                  <li key={item.name} className="flex-shrink-0">
                    <Link href={item.href} className="block py-1 px-1 text-sm font-medium hover:text-[#00acee]">
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </nav>
      </header>

      {/* Mobile Menu */}
      <MobileMenu isOpen={isMobileMenuOpen} onClose={closeMobileMenu} />
    </>
  )
}
