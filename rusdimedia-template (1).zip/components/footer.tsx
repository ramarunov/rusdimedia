import Link from "next/link"
import Image from "next/image"
import Script from "next/script"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="mx-auto max-w-[1080px] px-4 py-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          {/* Column 1 */}
          <div>
            {/* Logo */}
            <Link href="/" className="flex items-center">
              <Image
                src="https://dash.rusdimedia.com/wp-content/uploads/2024/10/Dosa-Besar-dalam-Islam-e1744014973421.png"
                alt="Rusdimedia Logo"
                width={128}
                height={60}
                className="h-auto"
                priority
              />
            </Link>
            <p className="mb-4 text-gray-400">
              Baca berita dan informasi terbaru seputar politik, gaya hidup, tips dan trik hari ini hanya di Rusdi
              Media. Disajikan berdasarkan fakta dan sumber terpercaya!
            </p>
          </div>

          {/* Column 2 */}
          <div>
            <h4 className="mb-4 font-bold uppercase">Kategori</h4>
            <ul className="space-y-2 text-gray-400">
              <li>
                <Link href="/kategori/politik" className="hover:text-white">
                  Politik
                </Link>
              </li>
              <li>
                <Link href="/kategori/ekonomi" className="hover:text-white">
                  Ekonomi
                </Link>
              </li>
              <li>
                <Link href="/kategori/gaya-hidup" className="hover:text-white">
                  Gaya Hidup
                </Link>
              </li>
              <li>
                <Link href="/kategori/teknologi" className="hover:text-white">
                  Teknologi
                </Link>
              </li>
              <li>
                <Link href="/kategori/olahraga" className="hover:text-white">
                  Olahraga
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3 */}
          <div>
            <h4 className="mb-4 font-bold uppercase">Halaman</h4>
            <ul className="space-y-2 text-gray-400">
              <li>
                <Link href="/pages/tentang-kami" className="hover:text-white">
                  Tentang Kami
                </Link>
              </li>
              <li>
                <Link href="/pages/hubungi-kami" className="hover:text-white">
                  Hubungi Kami
                </Link>
              </li>
              <li>
                <Link href="/pages/kebijakan-privasi" className="hover:text-white">
                  Kebijakan Privasi
                </Link>
              </li>
              <li>
                <Link href="/pages/disclaimer" className="hover:text-white">
                  Disclaimer
                </Link>
              </li>
              <li>
                <Link href="/pages/pedoman-media-siber" className="hover:text-white">
                  Pedoman Media Siber
                </Link>
              </li>
              <li>
                <Link href="/sitemap" className="hover:text-white">
                  Sitemap
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 4 */}
          <div>
            <h4 className="mb-4 font-bold uppercase">Hubungi Kami</h4>
            <address className="not-italic text-gray-400">
              <p className="mb-2">Email: mediarusdi@gmail.com</p>
              <p className="mb-2">Phone: +62 896 2449 0220</p>
              <p>Lampung, Indonesia</p>
            </address>
          </div>
        </div>

        <div className="mt-8 border-t border-gray-800 pt-6 text-center text-gray-400">
          <p>
            &copy; {new Date().getFullYear()} <Link href="/"> Rusdimedia.com</Link>. All rights reserved.
          </p>
        </div>

        {/* Histats Analytics */}
        <Script id="histats-analytics" strategy="afterInteractive">
          {`
            var _Hasync= _Hasync|| [];
            _Hasync.push(['Histats.start', '1,4911484,4,0,0,0,00010000']);
            _Hasync.push(['Histats.fasi', '1']);
            _Hasync.push(['Histats.track_hits', '']);
            (function() {
              var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
              hs.src = ('//s10.histats.com/js15_as.js');
              (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
            })();
          `}
        </Script>
        <noscript>
          <a href="/" target="_blank" rel="noopener noreferrer">
            <img src="//sstatic1.histats.com/0.gif?4911484&101" alt="" border="0" />
          </a>
        </noscript>
      </div>
    </footer>
  )
}
