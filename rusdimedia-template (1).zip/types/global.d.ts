interface Window {
  adsbygoogle: any[]
}
