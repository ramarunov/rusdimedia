import { searchPosts } from "@/lib/api"

interface GetPostsOptions {
  query?: string
  page?: number
  perPage?: number
}

export async function getPosts({ query = "", page = 1, perPage = 10 }: GetPostsOptions = {}) {
  if (!query) return []

  try {
    const result = await searchPosts(query, page, perPage)
    return result.posts
  } catch (error) {
    console.error("Error fetching posts:", error)
    return []
  }
}
